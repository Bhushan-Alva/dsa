"""Folder creation utility with step-level logging.

Public function preserved:
- create_folders

Purpose:
Create the standard project folder structure before the processing pipeline starts.
The function is intentionally flexible so it can support both your existing notebook
style and a more configurable production-style setup.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Mapping, Sequence

logger = logging.getLogger(__name__)

DEFAULT_FOLDER_STRUCTURE = {
    "raw": "Files/01. Raw",
    "current_raw": "Files/01. Raw/Current Raw",
    "previous_raw": "Files/01. Raw/Previous Raw",
    "lookup": "Files/02. Lookup",
    "clean_raw": "Files/03. Clean Raw",
    "output": "Files/04. Output",
    "logs": "Files/05. Logs",
    "validation": "Files/06. Validation",
    "archive": "Files/07. Archive",
}


def _log_step(step: str, level: int = logging.INFO, **details: Any) -> None:
    """Write one structured folder-creation log event."""
    if details:
        detail_text = " | ".join(f"{key}={value}" for key, value in details.items())
        logger.log(level, "%s | %s", step, detail_text)
    else:
        logger.log(level, "%s", step)


def _to_base_path(dir_path) -> Path:
    """Preserve old behavior: dir_path=1 means current working directory."""
    if dir_path == 1 or dir_path is None:
        base_dir = Path.cwd()
    else:
        base_dir = Path(dir_path)
    return base_dir


def _normalise_structure(folder_structure: Mapping[str, str | Path] | Sequence[str | Path] | None) -> dict[str, Path]:
    """Normalize a mapping/list of folders into name -> relative Path."""
    if folder_structure is None:
        return {name: Path(relative_path) for name, relative_path in DEFAULT_FOLDER_STRUCTURE.items()}

    if isinstance(folder_structure, Mapping):
        return {str(name): Path(relative_path) for name, relative_path in folder_structure.items()}

    return {Path(relative_path).name: Path(relative_path) for relative_path in folder_structure}


def create_folders(
    dir_path=1,
    folder_structure: Mapping[str, str | Path] | Sequence[str | Path] | None = None,
    exist_ok: bool = True,
    return_paths: bool = True,
) -> dict[str, Path] | list[Path]:
    """Create required project folders and log each step.

    Parameters
    ----------
    dir_path : str, Path, or 1
        Base directory where folders should be created. Existing behavior is kept:
        `dir_path=1` means use `Path.cwd()`.
    folder_structure : mapping, sequence, or None
        If None, creates the default project folders.
        If mapping, keys become friendly names and values are relative folder paths.
        If sequence, each item is treated as a relative folder path.
    exist_ok : bool
        Passed to Path.mkdir. Keep True for rerunnable pipelines.
    return_paths : bool
        True returns `{folder_name: absolute_path}`.
        False returns a list of absolute paths for compatibility with list-style usage.

    Returns
    -------
    dict[str, pathlib.Path] or list[pathlib.Path]
        Created folder paths.
    """
    _log_step("Folder creation started", dir_path=dir_path, exist_ok=exist_ok)

    base_dir = _to_base_path(dir_path)
    folders = _normalise_structure(folder_structure)

    _log_step(
        "Folder structure resolved",
        base_dir=base_dir,
        folder_count=len(folders),
        folder_names=list(folders.keys()),
    )

    created_paths: dict[str, Path] = {}
    errors: dict[str, str] = {}

    for name, relative_path in folders.items():
        folder_path = base_dir / relative_path
        try:
            already_exists = folder_path.exists()
            folder_path.mkdir(parents=True, exist_ok=exist_ok)
            created_paths[name] = folder_path
            _log_step(
                "Folder ready",
                folder_name=name,
                path=folder_path,
                already_exists=already_exists,
            )
        except Exception as exc:
            errors[name] = str(exc)
            _log_step(
                "Folder creation failed",
                logging.ERROR,
                folder_name=name,
                path=folder_path,
                error_type=type(exc).__name__,
                error_message=str(exc),
            )

    if errors:
        _log_step("Folder creation completed with errors", logging.ERROR, failed_count=len(errors), errors=errors)
        raise RuntimeError(
            "Failed to create one or more folders:\n"
            + "\n".join(f"{name}: {message}" for name, message in errors.items())
        )

    _log_step("Folder creation completed", created_count=len(created_paths), base_dir=base_dir)

    if return_paths:
        return created_paths
    return list(created_paths.values())
