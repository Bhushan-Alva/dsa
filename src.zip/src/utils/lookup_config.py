LOOKUP_CONFIG = {
    "project_group_type": {
        "sheet": "Project Group Type Mapping",
        "key_col": 0,
        "value_col": 1
    },
    "legal_entity_country": {
        "sheet": "Legal entity Country Mapping",
        "key_col": 0,
        "value_col": 1
    },
    "market_unit": {
        "sheet": "Market Unit Mapping",
        "key_col": 0,
        "value_col": 1
    },
    "private_car_source": {
        "sheet": "Private - Source Mapping",
        "key_col": 0,
        "value_col": 3
    },
    "private_car_type": {
        "sheet": "Private - Source Mapping",
        "key_col": 0,
        "value_col": 4
    },
    "legal_entity": {
        "sheet": "Legal Entity Mapping",
        "key_col": 4,
        "value_col": 7
    },
    "gbl": {
        "sheet": "Legal Entity Mapping",
        "key_col": 4,
        "value_col": 6
    },
    "bu_label": {
        "sheet": "Legal Entity Mapping",
        "key_col": 4,
        "value_col": 5
    },
    "currency_conversion": {
        "sheet": "Currency Conversion Mapping",
        "key_col": 0,
        "value_col": 3
    },
    "currency": {
        "sheet": "Currency Mapping",
        "key_col": 0,
        "value_col": 2
    },
    "chargeable": {
        "sheet": "Chargeable",
        "key_col": 0,
        "value_col": 1
    },
    "source": {
        "sheet": "Source",
        "key_col": 0,
        "value_col": 1
    },
    "company_car_source": {
        "sheet": "Company - source mapping",
        "key_col": 0,
        "value_col": 4
    },
    "lpt_bus_rates_mapping": {
        "sheet": "LPT Rates Mapping",
        "key_col": 1,
        "value_col": 14
    },
    "lpt_rail_rates_mapping": {
        "sheet": "LPT Rates Mapping",
        "key_col": 1,
        "value_col": 15
    },
    "lpt_cc_bus_rates_mapping": {
        "sheet": "LPT Rates Mapping",
        "key_col": 0,
        "value_col": 14
    },
    "lpt_cc_rail_rates_mapping": {
        "sheet": "LPT Rates Mapping",
        "key_col": 0,
        "value_col": 15
    },
    "lpt_country_mapping": {
        "sheet": "LPT Country Mapping",
        "key_col": 0,
        "value_col": 1
    },
    "rental_fuel_price_mapping": {
        "sheet": "Rental - Fuel price Mapping",
        "key_col": 1,
        "value_col": 4
    },
    "rental_source_mapping": {
        "sheet": "Rental - source mapping",
        "key_col": 1,
        "value_col": 3
    },
    "rental_source_fuel_mapping": {
        "sheet": "Rental - Travel Type Mapping",
        "key_col": 0,
        "value_col": 3
    },
    "rental_split_mapping": {
        "sheet": "Rental - Country Split Mapping",
        "key_col": 5,
        "value_col": 2
    },
    "taxi_city_start_rate_mapping": {
        "sheet": "Taxi - City Rates",
        "key_col": 0,
        "value_col": 5
    },
    "taxi_city_1km_rate_mapping": {
        "sheet": "Taxi - City Rates",
        "key_col": 0,
        "value_col": 6
    },
    "taxi_country_start_rate_mapping": {
        "sheet": "Taxi Country Rates",
        "key_col": 0,
        "value_col": 1
    },
    "taxi_country_1km_rate_mapping": {
        "sheet": "Taxi Country Rates",
        "key_col": 0,
        "value_col": 2
    },
    "taxi_city_normalized_mapping": {
        "sheet": "Taxi - City Rates",
        "key_col": 1,
        "value_col": 4
    },
    "normalized_country_mapping": {
        "sheet": "Normalized Country Mapping",
        "key_col": 0,
        "value_col": 1
    },
    "comp_details_from_mapping": {
        "sheet": "Comp Details Mapping",
        "key_col": 1,
        "value_col": 2
    },
    "comp_details_to_mapping": {
        "sheet": "Comp Details Mapping",
        "key_col": 1,
        "value_col": 3
    },
    "city_pair_mapping": {
        "sheet": "City Mapping",
        "key_col": 0,
        "value_col": 2
    },
    "country_mapping": {
        "sheet": "City Mapping",
        "key_col": 1,
        "value_col": 2
    },
    "vendor_name_mapping": {
        "sheet": "Vendor Name mapping",
        "key_col": 0,
        "value_col": 1
    },
    "eurostar_mapping": {
        "sheet": "Eurostar mapping",
        "key_col": 0,
        "value_col": 1
    },
    
    "rail_city_distance_mapping": {
        "sheet": "Rail distance",
        "key_col": 0,
        "value_col": 1
    },  
        "rail_country_rates_mapping": {
        "sheet": "rail country rates",
        "key_col": 0,
        "value_col": 3
    },
        "rail_region_rates_mapping": {
        "sheet": "rail region rates",
        "key_col": 0,
        "value_col": 3
    },
        "comp_details_distance_mapping": {
        "sheet": "Comp Details Mapping",
        "key_col": 1,
        "value_col": 5
    },  
        "rail_normalized_city_mapping": {
        "sheet": "Rail Normalized city",
        "key_col": 0,
        "value_col": 1
    },  
        "rail_normalized_country_mapping": {
        "sheet": "Rail Normalized city",
        "key_col": 0,
        "value_col": 2
    },  
        "usage_unit_mapping": {
        "sheet": "Usage Unit Mapping",
        "key_col": 0,
        "value_col": 1
    },
        "rail_clean_country_mapping": {
        "sheet": "Rail Clean Country",
        "key_col": 0,
        "value_col": 1
    },
        "rail_clean_region_mapping": {
        "sheet": "Rail Clean Country",
        "key_col": 0,
        "value_col": 2
    },   
        "1bb_code_mapping": {
        "sheet": "Profit Centre 1bb",
        "key_col": 3,
        "value_col": 2
    },  
        "io_text7_mapping": {
        "sheet": "IO type",
        "key_col": 1,
        "value_col": 3
    },  
        "profit_centre_gbl_mapping": {
        "sheet": "Profit Centre L2",
        "key_col": 0,
        "value_col": 2
    },  
        "project_class_code_mapping": {
        "sheet": "Project type",
        "key_col": 1,
        "value_col": 3
    },  
        "cost_centre_l4_mapping": {
        "sheet": "Cost Centre",
        "key_col": 0,
        "value_col": 1
    }, 
    "rail_normalized_city_country_mapping": {
        "sheet": "Rail Normalized city",
        "key_col": 0,
        "value_col": 2
    },  
}


