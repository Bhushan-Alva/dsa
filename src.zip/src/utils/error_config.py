ERROR_CONFIG = {
    # Common across all sources
    "missing_entity": {
        "input_columns": [
            "Employee Country",
            "Employee Legal Unit",
            "Emp Sbu Name",
            "Emp Bu Name",
        ],
        "output_column": "Legal Entity",
    },

    # Common across all sources
    "chargeable": {
        "input_columns": ["Billable/Nonbillable"],
        "output_column": "Chargeable/Non-Chargeable",
    },

    # Common across all sources
    "text_7": {
        "input_columns": ["Project Group Type"],
        "output_column": "Text 7",
    },

    # Common across all sources
    "market_unit": {
        "input_columns": ["Sector Names", "Sub sector names"],
        "output_column": "Market Unit",
    },
    
    # Common across all sources
    "to_be_uploaded": {
        "input_columns": ["Emp GBL", "Source"],
        "output_column": "To be Uploaded?",
    },

    # Hotel-specific
    "country_of_hotel": {
        "input_columns": ["Source", "Country Of Transaction"],
        "output_column": "Country of Hotel Stay",
        "sources": ["Hotel"],
    },

    # Rail-specific
    "rail_origin_city": {
        "input_columns": [
            "Source",
            "Port Of Departure",
        ],
        "output_column": "Origin City",
        "sources": ["Rail"],
    },

    "rail_destination_city": {
        "input_columns": [
            "Source",
            "Port Of Arrival",
        ],
        "output_column": "Destination City",
        "sources": ["Rail"],
    },

    # Taxi-specific
    "taxi_usage_input": {
        "input_columns": [
            "Source",
            "Country Of Transaction",
            "City Of Transaction",     
        ],
        "output_column": "Usage Input",
        "sources": ["Taxi"],
    },

    # Company Car-specific
    "company_car_source_name": {
        "input_columns": [
            "Source",
            "Employee Country",
            "Expense Type",
            "Criteria Name",
        ],
        "output_column": "Source Name",
        "sources": ["Company Car"],
    },
    
    # Private Car-specific
    "private_car_source_name": {
        "input_columns": [
            "Source",
            "Employee Country",
            "Expense Type",
            "Criteria Name",
        ],
        "output_column": "Source Name",
        "sources": ["Private Car"],
    },
    
    # Rental Car-specific
    "rental_car_source_name": {
        "input_columns": [
            "Source",
            "Country Of Transaction",
        ],
        "output_column": "Source Name",
        "sources": ["Rental Car"],
    },
}