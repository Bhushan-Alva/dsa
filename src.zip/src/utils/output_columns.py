"""Clean output configuration for MyExpense processing.

Contains:
- keys: source-wise console key column configuration
- output_columns: common + source-specific output column configuration

Notes:
- Column names are standardized for spacing and casing.
- generate_output.py should combine output_columns["Common Columns"] with output_columns[source].
- If your source dataframe uses alternate names like City Of Transaction for City Name,
  keep the alias handling in generate_output.py.
"""

keys = {
    "Company Car": [
        "Employee Country",
        "Expense Report Key",
        "Source Name",
        "Travel Type",
        "Year",
        "Month",
        "Travel Category",
        "Chargeable/Non-Chargeable",
        "Project Group Type",
    ],

    "Private Car": [
        "Employee Country",
        "Expense Report Key",
        "Expense Type",
        "Criteria Name",
        "Year",
        "Month",
        "Billable/Nonbillable",
        "Country Of Transaction",
        "Project Group Type",
    ],

    "Rental Car": [
        "Employee Country",
        "Expense Report Key",
        "Expense Type",
        "Billable/Nonbillable",
        "Country Of Transaction",
        "Departure Date",
        "Project Group Type",
    ],

    "LPT": [
        "Employee Country",
        "Expense Report Key",
        "Country Of Transaction",
        "City Of Transaction",
        "Departure Date",
        "Billable/Nonbillable",
        "Project Group Type",
    ],

    "Taxi": [
        "Employee Country",
        "Expense Report Key",
        "Country Of Transaction",
        "City Of Transaction",
        "Billable/Nonbillable",
        "Year",
        "Month",
        "Project Group Type",
    ],

    "Rail": [
        "Employee Country",
        "Expense Report Key",
        "Country Of Transaction",
        "City Of Transaction",
        "Departure Date",
        "Billable/Nonbillable",
        "Source Name",
        "Travel Type"
    ],
    
    "Hotel": [
        "Employee Country",
        "Expense Report Key",
        "Country Of Transaction",
        "Hotel City",
        "Expense Type",
        "Year",
        "Month",
        "Billable/Nonbillable",
        "Project Group Type",
    ],
}


output_columns = {
    "Common Columns": [
        "Console Key",
        "Source Name",
        "Usage Input",
        "Usage Unit Input",
        "Cost",
        "Currency",
        "Accounting Date",
        "Chargeable/Non-Chargeable",
        "Data Source",
        "Description/Notes",
        "Emp BU Code",
        "Emp BU Label - Lookup Key",
        "Emp GBL",
        "Emp PU Code",
        "Employee Email",
        "Employee First Name",
        "Employee ID",
        "Employee Last Name",
        "Employee Project Code",
        "Estimated data?",
        "Expense ID",
        "Legal Entity",
        "Long Text 1",
        "Long Text 2",
        "Market Unit",
        "Project Details",
        "Project GBL",
        "Project Unit Info",
        "Service Line",
        "To be Uploaded?",
        "Travel Category",
        "Travel Purpose",
        "Employee Grade",
        "Text 7",
    ],

    "Company Car": [
        "Departure Date",
        "Arrival Date",
        "Text 2",
        "Text 3",
        "Employee Legal Unit",
        "Travel Type",
    ],

    "Private Car": [
        "Departure Date",
        "Arrival Date",
        "Text 2",
        "Text 3",
        "Travel Type",
    ],

    "Rental Car": [
        "Departure Date",
        "Arrival Date",
        "Text 2",
        "Text 3",
        "Travel Type",
    ],

    "LPT": [
        "Departure Date",
        "Arrival Date",
        "Text 5",
        "Number 2",
    ],

    "Taxi": [
        "Departure Date",
        "Arrival Date",
        "Country Of Transaction",
        "City Name",
        "Text 3",
        "Text 5",
        "Number 2",
        "Number 3",
    ],

    "Rail": [
        "Departure Date",
        "Arrival Date",
        "Text 1",
        "Text 3",
        "Country Of Transaction",
        "Emissions",
    ],

    "Hotel": [
        "Check-In Date",
        "Check-Out Date",
        "Country of Hotel Stay",
        "Hotel City",
        "Hotel Name",
    ],
}


output_column_aliases = {
    "Country of Transaction": "Country Of Transaction",
    "Country Of transaction": "Country Of Transaction",
    "City Name": "City Of Transaction",
    "Text3": "Text 3",
    "Text3 ": "Text 3",
    "Text5": "Text 5",
    "Number2": "Number 2",
    "Number3": "Number 3",
}
