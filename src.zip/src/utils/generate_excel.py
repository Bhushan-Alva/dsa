"""Create a professionally formatted Excel workbook from tabular data."""

from pathlib import Path
from typing import Any, Union

import pandas as pd
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter


PathLike = Union[str, Path]


def generate_excel(
    data: Any,
    output_path: PathLike,
    output_file: str,
    sheet_name: str = "Data",
    header_freeze: bool = True,
    header_bold: bool = True,
    border: bool = True,
    header_bg_colour: str = "0000FF",
    header_color: str = "FFFFFF",
    column_autofit: bool = True,
    max_column_width: int = 50,
    add_filter: bool = True,
) -> str:
    """Generate a formatted Excel workbook from DataFrame-compatible data.

    Parameters
    ----------
    data:
        A pandas DataFrame or data that can be converted into a DataFrame.
    output_path:
        Folder where the Excel workbook will be saved.
    output_file:
        Excel workbook filename.
    sheet_name:
        Worksheet name.
    header_freeze:
        Freeze the first row when True.
    header_bold:
        Make header text bold when True.
    border:
        Apply thin borders to populated cells when True.
    header_bg_colour:
        Header background colour in hexadecimal format.
    header_color:
        Header font colour in hexadecimal format.
    column_autofit:
        Automatically adjust column widths when True.
    max_column_width:
        Maximum permitted column width.
    add_filter:
        Add an AutoFilter to the populated range when True.

    Returns
    -------
    str
        Full path of the generated Excel workbook.
    """
    if not isinstance(data, pd.DataFrame):
        data = pd.DataFrame(data)

    if max_column_width <= 0:
        raise ValueError("max_column_width must be greater than zero.")

    header_bg_colour = _normalise_hex_colour(
        header_bg_colour,
        "header_bg_colour",
    )
    header_color = _normalise_hex_colour(
        header_color,
        "header_color",
    )

    output_directory = Path(output_path)
    output_directory.mkdir(parents=True, exist_ok=True)

    output_filename = Path(output_file).name
    if Path(output_filename).suffix.lower() != ".xlsx":
        output_filename = f"{output_filename}.xlsx"

    final_output_path = output_directory / output_filename
    sheet_name = _clean_sheet_name(sheet_name)

    with pd.ExcelWriter(final_output_path, engine="openpyxl") as writer:
        data.to_excel(
            writer,
            sheet_name=sheet_name,
            index=False,
        )

        worksheet = writer.sheets[sheet_name]

        thin_border = Border(
            left=Side(style="thin", color="D9E1F2"),
            right=Side(style="thin", color="D9E1F2"),
            top=Side(style="thin", color="D9E1F2"),
            bottom=Side(style="thin", color="D9E1F2"),
        )

        header_fill = PatternFill(
            fill_type="solid",
            fgColor=header_bg_colour,
        )

        for cell in worksheet[1]:
            cell.fill = header_fill
            cell.font = Font(
                bold=header_bold,
                color=header_color,
            )
            cell.alignment = Alignment(
                horizontal="center",
                vertical="center",
            )

        worksheet.row_dimensions[1].height = 22
        worksheet.sheet_view.showGridLines = False

        if header_freeze:
            worksheet.freeze_panes = "A2"

        if border:
            for row in worksheet.iter_rows(
                min_row=1,
                max_row=worksheet.max_row,
                min_col=1,
                max_col=worksheet.max_column,
            ):
                for cell in row:
                    cell.border = thin_border

        if add_filter and worksheet.max_column > 0 and worksheet.max_row > 0:
            last_column = get_column_letter(worksheet.max_column)
            worksheet.auto_filter.ref = f"A1:{last_column}{worksheet.max_row}"

        if column_autofit:
            for column_number, column_cells in enumerate(
                worksheet.iter_cols(
                    min_col=1,
                    max_col=worksheet.max_column,
                ),
                start=1,
            ):
                maximum_length = max(
                    (
                        len(str(cell.value))
                        for cell in column_cells
                        if cell.value is not None
                    ),
                    default=0,
                )

                adjusted_width = min(
                    maximum_length + 2,
                    max_column_width,
                )

                column_letter = get_column_letter(column_number)
                worksheet.column_dimensions[column_letter].width = max(
                    adjusted_width,
                    10,
                )

    return str(final_output_path)


def _normalise_hex_colour(colour: str, parameter_name: str) -> str:
    """Validate and normalize a hexadecimal colour value."""
    value = str(colour).strip().lstrip("#").upper()

    is_valid_length = len(value) in (6, 8)
    is_valid_hex = all(
        character in "0123456789ABCDEF"
        for character in value
    )

    if not is_valid_length or not is_valid_hex:
        raise ValueError(
            f"{parameter_name} must be a valid "
            "6-digit or 8-digit hexadecimal colour."
        )

    return value


def _clean_sheet_name(sheet_name: str) -> str:
    """Return a valid Excel worksheet name."""
    cleaned_name = str(sheet_name).strip()

    for character in ("\\", "/", "*", "?", ":", "[", "]"):
        cleaned_name = cleaned_name.replace(character, "_")

    return cleaned_name[:31] or "Data"

