"""Central logging setup for Centralized Processing V2.

Use this before calling create_folders or any processing step.
"""

from __future__ import annotations

import logging
from datetime import datetime
from pathlib import Path
from typing import Optional


def setup_processing_logging(
    log_folder: str | Path = "logs",
    log_file_name: Optional[str] = None,
    level: int = logging.INFO,
    console: bool = True,
    overwrite: bool = True,
) -> Path:
    """Configure project-wide logging and return the log file path.

    Parameters
    ----------
    log_folder : str or Path
        Folder where the processing log should be saved.
    log_file_name : str, optional
        Log filename. If None, defaults to `processing_run.log`.
    level : int
        Logging level. Use logging.INFO for normal runs and logging.DEBUG for deep checks.
    console : bool
        Also show logs in notebook/console output.
    overwrite : bool
        True overwrites the previous run log. False appends to it.

    Returns
    -------
    pathlib.Path
        Path of the configured log file.
    """
    log_folder = Path(log_folder)
    log_folder.mkdir(parents=True, exist_ok=True)

    if log_file_name is None:
        log_file_name = "processing_run.log"

    log_path = log_folder / log_file_name
    mode = "w" if overwrite else "a"

    handlers: list[logging.Handler] = [
        logging.FileHandler(log_path, mode=mode, encoding="utf-8")
    ]

    if console:
        handlers.append(logging.StreamHandler())

    logging.basicConfig(
        level=level,
        format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
        handlers=handlers,
        force=True,
    )

    logging.getLogger(__name__).info(
        "Processing logging configured | log_path=%s | level=%s | overwrite=%s",
        log_path,
        logging.getLevelName(level),
        overwrite,
    )

    return log_path


def setup_timestamped_processing_logging(
    log_folder: str | Path = "logs",
    level: int = logging.INFO,
    console: bool = True,
) -> Path:
    """Configure logging with a timestamped logfile name."""
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    return setup_processing_logging(
        log_folder=log_folder,
        log_file_name=f"processing_run_{stamp}.log",
        level=level,
        console=console,
        overwrite=True,
    )
