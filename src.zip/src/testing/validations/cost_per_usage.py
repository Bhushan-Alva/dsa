import numpy as np
import pandas as pd


def cost_comparison(data, source="Hotel", threshold=2):
    """
    Compare expense-level cost per room night against the weighted
    country-average cost per room night.
    """

    if threshold <= 0:
        raise ValueError("threshold must be greater than zero.")

    required_columns = {
        "Source",
        "Country Of Transaction",
        "Legal Entity",
        "Expense ID",
        "Usage Input",
        "Approved Amount",
    }

    missing_columns = required_columns.difference(data.columns)

    if missing_columns:
        raise KeyError(
            f"Missing required columns: {sorted(missing_columns)}"
        )

    # Filter using the source parameter
    filtered_data = data.loc[
        data["Source"].eq(source)
    ].copy()

    # Convert calculation columns to numeric
    filtered_data["Usage Input"] = pd.to_numeric(
        filtered_data["Usage Input"],
        errors="coerce"
    )

    filtered_data["Approved Amount"] = pd.to_numeric(
        filtered_data["Approved Amount"],
        errors="coerce"
    )

    # Remove rows without the required grouping information
    filtered_data = filtered_data.dropna(
        subset=[
            "Country Of Transaction",
            "Legal Entity",
            "Expense ID",
        ]
    )

    # Country-level totals
    country_avg = (
        filtered_data.groupby(
            "Country Of Transaction",
            dropna=False
        )[["Usage Input", "Approved Amount"]]
        .sum(min_count=1)
    )

    # Safe country-level division
    country_avg["Average Cost per room night"] = np.nan

    valid_country_usage = (
        country_avg["Usage Input"].notna()
        & country_avg["Usage Input"].ne(0)
    )

    country_avg.loc[
        valid_country_usage,
        "Average Cost per room night"
    ] = (
        country_avg.loc[
            valid_country_usage,
            "Approved Amount"
        ]
        / country_avg.loc[
            valid_country_usage,
            "Usage Input"
        ]
    )

    # Expense-level totals
    result = (
        filtered_data.groupby(
            [
                "Country Of Transaction",
                "Legal Entity",
                "Expense ID",
            ],
            dropna=False
        )[["Usage Input", "Approved Amount"]]
        .sum(min_count=1)
    )

    # Safe expense-level division
    result["Cost per room night"] = np.nan

    valid_expense_usage = (
        result["Usage Input"].notna()
        & result["Usage Input"].ne(0)
    )

    result.loc[
        valid_expense_usage,
        "Cost per room night"
    ] = (
        result.loc[
            valid_expense_usage,
            "Approved Amount"
        ]
        / result.loc[
            valid_expense_usage,
            "Usage Input"
        ]
    )

    # Join country-average cost
    result = result.join(
        country_avg[["Average Cost per room night"]],
        on="Country Of Transaction"
    )

    # Calculate permitted range
    result["Lower Bound"] = (
        result["Average Cost per room night"] / threshold
    )

    result["Upper Bound"] = (
        result["Average Cost per room night"] * threshold
    )

    # Valid comparison requires both calculated costs
    valid_comparison = (
        result["Cost per room night"].notna()
        & result["Average Cost per room night"].notna()
    )

    within_threshold = result["Cost per room night"].between(
        result["Lower Bound"],
        result["Upper Bound"],
        inclusive="both"
    )

    result["Flag"] = np.select(
        [
            ~valid_comparison,
            within_threshold,
        ],
        [
            "NO VALID USAGE",
            "OK",
        ],
        default="CHECK"
    )

    # Percentage difference
    result["% Difference"] = np.nan

    valid_average = (
        valid_comparison
        & result["Average Cost per room night"].ne(0)
    )

    result.loc[
        valid_average,
        "% Difference"
    ] = (
        (
            result.loc[
                valid_average,
                "Cost per room night"
            ]
            - result.loc[
                valid_average,
                "Average Cost per room night"
            ]
        )
        / result.loc[
            valid_average,
            "Average Cost per room night"
        ]
    ) * 100

    # Round displayed calculation results
    numeric_output_columns = [
        "Usage Input",
        "Approved Amount",
        "Cost per room night",
        "Average Cost per room night",
        "Lower Bound",
        "Upper Bound",
        "% Difference",
    ]

    result[numeric_output_columns] = (
        result[numeric_output_columns].round(2)
    )

    return result.reset_index()