from pathlib import Path
from typing import Union

import numpy as np
import pandas as pd

PathLike = Union[str, Path]
MILES_PER_KILOMETRE = 0.621371192


def calculate_emissions(
    data: pd.DataFrame,
    ef_lookup_path: PathLike,
    source_column: str,
    country_column: str,
    year_column: str,
    usage_column: str,
    usage_unit: str,
    emissions_column: str,
    lookup_sheet: str = "EF",
    output_ef_column: str = "Emission Factor",
    output_emissions_column: str = "Emissions Generated",
):
    """Map emission factors and calculate emissions.

    Rules
    -----
    1. Existing emissions populated:
       Emission Factor = blank and Emissions Generated = existing emissions.
    2. Usage unit blank/null and no existing emissions:
       Emission Factor = 0 and Emissions Generated = 0.
    3. Usage unit is mile/miles:
       Usage is converted to kilometres before applying the emission factor.
    4. Non-Hotel factor mapping:
       Source Name + Year.
    5. Hotel factor mapping:
       Country + Year, then Worldwide + Year as fallback.

    Returns
    -------
    dict
        Contains data, missing_ef_log, all_source_duplicates,
        hotel_duplicates, and ef_lookup.
    """
    if not isinstance(data, pd.DataFrame):
        raise TypeError("data must be a pandas DataFrame.")

    lookup_path = Path(ef_lookup_path)
    if not lookup_path.exists():
        raise FileNotFoundError(f"EF lookup file not found: {lookup_path}")

    required_data_columns = [
        source_column,
        country_column,
        year_column,
        usage_column,
        usage_unit,
        emissions_column,
    ]
    missing_data_columns = [
        column for column in required_data_columns if column not in data.columns
    ]
    if missing_data_columns:
        raise KeyError(f"Missing columns in data: {missing_data_columns}")

    ef_lookup = pd.read_excel(
        lookup_path,
        sheet_name=lookup_sheet,
        engine="openpyxl",
    )

    required_lookup_columns = [
        "Source Name (on CR360)",
        "Countries",
        "Year",
        "Emission Factor 1 (Standard Unit)",
    ]
    missing_lookup_columns = [
        column
        for column in required_lookup_columns
        if column not in ef_lookup.columns
    ]
    if missing_lookup_columns:
        raise KeyError(f"Missing columns in ef_lookup: {missing_lookup_columns}")

    data = data.copy()
    ef_lookup = ef_lookup.copy()

    def clean_text(series: pd.Series) -> pd.Series:
        return (
            series.astype("string")
            .fillna("")
            .str.strip()
            .str.lower()
        )

    def clean_year(series: pd.Series) -> pd.Series:
        return clean_text(series).str.replace(r"\.0$", "", regex=True)

    # ---------------------------------------------------------
    # Prepare lookup
    # ---------------------------------------------------------
    lookup_year = clean_year(ef_lookup["Year"])
    lookup_source = clean_text(ef_lookup["Source Name (on CR360)"])
    lookup_country = clean_text(ef_lookup["Countries"])

    ef_lookup["Year"] = lookup_year
    ef_lookup["Source Name (on CR360)"] = lookup_source
    ef_lookup["Countries"] = lookup_country
    ef_lookup["Emission Factor 1 (Standard Unit)"] = pd.to_numeric(
        ef_lookup["Emission Factor 1 (Standard Unit)"],
        errors="coerce",
    )

    ef_lookup["All Sources Key"] = lookup_source + lookup_year
    ef_lookup["Hotel Key"] = lookup_country + lookup_year

    valid_source_key = lookup_source.ne("") & lookup_year.ne("")
    valid_hotel_key = lookup_country.ne("") & lookup_year.ne("")

    all_source_duplicates = (
        ef_lookup.loc[
            valid_source_key
            & ef_lookup["All Sources Key"].duplicated(keep=False),
            [
                "All Sources Key",
                "Source Name (on CR360)",
                "Year",
                "Emission Factor 1 (Standard Unit)",
            ],
        ]
        .sort_values("All Sources Key", kind="stable")
        .reset_index(drop=True)
    )

    hotel_duplicates = (
        ef_lookup.loc[
            valid_hotel_key
            & ef_lookup["Hotel Key"].duplicated(keep=False),
            [
                "Hotel Key",
                "Countries",
                "Year",
                "Emission Factor 1 (Standard Unit)",
            ],
        ]
        .sort_values("Hotel Key", kind="stable")
        .reset_index(drop=True)
    )

    if not all_source_duplicates.empty:
        print("Warning: duplicate All Sources Key values found; first is used.")
    if not hotel_duplicates.empty:
        print("Warning: duplicate Hotel Key values found; first is used.")

    source_mapping = (
        ef_lookup.loc[
            valid_source_key,
            ["All Sources Key", "Emission Factor 1 (Standard Unit)"],
        ]
        .drop_duplicates("All Sources Key", keep="first")
        .set_index("All Sources Key")["Emission Factor 1 (Standard Unit)"]
    )

    hotel_mapping = (
        ef_lookup.loc[
            valid_hotel_key,
            ["Hotel Key", "Emission Factor 1 (Standard Unit)"],
        ]
        .drop_duplicates("Hotel Key", keep="first")
        .set_index("Hotel Key")["Emission Factor 1 (Standard Unit)"]
    )

    # ---------------------------------------------------------
    # Prepare activity data
    # ---------------------------------------------------------
    data_year = clean_year(data[year_column])
    data_source = clean_text(data[source_column])
    data_country = clean_text(data[country_column])
    data_unit = clean_text(data[usage_unit])

    usage_numeric = pd.to_numeric(data[usage_column], errors="coerce")
    existing_emissions = pd.to_numeric(
        data[emissions_column],
        errors="coerce",
    )

    data[usage_column] = usage_numeric
    data["All Sources Key"] = data_source + data_year
    data["Hotel Key"] = data_country + data_year
    data["Worldwide Hotel Key"] = "worldwide" + data_year

    # Standard bool masks are required by NumPy np.select.
    is_hotel = (
        data_source.str.contains("hotel", na=False)
        .fillna(False)
        .astype(bool)
    )
    unit_is_blank = data_unit.eq("").fillna(True).astype(bool)
    unit_is_miles = (
        data_unit.isin(["mile", "miles"])
        .fillna(False)
        .astype(bool)
    )
    has_existing_emissions = existing_emissions.notna().astype(bool)

    # Convert miles to kilometres for emission calculation only.
    calculated_usage = usage_numeric.where(
        ~unit_is_miles,
        usage_numeric / MILES_PER_KILOMETRE,
    )

    # ---------------------------------------------------------
    # Vectorized EF mapping
    # ---------------------------------------------------------
    source_factor = data["All Sources Key"].map(source_mapping)
    hotel_country_factor = data["Hotel Key"].map(hotel_mapping)
    hotel_worldwide_factor = data["Worldwide Hotel Key"].map(hotel_mapping)
    hotel_factor = hotel_country_factor.fillna(hotel_worldwide_factor)

    mapped_factor = source_factor.copy()
    mapped_factor.loc[is_hotel] = hotel_factor.loc[is_hotel]

    data[output_ef_column] = mapped_factor

    # Blank usage unit means zero EF unless existing emissions override it.
    blank_unit_no_override = unit_is_blank & ~has_existing_emissions
    data.loc[blank_unit_no_override, output_ef_column] = 0.0

    # Existing emissions override means the EF remains blank.
    data.loc[has_existing_emissions, output_ef_column] = np.nan

    # ---------------------------------------------------------
    # Mapping/calculation audit columns
    # ---------------------------------------------------------
    data["Usage for Emission Calculation"] = calculated_usage

    data["EF Mapping Type"] = np.select(
        condlist=[
            has_existing_emissions.to_numpy(dtype=bool),
            blank_unit_no_override.to_numpy(dtype=bool),
            (
                ~is_hotel & source_factor.notna()
            ).to_numpy(dtype=bool),
            (
                is_hotel & hotel_country_factor.notna()
            ).to_numpy(dtype=bool),
            (
                is_hotel
                & hotel_country_factor.isna()
                & hotel_worldwide_factor.notna()
            ).to_numpy(dtype=bool),
        ],
        choicelist=[
            "Existing Emissions Used",
            "Blank Usage Unit - Zero",
            "Source-Year",
            "Hotel Country-Year",
            "Hotel Worldwide-Year",
        ],
        default="Emission Factor Missing",
    )

    data["Usage Conversion Type"] = np.select(
        condlist=[
            has_existing_emissions.to_numpy(dtype=bool),
            blank_unit_no_override.to_numpy(dtype=bool),
            (
                unit_is_miles
                & ~has_existing_emissions
                & ~unit_is_blank
            ).to_numpy(dtype=bool),
        ],
        choicelist=[
            "Not Applicable - Existing Emissions",
            "Not Applicable - Blank Unit",
            "Miles to Kilometres",
        ],
        default="No Conversion",
    )

    # ---------------------------------------------------------
    # Calculate final emissions with rule priority
    # ---------------------------------------------------------
    calculated_emissions = calculated_usage * mapped_factor

    data[output_emissions_column] = calculated_emissions
    data.loc[blank_unit_no_override, output_emissions_column] = 0.0
    data.loc[has_existing_emissions, output_emissions_column] = (
        existing_emissions.loc[has_existing_emissions]
    )

    # ---------------------------------------------------------
    # Unique missing-factor audit log
    # Existing-emission rows and blank-unit rows do not require an EF.
    # ---------------------------------------------------------
    missing_mask = (
        ~has_existing_emissions
        & ~unit_is_blank
        & usage_numeric.notna()
        & mapped_factor.isna()
    ).astype(bool)

    missing_log_columns = [
        "Source",
        source_column,
        country_column,
        year_column,
        usage_unit,
        "All Sources Key",
        "Hotel Key",
        "Worldwide Hotel Key",
        "EF Mapping Type",
    ]
    missing_log_columns = list(dict.fromkeys(missing_log_columns))
    missing_log_columns = [
        column for column in missing_log_columns if column in data.columns
    ]

    missing_ef_log = data.loc[
        missing_mask,
        missing_log_columns,
    ].copy()

    missing_ef_log["Lookup Key Used"] = np.where(
        is_hotel.loc[missing_mask].to_numpy(dtype=bool),
        data.loc[missing_mask, "Hotel Key"],
        data.loc[missing_mask, "All Sources Key"],
    )

    missing_ef_log = (
        missing_ef_log
        .drop_duplicates()
        .reset_index(drop=True)
    )

    return {
        "data": data,
        "missing_ef_log": missing_ef_log,
        "all_source_duplicates": all_source_duplicates,
        "hotel_duplicates": hotel_duplicates,
        "ef_lookup": ef_lookup,
    }
