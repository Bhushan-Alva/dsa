"""Email helper utilities with optional Outlook support and step-level logging.

Public functions preserved:
- render_html_matrix
- send_outlook_email

Added functions:
- read_comparison_preview
- build_comparison_summary_matrix
- render_difference_summary_html
- send_comparison_email_per_source
- send_comparison_emails_by_source

Purpose:
Render validation/comparison DataFrames as HTML and optionally create/send Outlook
emails on Windows machines where Outlook and pywin32 are available.

Important:
This module is safe to import on non-Windows/server environments. Outlook-specific
errors are raised only when send_outlook_email is actually called.
"""

from __future__ import annotations

import html
import logging
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)

try:  # pywin32 is Windows/Outlook specific
    import win32com.client as win32  # type: ignore
except Exception:  # pragma: no cover - expected outside Windows/Outlook environments
    win32 = None


DEFAULT_COMPARISON_COLUMNS = [
    "Employee country",
    "report extract date",
    "expense id",
    "prev amt",
    "curr amt",
    "diff",
]


def _log_step(step: str, level: int = logging.INFO, **details: Any) -> None:
    """Write one structured log entry for mail processing."""
    if details:
        detail_text = " | ".join(f"{key}={value}" for key, value in details.items())
        logger.log(level, "%s | %s", step, detail_text)
    else:
        logger.log(level, "%s", step)


def _normalise_recipients(value: str | Iterable[str] | None, field_name: str) -> list[str]:
    """Normalize recipient input to a clean list of email strings.

    Supports:
    - single string
    - semicolon-separated string
    - comma-separated string
    - list/tuple/set of recipients
    - Outlook display lists, e.g. "DL IN CAT_MYEXPENSE"
    """
    if value is None:
        return []
    if isinstance(value, str):
        parts = value.replace(",", ";").split(";")
    else:
        parts = list(value)

    recipients = [str(item).strip() for item in parts if str(item).strip()]
    _log_step("Recipients normalised", field=field_name, recipient_count=len(recipients))
    return recipients


def _normalise_attachments(value: str | Path | Sequence[str | Path] | None) -> list[Path]:
    """Normalize attachment input to a list of Path objects."""
    if value is None:
        return []
    if isinstance(value, (str, Path)):
        attachments = [Path(value)]
    else:
        attachments = [Path(item) for item in value]
    _log_step("Attachments normalised", attachment_count=len(attachments), attachments=[str(path) for path in attachments])
    return attachments


def _format_cell(value: Any) -> str:
    """Format a value safely for HTML table display."""
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass

    if isinstance(value, (float, int, np.floating, np.integer)):
        if np.isfinite(value):
            return f"{float(value):,.2f}"
        return ""
    return html.escape(str(value))


def render_html_matrix(
    df: pd.DataFrame,
    title: str | None = None,
    max_rows: int | None = None,
    include_index: bool = False,
    table_style: str | None = None,
) -> str:
    """Render a DataFrame as a clean HTML table for email body."""
    _log_step("HTML matrix render started", rows=len(df), columns=len(df.columns), title=title, max_rows=max_rows)

    if not isinstance(df, pd.DataFrame):
        _log_step("HTML matrix render failed", logging.ERROR, reason="df is not a DataFrame", received_type=type(df).__name__)
        raise TypeError("df must be a pandas DataFrame")

    render_df = df.copy()
    truncated = False
    if max_rows is not None and len(render_df) > max_rows:
        render_df = render_df.head(max_rows)
        truncated = True
        _log_step("HTML matrix render truncated", logging.WARNING, original_rows=len(df), rendered_rows=max_rows)

    if include_index:
        render_df = render_df.reset_index()

    if table_style is None:
        table_style = "border-collapse:collapse;font-family:Segoe UI,Arial,sans-serif;font-size:12px;"

    html_parts = []
    if title:
        html_parts.append(f"<h3 style='font-family:Segoe UI,Arial,sans-serif;'>{html.escape(str(title))}</h3>")

    if truncated:
        html_parts.append(
            f"<p style='font-family:Segoe UI,Arial,sans-serif;'>Showing first {len(render_df):,} of {len(df):,} rows.</p>"
        )

    html_parts.append(f"<table style='{table_style}'>")
    html_parts.append("<thead><tr>")
    for column in render_df.columns:
        html_parts.append(
            "<th style='background:#4F81BD;color:white;border:1px solid #D9E2F3;padding:6px;text-align:left;'>"
            + html.escape(str(column))
            + "</th>"
        )
    html_parts.append("</tr></thead>")

    html_parts.append("<tbody>")
    for _, row in render_df.iterrows():
        html_parts.append("<tr>")
        for value in row:
            html_parts.append(
                "<td style='border:1px solid #D9E2F3;padding:6px;'>"
                + _format_cell(value)
                + "</td>"
            )
        html_parts.append("</tr>")
    html_parts.append("</tbody></table>")

    result = "".join(html_parts)
    _log_step("HTML matrix render completed", rendered_rows=len(render_df), html_length=len(result))
    return result


def send_outlook_email(
    to_emails,
    subject: str,
    html_body: str,
    cc_emails=None,
    bcc_emails=None,
    attachments=None,
    display: bool = True,
    send: bool = False,
    importance: str = "Normal",
) -> bool:
    """Create, display, or send an Outlook email."""
    _log_step("Outlook email step started", subject=subject, display=display, send=send)

    to_list = _normalise_recipients(to_emails, "to")
    cc_list = _normalise_recipients(cc_emails, "cc")
    bcc_list = _normalise_recipients(bcc_emails, "bcc")
    attachment_paths = _normalise_attachments(attachments)

    if not to_list:
        _log_step("Outlook email failed", logging.ERROR, reason="No To recipients")
        raise ValueError("At least one To recipient is required")
    if not subject or not str(subject).strip():
        _log_step("Outlook email failed", logging.ERROR, reason="Subject is blank")
        raise ValueError("subject cannot be blank")
    if html_body is None:
        _log_step("Outlook email failed", logging.ERROR, reason="html_body is None")
        raise ValueError("html_body cannot be None")
    if not display and not send:
        _log_step("Outlook email failed", logging.ERROR, reason="Both display and send are False")
        raise ValueError("At least one of display=True or send=True is required")

    missing_attachments = [path for path in attachment_paths if not path.exists()]
    if missing_attachments:
        _log_step("Outlook email failed", logging.ERROR, reason="Attachment not found", attachments=[str(path) for path in missing_attachments])
        raise FileNotFoundError(f"Attachment(s) not found: {[str(path) for path in missing_attachments]}")

    if win32 is None:
        _log_step("Outlook email failed", logging.ERROR, reason="pywin32/Outlook unavailable")
        raise RuntimeError("Outlook automation is unavailable. This requires Windows, Outlook desktop, and pywin32.")

    try:
        outlook = win32.Dispatch("Outlook.Application")
        mail = outlook.CreateItem(0)

        mail.To = "; ".join(to_list)
        if cc_list:
            mail.CC = "; ".join(cc_list)
        if bcc_list:
            mail.BCC = "; ".join(bcc_list)

        mail.Subject = str(subject).strip()
        mail.HTMLBody = str(html_body)

        importance_map = {"low": 0, "normal": 1, "high": 2}
        mail.Importance = importance_map.get(str(importance).strip().lower(), 1)

        for path in attachment_paths:
            mail.Attachments.Add(Source=str(path.resolve()))
            _log_step("Attachment added", attachment=str(path.resolve()))

        if send:
            mail.Send()
            _log_step("Outlook email sent", to_count=len(to_list), cc_count=len(cc_list), attachment_count=len(attachment_paths))
        elif display:
            mail.Display()
            _log_step("Outlook email displayed", to_count=len(to_list), cc_count=len(cc_list), attachment_count=len(attachment_paths))
    except Exception as exc:
        _log_step("Outlook email failed", logging.ERROR, error_type=type(exc).__name__, error_message=str(exc))
        raise

    _log_step("Outlook email step completed", subject=subject)
    return True


def read_comparison_preview(
    file_path: str | Path,
    max_rows: int | None = None,
    expected_columns: Sequence[str] | None = None,
) -> pd.DataFrame:
    """Read a comparison file for email table generation.

    Supports `.xlsx`, `.xlsm`, `.xls`, and `.csv` files.
    By default it keeps the six current-vs-previous comparison columns.
    """
    file_path = Path(file_path)
    _log_step("Comparison preview read started", file_path=file_path, max_rows=max_rows)

    if not file_path.exists():
        _log_step("Comparison preview read failed", logging.ERROR, reason="File not found", file_path=file_path)
        raise FileNotFoundError(f"Comparison file not found: {file_path}")

    if expected_columns is None:
        expected_columns = DEFAULT_COMPARISON_COLUMNS

    suffix = file_path.suffix.lower()
    if suffix == ".csv":
        preview_df = pd.read_csv(file_path, nrows=max_rows)
    elif suffix in {".xlsx", ".xlsm", ".xls"}:
        preview_df = pd.read_excel(file_path, sheet_name=0, nrows=max_rows)
    else:
        _log_step("Comparison preview read failed", logging.ERROR, reason="Unsupported file type", file_path=file_path)
        raise ValueError(f"Unsupported comparison file type: {suffix}")

    available_columns = [col for col in expected_columns if col in preview_df.columns]
    if available_columns:
        preview_df = preview_df[available_columns]
    else:
        _log_step("Comparison preview columns not found", logging.WARNING, file_path=file_path, expected_columns=list(expected_columns))

    _log_step("Comparison preview read completed", file_path=file_path, rows=len(preview_df), columns=len(preview_df.columns))
    return preview_df


def build_comparison_summary_matrix(diff_df: pd.DataFrame) -> pd.DataFrame:
    """Build country x month percentage-difference matrix for email body.

    Input should contain:
    - Employee country
    - report extract date
    - prev amt
    - curr amt

    Output example:
    Employee country | Jan-2026 | Feb-2026 | Mar-2026 | ...

    Logic per country-month:
    - prev = 0 and curr = 0: 0.00
    - prev = 0 and curr != 0: 100.00
    - otherwise: ((curr - prev) / abs(prev)) * 100
    """
    required = ["Employee country", "report extract date", "prev amt", "curr amt"]
    missing = [col for col in required if col not in diff_df.columns]
    if missing:
        _log_step("Comparison summary matrix failed", logging.ERROR, missing_columns=missing)
        raise KeyError(f"Missing required columns for comparison summary matrix: {missing}")

    df = diff_df.copy()
    df["report extract date"] = pd.to_datetime(df["report extract date"], errors="coerce")
    df["month_period"] = df["report extract date"].dt.to_period("M")
    df["month_label"] = df["report extract date"].dt.strftime("%b-%Y")
    df["prev amt"] = pd.to_numeric(df["prev amt"], errors="coerce").fillna(0)
    df["curr amt"] = pd.to_numeric(df["curr amt"], errors="coerce").fillna(0)

    before = len(df)
    df = df.dropna(subset=["Employee country", "month_period"]).copy()

    grouped = (
        df.groupby(["Employee country", "month_period", "month_label"], dropna=False)
        .agg(prev_amt=("prev amt", "sum"), curr_amt=("curr amt", "sum"))
        .reset_index()
    )

    grouped["pct_diff"] = np.where(
        (grouped["prev_amt"] == 0) & (grouped["curr_amt"] == 0),
        0.0,
        np.where(
            (grouped["prev_amt"] == 0) & (grouped["curr_amt"] != 0),
            100.0,
            ((grouped["curr_amt"] - grouped["prev_amt"]) / grouped["prev_amt"].abs()) * 100,
        ),
    )

    month_order = (
        grouped[["month_period", "month_label"]]
        .drop_duplicates()
        .sort_values("month_period")["month_label"]
        .tolist()
    )

    matrix = (
        grouped.pivot_table(
            index="Employee country",
            columns="month_label",
            values="pct_diff",
            aggfunc="first",
            fill_value=0.0,
        )
        .reindex(columns=month_order)
        .reset_index()
    )

    matrix = matrix.sort_values("Employee country").reset_index(drop=True)

    _log_step(
        "Comparison summary matrix built",
        input_rows=before,
        usable_rows=len(df),
        output_rows=len(matrix),
        month_count=max(len(matrix.columns) - 1, 0),
    )
    return matrix


def render_difference_summary_html(
    summary_df: pd.DataFrame,
    title: str | None = None,
    latest_month_name: str | None = None,
) -> str:
    """Render the country x month summary matrix like the required Outlook screenshot.

    Color rules:
    Latest month:
        0.00     -> RED
        non-zero -> BLUE

    Other months:
        0.00     -> GREEN
        non-zero -> RED

    Expected input:
        Employee country | Jan-2026 | Feb-2026 | ... | Latest-Month
    """

    _log_step(
        "Difference summary HTML render started",
        rows=len(summary_df),
        columns=len(summary_df.columns),
        title=title,
    )

    if not isinstance(summary_df, pd.DataFrame):
        _log_step(
            "Difference summary HTML render failed",
            logging.ERROR,
            reason="summary_df is not a DataFrame",
            received_type=type(summary_df).__name__,
        )
        raise TypeError("summary_df must be a pandas DataFrame")

    if summary_df.empty:
        _log_step(
            "Difference summary HTML render completed",
            logging.WARNING,
            reason="summary_df is empty",
        )
        return "<p>No comparison differences available.</p>"

    if "Employee country" not in summary_df.columns:
        _log_step(
            "Difference summary HTML render failed",
            logging.ERROR,
            reason="Employee country column missing",
            columns=list(summary_df.columns),
        )
        raise KeyError("summary_df must contain 'Employee country' column")

    month_columns = [col for col in summary_df.columns if col != "Employee country"]

    if not month_columns:
        _log_step(
            "Difference summary HTML render completed",
            logging.WARNING,
            reason="No month columns available",
        )
        return "<p>No month-wise comparison data available.</p>"

    # If latest month is not explicitly passed, use the last month column.
    # build_comparison_summary_matrix already sorts month columns chronologically.
    if latest_month_name is None:
        latest_month_name = month_columns[-1]

    RED = "#FFD5D5"
    BLUE = "#CFE8FF"
    GREEN = "#C6EFCE"
    WHITE = "#FFFFFF"
    BORDER = "#BFBFBF"

    table_style = (
        "border-collapse:collapse;"
        "font-family:Segoe UI,Roboto,Arial,sans-serif;"
        "font-size:12px;"
    )

    cell_style = (
        f"border:1px solid {BORDER};"
        "padding:6px 8px;"
        "text-align:center;"
        "color:#000000;"
    )

    row_header_style = (
        f"border:1px solid {BORDER};"
        "padding:6px 8px;"
        "text-align:left;"
        "font-weight:bold;"
        f"background-color:{WHITE};"
        "color:#000000;"
    )

    html_parts: list[str] = []

    if title:
        html_parts.append(
            "<h3 style='font-family:Segoe UI,Roboto,Arial,sans-serif;'>"
            + html.escape(str(title))
            + "</h3>"
        )

    html_parts.append(f"<table style='{table_style}'>")

    # Header: first cell blank, then month names
    html_parts.append("<thead><tr>")
    html_parts.append(f"<th style='{cell_style} background-color:{WHITE};'></th>")

    for col in month_columns:
        html_parts.append(
            f"<th style='{cell_style} font-weight:bold;background-color:{WHITE};'>"
            + html.escape(str(col))
            + "</th>"
        )

    html_parts.append("</tr></thead>")

    # Body
    html_parts.append("<tbody>")

    for _, row in summary_df.iterrows():
        html_parts.append("<tr>")

        country_value = "" if pd.isna(row["Employee country"]) else str(row["Employee country"])

        html_parts.append(
            f"<th style='{row_header_style}'>"
            + html.escape(country_value)
            + "</th>"
        )

        for col in month_columns:
            value = row[col]

            if pd.isna(value):
                display_value = "NA"
                bg_color = WHITE
            else:
                try:
                    num_value = float(value)
                except Exception:
                    num_value = 0.0

                display_value = f"{num_value:.2f}%"
                is_zero = abs(num_value) < 1e-12

                if latest_month_name and col == latest_month_name:
                    # Latest month:
                    # 0.00 -> RED, non-zero -> BLUE
                    bg_color = RED if is_zero else BLUE
                else:
                    # Previous months:
                    # 0.00 -> GREEN, non-zero -> RED
                    bg_color = GREEN if is_zero else RED

            html_parts.append(
                f"<td style='{cell_style} background-color:{bg_color};'>"
                + display_value
                + "</td>"
            )

        html_parts.append("</tr>")

    html_parts.append("</tbody></table>")

    result = "\n".join(html_parts)

    _log_step(
        "Difference summary HTML render completed",
        html_length=len(result),
        latest_month_name=latest_month_name,
        month_columns=month_columns,
    )

    return result

def send_comparison_email_per_source(
    source: str,
    report_path: str | Path,
    to_emails,
    data_source="MyExpense",
    cc_emails=None,
    bcc_emails=None,
    run_date: str | None = None,
    max_preview_rows: int | None = None,
    display: bool = True,
    send: bool = False,
    importance: str = "Normal",
) -> bool:
    """Create/send one current-vs-previous comparison email for one source.

    Email body shows country x month summary matrix.
    Attachment contains detailed six-column comparison file.
    """
    report_path = Path(report_path)
    if run_date is None:
        run_date = datetime.now().strftime("%d-%m-%Y")

    _log_step("Per-source comparison email started", source=source, report_path=report_path)

    diff_df = read_comparison_preview(report_path, max_rows=max_preview_rows)
    summary_df = build_comparison_summary_matrix(diff_df)
    summary_html = render_difference_summary_html(summary_df)

    html_body = f"""
    <p>Hello All,</p>
    <br>
    <p>Please find {data_source} <b>{html.escape(str(source))}</b> difference table below:</p>
    <p>Kindly refer to the attachment for the differences found.</p>
    <br>
    {summary_html}
    """

    result = send_outlook_email(
        to_emails=to_emails,
        cc_emails=cc_emails,
        bcc_emails=bcc_emails,
        subject=f"Python {data_source} {source} difference {run_date}",
        html_body=html_body,
        attachments=[report_path],  # one mail, one source, one attachment
        display=display,
        send=send,
        importance=importance,
    )

    _log_step("Per-source comparison email completed", source=source, report_path=report_path)
    return result


def send_comparison_emails_by_source(
    comparison_reports: Mapping[str, str | Path],
    to_emails,
    cc_emails=None,
    bcc_emails=None,
    data_source="MyExpense",
    run_date: str | None = None,
    max_preview_rows: int | None = None,
    display: bool = True,
    send: bool = False,
    importance: str = "Normal",
    continue_on_error: bool = False,
) -> list[str]:
    """Create/send separate current-vs-previous comparison emails source-wise.

    Each email body contains a country x month summary matrix.
    Each email has only one source-specific attachment.
    """
    if not comparison_reports:
        _log_step("Per-source comparison email skipped", logging.WARNING, reason="comparison_reports is empty")
        return []

    if run_date is None:
        run_date = datetime.now().strftime("%d-%m-%Y")

    _log_step("Per-source comparison emails started", source_count=len(comparison_reports), run_date=run_date)

    completed_sources: list[str] = []
    errors: dict[str, str] = {}

    for source, report_path in comparison_reports.items():
        try:
            send_comparison_email_per_source(
                source=source,
                report_path=report_path,
                to_emails=to_emails,
                cc_emails=cc_emails,
                bcc_emails=bcc_emails,
                data_source=data_source,
                run_date=run_date,
                max_preview_rows=max_preview_rows,
                display=display,
                send=send,
                importance=importance,
            )
            completed_sources.append(str(source))
        except Exception as exc:
            errors[str(source)] = str(exc)
            _log_step("Per-source comparison email failed", logging.ERROR, source=source, report_path=report_path, error_type=type(exc).__name__, error_message=str(exc))
            if not continue_on_error:
                raise

    if errors:
        _log_step("Per-source comparison emails completed with errors", logging.ERROR, completed_sources=completed_sources, errors=errors)
    else:
        _log_step("Per-source comparison emails completed", completed_sources=completed_sources)

    return completed_sources
