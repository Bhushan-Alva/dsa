import re
from datetime import datetime
from pathlib import Path
from typing import Iterable, Optional, Union

import pandas as pd
from openpyxl import Workbook, load_workbook
from openpyxl.formatting.rule import ColorScaleRule
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

PathLike = Union[str, Path]
BLANK_VALUES = {"", "null", "none", "nan", "n/a", "na", "<na>"}
ALL_DATA_LABEL = "All Data"
BLANK_SOURCE_LABEL = "Blank Source"


def identify_blank_values(series: pd.Series) -> pd.Series:
    """Return True for values that should be treated as blank."""
    # Convert to pandas string dtype before replacing missing values.
    # This works with nullable Float64, Int64, boolean, datetime and object columns.
    return (
        series.astype("string")
        .fillna("")
        .str.strip()
        .str.lower()
        .isin(BLANK_VALUES)
    )


def create_column_summary(data: pd.DataFrame) -> pd.DataFrame:
    """Calculate completeness for every column, preserving DataFrame order."""
    total_rows = len(data)
    rows = []

    for column_name in data.columns:
        blank_rows = int(identify_blank_values(data[column_name]).sum())
        populated_rows = total_rows - blank_rows
        rows.append({
            "Column Name": str(column_name),
            "Total Rows": total_rows,
            "Populated Rows": populated_rows,
            "Populated Percentage": populated_rows / total_rows if total_rows else 0,
        })

    summary = pd.DataFrame(rows)
    summary.insert(0, "Serial Number", range(1, len(summary) + 1))
    return summary


def _resolve_sources(
    data: pd.DataFrame,
    source_column: Optional[str],
    sources: Optional[Union[str, Iterable[str]]],
):
    """
    Resolve source groups.

    If source_column is blank, missing, or contains only blank values,
    create one All Data sheet. If nonblank sources exist, create one sheet
    per unique source. Blank rows alongside nonblank sources use Blank Source.
    """
    if not source_column or source_column not in data.columns:
        if sources is not None:
            raise KeyError(f"Source column not found: {source_column!r}")
        return {ALL_DATA_LABEL: pd.Series(True, index=data.index)}

    cleaned = data[source_column].astype("string").fillna("").str.strip()
    blank_mask = identify_blank_values(cleaned)
    nonblank = cleaned.mask(blank_mask, "")

    if nonblank.eq("").all():
        return {ALL_DATA_LABEL: pd.Series(True, index=data.index)}

    if sources is None:
        requested = nonblank[nonblank.ne("")].drop_duplicates().tolist()
        if blank_mask.any():
            requested.append(BLANK_SOURCE_LABEL)
    elif isinstance(sources, str):
        requested = [sources]
    else:
        requested = list(sources)

    groups = {}
    for source in requested:
        source = str(source).strip()
        if not source:
            continue
        if source.casefold() == BLANK_SOURCE_LABEL.casefold():
            groups[BLANK_SOURCE_LABEL] = blank_mask
        else:
            groups[source] = nonblank.str.casefold().eq(source.casefold())

    if not groups:
        raise ValueError("No source values were provided or found.")

    return groups


def _safe_sheet_names(sources):
    """Create unique Excel-safe worksheet names."""
    used = set()
    mapping = {}

    for source in sources:
        base = (re.sub(r'[\\/*?:\[\]]', "_", str(source)).strip() or ALL_DATA_LABEL)[:31]
        name = base
        counter = 2
        while name.casefold() in used:
            suffix = f"_{counter}"
            name = f"{base[:31-len(suffix)]}{suffix}"
            counter += 1
        used.add(name.casefold())
        mapping[source] = name

    return mapping


def _read_existing_history(output_file: Path):
    """Read column order and prior run blocks from an existing workbook."""
    history = {}
    if not output_file.exists():
        return history

    workbook = load_workbook(output_file, data_only=True, read_only=True)
    try:
        for worksheet in workbook.worksheets:
            if worksheet.max_row < 3 or worksheet.max_column < 5:
                continue
            if [worksheet.cell(2, 1).value, worksheet.cell(2, 2).value] != [
                "Serial Number", "Column Name"
            ]:
                continue

            column_order = [
                str(value)
                for value in (
                    worksheet.cell(row, 2).value
                    for row in range(3, worksheet.max_row + 1)
                )
                if value is not None
            ]

            blocks = []
            for start in range(3, worksheet.max_column + 1, 3):
                if start + 2 > worksheet.max_column:
                    break
                title = worksheet.cell(1, start).value
                if not title:
                    continue

                values = {}
                for row, column_name in enumerate(column_order, start=3):
                    values[column_name] = {
                        "Total Rows": worksheet.cell(row, start).value,
                        "Populated Rows": worksheet.cell(row, start + 1).value,
                        "Populated Percentage": worksheet.cell(row, start + 2).value,
                    }
                blocks.append((str(title), values))

            history[worksheet.title] = {
                "column_order": column_order,
                "blocks": blocks,
            }
    finally:
        workbook.close()

    return history


def _append_new_columns(existing_columns, current_columns):
    """Preserve old order and append newly found columns at the end."""
    result = list(existing_columns)
    existing_lookup = {column.casefold() for column in result}

    for column in current_columns:
        if column.casefold() not in existing_lookup:
            result.append(column)
            existing_lookup.add(column.casefold())

    return result


def _write_workbook(
    output_file: Path,
    summaries,
    history,
    sheet_names,
    run_title: str,
):
    """Create a new workbook or fully rewrite the existing workbook."""
    workbook = Workbook()
    workbook.remove(workbook.active)

    blue_fill = PatternFill("solid", fgColor="1F4E78")
    white_bold = Font(color="FFFFFF", bold=True)

    for source, summary in summaries.items():
        sheet_name = sheet_names[source]
        worksheet = workbook.create_sheet(sheet_name)
        worksheet.sheet_view.showGridLines = False
        worksheet.freeze_panes = "C3"

        prior = history.get(sheet_name, {"column_order": [], "blocks": []})
        current_columns = summary["Column Name"].astype(str).tolist()
        column_order = _append_new_columns(prior["column_order"], current_columns)

        current_values = (
            summary.set_index("Column Name")
            [["Total Rows", "Populated Rows", "Populated Percentage"]]
            .to_dict("index")
        )
        blocks = prior["blocks"] + [(run_title, current_values)]

        worksheet.cell(2, 1, "Serial Number")
        worksheet.cell(2, 2, "Column Name")

        for row, column_name in enumerate(column_order, start=3):
            worksheet.cell(row, 1, row - 2)
            worksheet.cell(row, 2, column_name)

        for block_number, (title, values) in enumerate(blocks):
            start = 3 + block_number * 3
            worksheet.merge_cells(start_row=1, start_column=start, end_row=1, end_column=start + 2)
            worksheet.cell(1, start, title).alignment = Alignment(
                horizontal="center", vertical="center"
            )
            worksheet.cell(2, start, "Total Rows")
            worksheet.cell(2, start + 1, "Populated Rows")
            worksheet.cell(2, start + 2, "Populated Percentage")

            for row, column_name in enumerate(column_order, start=3):
                item = values.get(column_name, {})
                worksheet.cell(row, start, item.get("Total Rows"))
                worksheet.cell(row, start + 1, item.get("Populated Rows"))
                percentage = worksheet.cell(row, start + 2, item.get("Populated Percentage"))
                percentage.number_format = "0.0%"

            if column_order:
                letter = get_column_letter(start + 2)
                worksheet.conditional_formatting.add(
                    f"{letter}3:{letter}{len(column_order)+2}",
                    ColorScaleRule(
                        start_type="min", start_color="F8696B",
                        mid_type="percentile", mid_value=50, mid_color="FFEB84",
                        end_type="max", end_color="63BE7B",
                    ),
                )

        for cell in worksheet[2]:
            cell.fill = blue_fill
            cell.font = white_bold
            cell.alignment = Alignment(horizontal="center", vertical="center")

        worksheet.row_dimensions[2].height = 25
        worksheet.column_dimensions["A"].width = 15
        worksheet.column_dimensions["B"].width = 45
        for column in range(3, worksheet.max_column + 1):
            worksheet.column_dimensions[get_column_letter(column)].width = 22

        worksheet.auto_filter.ref = (
            f"A2:{get_column_letter(worksheet.max_column)}{len(column_order)+2}"
        )

    output_file.parent.mkdir(parents=True, exist_ok=True)
    try:
        workbook.save(output_file)
    except PermissionError as error:
        raise PermissionError(
            f"Close the existing output workbook and rerun: {output_file}"
        ) from error


def dataframe_completeness_by_source(
    data: pd.DataFrame,
    output_file: PathLike,
    sources: Optional[Union[str, Iterable[str]]] = None,
    source_column: Optional[str] = "Source",
    run_datetime: Optional[datetime] = None,
):
    """
    Create or update completeness history using an already-loaded DataFrame.

    One sheet is created for each unique nonblank source. If the source column
    is blank, missing, or entirely blank, one All Data sheet is created.
    New DataFrame columns are appended after existing column names.
    """
    if not isinstance(data, pd.DataFrame):
        raise TypeError("data must be a pandas DataFrame.")
    if data.empty:
        raise ValueError("The input DataFrame is empty.")

    output_file = Path(output_file)
    groups = _resolve_sources(data, source_column, sources)
    sheet_names = _safe_sheet_names(groups)

    summaries = {}
    for source, mask in groups.items():
        source_data = data.loc[mask]
        if source_data.empty:
            raise ValueError(f"No rows found for source: {source!r}")
        summaries[source] = create_column_summary(source_data)

    history = _read_existing_history(output_file)
    run_title = (run_datetime or datetime.now()).strftime("%Y-%m-%d %H:%M:%S")

    _write_workbook(output_file, summaries, history, sheet_names, run_title)

    print(f"Output file: {output_file.resolve()}")
    print(f"Run: {run_title}")
    for source, summary in summaries.items():
        total_rows = int(summary["Total Rows"].iloc[0])
        print(f"{source}: {total_rows:,} rows, sheet={sheet_names[source]}")

    return {
        "summaries": summaries,
        "run_datetime": run_title,
        "output_file": output_file,
    }
