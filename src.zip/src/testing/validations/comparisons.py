"""Comparison validation utilities with step-level logging.

Updated requirement:
For current-vs-previous comparison, use only these fields from both tables:
- Source
- Employee Country
- Report Extract Date
- Expense ID
- Approved Amount

Output contains exactly 6 business columns:
- Employee country
- report extract date
- expense id
- prev amt
- curr amt
- diff

Excel output date handling:
- report extract date is written as a real Excel date
- Excel number format is mm-dd-yyyy
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Sequence

import pandas as pd
from openpyxl import load_workbook
from openpyxl.formatting.rule import Rule
from openpyxl.styles import Font, PatternFill
from openpyxl.styles.differential import DifferentialStyle
from openpyxl.utils import get_column_letter

logger = logging.getLogger(__name__)

DEFAULT_OUTPUT_FILE = "Comparison_Report.xlsx"
DEFAULT_MATRIX_SHEET = "Amount Diff"
DEFAULT_EXPENSE_DIFF_SHEET = "Expense Level Diff"
DEFAULT_SUMMARY_SHEET = "Summary"
EXCEL_MAX_ROWS = 1_048_576

OUTPUT_COLUMNS_6 = [
    "Employee country",
    "report extract date",
    "expense id",
    "prev amt",
    "curr amt",
    "diff",
]

DATE_OUTPUT_COL = "report extract date"
EXCEL_DATE_FORMAT = "mm-dd-yyyy"
CSV_DATE_FORMAT = "%m-%d-%Y"


def _log_step(step: str, level: int = logging.INFO, **details: Any) -> None:
    """Write one structured comparison log event only when enabled."""
    if not logger.isEnabledFor(level):
        return
    if details:
        detail_text = " | ".join(f"{key}={value}" for key, value in details.items())
        logger.log(level, "%s | %s", step, detail_text)
    else:
        logger.log(level, "%s", step)


def _to_path(path: str | Path, name: str) -> Path:
    if path is None or str(path).strip() == "":
        _log_step("Path validation failed", logging.ERROR, parameter=name, value=path)
        raise ValueError(f"{name} cannot be empty")
    return Path(path)


def _normalise_columns(columns: Sequence[str] | str | None) -> list[str]:
    if columns is None:
        return []
    if isinstance(columns, str):
        return [columns]
    return [str(column) for column in columns]


def _require_columns(df: pd.DataFrame, columns: Sequence[str], context: str) -> None:
    missing = [column for column in columns if column not in df.columns]
    if missing:
        _log_step("Required-column validation failed", logging.ERROR, context=context, missing_columns=missing)
        raise KeyError(f"Missing required column(s) in {context}: {missing}")


def _safe_filename(value: Any) -> str:
    text = "Unknown" if value is None or pd.isna(value) or str(value).strip() == "" else str(value).strip()
    return "".join("_" if char in '<>:"/\\|?*' else char for char in text).strip() or "Unknown"


def _autosize_and_style(path: Path, negative_positive_cols: Sequence[str] | None = None) -> None:
    """Apply formatting to every sheet and format report extract date as mm-dd-yyyy."""
    wb = load_workbook(path)
    negative_positive_cols = set(negative_positive_cols or [])

    header_fill = PatternFill(fill_type="solid", start_color="4F81BD", end_color="4F81BD")
    header_font = Font(bold=True, color="FFFFFF")
    positive_fill = PatternFill(fill_type="solid", start_color="E2F0D9", end_color="E2F0D9")
    negative_fill = PatternFill(fill_type="solid", start_color="FCE4D6", end_color="FCE4D6")

    for ws in wb.worksheets:
        if ws.max_row == 0:
            continue

        for cell in ws[1]:
            cell.fill = header_fill
            cell.font = header_font

        ws.freeze_panes = "A2"
        ws.auto_filter.ref = ws.dimensions

        header_map = {cell.value: idx for idx, cell in enumerate(ws[1], start=1)}

        # Format report extract date as real Excel date display mm-dd-yyyy.
        if DATE_OUTPUT_COL in header_map and ws.max_row > 1:
            date_col_letter = get_column_letter(header_map[DATE_OUTPUT_COL])
            for row_idx in range(2, ws.max_row + 1):
                ws[f"{date_col_letter}{row_idx}"].number_format = EXCEL_DATE_FORMAT

        for col_name in negative_positive_cols:
            if col_name in header_map and ws.max_row > 1:
                col_letter = get_column_letter(header_map[col_name])

                positive_rule = Rule(type="expression", dxf=DifferentialStyle(fill=positive_fill))
                positive_rule.formula = [f"${col_letter}2>0"]
                ws.conditional_formatting.add(f"{col_letter}2:{col_letter}{ws.max_row}", positive_rule)

                negative_rule = Rule(type="expression", dxf=DifferentialStyle(fill=negative_fill))
                negative_rule.formula = [f"${col_letter}2<0"]
                ws.conditional_formatting.add(f"{col_letter}2:{col_letter}{ws.max_row}", negative_rule)

        for column_cells in ws.columns:
            column_letter = get_column_letter(column_cells[0].column)
            max_length = 0
            for cell in column_cells[:500]:
                value = "" if cell.value is None else str(cell.value)
                max_length = max(max_length, len(value))
            ws.column_dimensions[column_letter].width = min(max(max_length + 2, 12), 60)

    wb.save(path)


def _standardise_report_extract_date(series: pd.Series) -> pd.Series:
    """Standardise report extract date as pandas datetime for grouping/export."""
    return pd.to_datetime(series, errors="coerce").dt.normalize()


def _prepare_minimal_table(
    df: pd.DataFrame,
    source_col: str,
    country_col: str,
    report_extract_date_col: str,
    expense_id_col: str,
    amount_col: str,
    amount_output_col: str,
    source: str | None = None,
) -> pd.DataFrame:
    """Filter, keep only required columns, standardise keys, and aggregate amount."""
    required = [source_col, country_col, report_extract_date_col, expense_id_col, amount_col]
    _require_columns(df, required, f"prepare_minimal_table {amount_output_col}")

    work = df.loc[:, required].copy()
    if source is not None:
        work = work[work[source_col].astype("string").str.strip().eq(str(source).strip())].copy()

    work["Employee country"] = work[country_col].astype("string").str.strip()
    work[DATE_OUTPUT_COL] = _standardise_report_extract_date(work[report_extract_date_col])
    work["expense id"] = work[expense_id_col].astype("string").str.replace(",", "", regex=False).str.strip()
    work[amount_output_col] = pd.to_numeric(work[amount_col], errors="coerce").fillna(0)

    before = len(work)
    work = work[
        work["Employee country"].notna()
        & work[DATE_OUTPUT_COL].notna()
        & work["expense id"].notna()
        & work["expense id"].ne("")
    ].copy()

    grouped = (
        work.groupby(["Employee country", DATE_OUTPUT_COL, "expense id"], dropna=False)[amount_output_col]
        .sum()
        .reset_index()
    )

    _log_step(
        "Minimal comparison table prepared",
        source=source,
        amount_output_col=amount_output_col,
        input_rows=before,
        usable_rows=len(work),
        grouped_rows=len(grouped),
    )
    return grouped


def build_current_previous_amount_diff(
    current_df: pd.DataFrame,
    previous_df: pd.DataFrame,
    source: str | None = None,
    source_col: str = "Source",
    country_col: str = "Employee Country",
    report_extract_date_col: str = "Report Extract Date",
    expense_id_col: str = "Expense ID",
    amount_col: str = "Approved Amount",
) -> pd.DataFrame:
    """Return six-column current-vs-previous amount diff for one source or all sources."""
    _log_step(
        "Current previous amount diff build started",
        source=source,
        current_rows=len(current_df),
        previous_rows=len(previous_df),
    )

    current = _prepare_minimal_table(
        current_df,
        source_col=source_col,
        country_col=country_col,
        report_extract_date_col=report_extract_date_col,
        expense_id_col=expense_id_col,
        amount_col=amount_col,
        amount_output_col="curr amt",
        source=source,
    )
    previous = _prepare_minimal_table(
        previous_df,
        source_col=source_col,
        country_col=country_col,
        report_extract_date_col=report_extract_date_col,
        expense_id_col=expense_id_col,
        amount_col=amount_col,
        amount_output_col="prev amt",
        source=source,
    )

    result = previous.merge(
        current,
        on=["Employee country", DATE_OUTPUT_COL, "expense id"],
        how="outer",
    )
    result["prev amt"] = pd.to_numeric(result["prev amt"], errors="coerce").fillna(0)
    result["curr amt"] = pd.to_numeric(result["curr amt"], errors="coerce").fillna(0)
    result["diff"] = result["curr amt"] - result["prev amt"]

    result = result[OUTPUT_COLUMNS_6].sort_values(
        ["Employee country", DATE_OUTPUT_COL, "expense id"],
        kind="stable",
    ).reset_index(drop=True)

    _log_step(
        "Current previous amount diff build completed",
        source=source,
        output_rows=len(result),
        prev_total=float(result["prev amt"].sum()),
        curr_total=float(result["curr amt"].sum()),
        diff_total=float(result["diff"].sum()),
    )
    return result


def _prepare_for_export(diff_df: pd.DataFrame, for_csv: bool = False) -> pd.DataFrame:
    """Prepare date column for Excel or CSV export."""
    out = diff_df.copy()
    if DATE_OUTPUT_COL in out.columns:
        parsed = pd.to_datetime(out[DATE_OUTPUT_COL], errors="coerce")
        if for_csv:
            out[DATE_OUTPUT_COL] = parsed.dt.strftime(CSV_DATE_FORMAT)
        else:
            out[DATE_OUTPUT_COL] = parsed
    return out


def save_amount_diff_to_excel_or_csv(diff_df: pd.DataFrame, output_file: str | Path, sheet_name: str = "Amount Diff") -> Path:
    """Save six-column comparison output. Excel date column is formatted mm-dd-yyyy."""
    output_file = _to_path(output_file, "output_file")
    output_file.parent.mkdir(parents=True, exist_ok=True)
    sheet_name = sheet_name[:31]

    if len(diff_df) + 1 > EXCEL_MAX_ROWS:
        csv_path = output_file.with_suffix(".csv")
        csv_df = _prepare_for_export(diff_df, for_csv=True)
        csv_df.to_csv(csv_path, index=False, encoding="utf-8-sig")
        _log_step(
            "Amount diff saved as CSV because Excel row limit would be exceeded",
            logging.WARNING,
            output_file=csv_path,
            rows=len(diff_df),
        )
        return csv_path

    try:
        export_df = _prepare_for_export(diff_df, for_csv=False)
        with pd.ExcelWriter(output_file, engine="openpyxl", mode="w", datetime_format=EXCEL_DATE_FORMAT) as writer:
            export_df.to_excel(writer, index=False, sheet_name=sheet_name)
        _autosize_and_style(output_file, negative_positive_cols=["diff"])
    except Exception as exc:
        _log_step("Amount diff save failed", logging.ERROR, output_file=output_file, error_type=type(exc).__name__, error_message=str(exc))
        raise

    _log_step("Amount diff saved", output_file=output_file, sheet_name=sheet_name, rows=len(diff_df), date_format=EXCEL_DATE_FORMAT)
    return output_file


def compare_and_export_amount_diff(
    current_df: pd.DataFrame,
    previous_df: pd.DataFrame,
    output_file,
    index_cols: Sequence[str] | str | None = None,
    value_col: str = "Approved Amount",
    key_cols: Sequence[str] | str | None = None,
    columns_to_keep: Sequence[str] | str | None = None,
    current_label: str = "Current",
    previous_label: str = "Previous",
    source: str | None = None,
    source_col: str = "Source",
    country_col: str = "Employee Country",
    report_extract_date_col: str = "Report Extract Date",
    expense_id_col: str = "Expense ID",
) -> Path:
    """Compatibility wrapper. Creates only the six required comparison columns."""
    _log_step("Amount comparison export started", output_file=output_file, source=source, value_col=value_col)
    diff_df = build_current_previous_amount_diff(
        current_df=current_df,
        previous_df=previous_df,
        source=source,
        source_col=source_col,
        country_col=country_col,
        report_extract_date_col=report_extract_date_col,
        expense_id_col=expense_id_col,
        amount_col=value_col,
    )
    path = save_amount_diff_to_excel_or_csv(diff_df, output_file, sheet_name=DEFAULT_MATRIX_SHEET)
    _log_step("Amount comparison export completed", output_file=path, rows=len(diff_df))
    return path


def build_pct_diff_matrix(
    current_df: pd.DataFrame,
    previous_df: pd.DataFrame,
    index_cols: Sequence[str] | str,
    value_col: str,
    current_label: str = "Current",
    previous_label: str = "Previous",
) -> pd.DataFrame:
    """Preserved wrapper for older calls."""
    return build_current_previous_amount_diff(
        current_df=current_df,
        previous_df=previous_df,
        amount_col=value_col,
    )


def build_expense_level_diff_file(
    current_df: pd.DataFrame,
    previous_df: pd.DataFrame,
    key_cols: Sequence[str] | str = "Expense ID",
    value_col: str = "Approved Amount",
    columns_to_keep: Sequence[str] | str | None = None,
    current_label: str = "Current",
    previous_label: str = "Previous",
) -> pd.DataFrame:
    """Preserved wrapper for older calls."""
    return build_current_previous_amount_diff(
        current_df=current_df,
        previous_df=previous_df,
        amount_col=value_col,
    )


def save_matrix_to_excel(matrix_df: pd.DataFrame, output_file, sheet_name: str = DEFAULT_MATRIX_SHEET, mode: str = "w") -> Path:
    """Preserved save function. Saves matrix to Excel or CSV if too large."""
    return save_amount_diff_to_excel_or_csv(matrix_df, output_file, sheet_name=sheet_name)


def run_country_month_report_by_source(
    current_df: pd.DataFrame,
    previous_df: pd.DataFrame,
    output_folder,
    source_col: str = "Source",
    country_col: str = "Employee Country",
    month_col: str = "Report Extract Date",
    value_col: str = "Approved Amount",
    key_cols: Sequence[str] | str | None = "Expense ID",
    columns_to_keep: Sequence[str] | str | None = None,
) -> dict[str, Path]:
    """Create one six-column comparison output per source."""
    output_folder = _to_path(output_folder, "output_folder")
    output_folder.mkdir(parents=True, exist_ok=True)
    _log_step(
        "Source-wise six-column comparison started",
        output_folder=output_folder,
        source_col=source_col,
        country_col=country_col,
        report_extract_date_col=month_col,
        expense_id_col=key_cols,
        value_col=value_col,
    )

    expense_id_col = key_cols if isinstance(key_cols, str) and key_cols else "Expense ID"
    required = [source_col, country_col, month_col, expense_id_col, value_col]
    _require_columns(current_df, required, "run_country_month_report_by_source current_df")
    _require_columns(previous_df, required, "run_country_month_report_by_source previous_df")

    sources = sorted(
        set(current_df[source_col].dropna().astype(str).str.strip())
        | set(previous_df[source_col].dropna().astype(str).str.strip())
    )
    sources = [source for source in sources if source]
    _log_step("Source-wise comparison sources identified", source_count=len(sources), sources=sources)

    exported: dict[str, Path] = {}
    errors: dict[str, str] = {}

    for source in sources:
        safe_source = _safe_filename(source)
        output_file = output_folder / f"{safe_source}_Amount_Diff.xlsx"
        try:
            diff_df = build_current_previous_amount_diff(
                current_df=current_df,
                previous_df=previous_df,
                source=source,
                source_col=source_col,
                country_col=country_col,
                report_extract_date_col=month_col,
                expense_id_col=expense_id_col,
                amount_col=value_col,
            )
            exported[source] = save_amount_diff_to_excel_or_csv(diff_df, output_file, sheet_name="Amount Diff")
            _log_step("Source-wise comparison completed", source=source, rows=len(diff_df), output_file=exported[source])
        except Exception as exc:
            errors[source] = str(exc)
            _log_step("Source-wise comparison failed", logging.ERROR, source=source, error_type=type(exc).__name__, error_message=str(exc))

    if errors:
        _log_step("Source-wise comparison completed with errors", logging.ERROR, failed_source_count=len(errors), errors=errors)
        raise RuntimeError("Failed to create one or more source comparison reports:\n" + "\n".join(f"{k}: {v}" for k, v in errors.items()))

    _log_step("Source-wise six-column comparison completed", exported_count=len(exported), exported_sources=list(exported.keys()))
    return exported
