"""Fast validation error-log writer with common and source-specific config support.

Main functionality:
- If output/check column is blank/NA/missing-like
- Keep configured input columns
- Remove duplicate combinations
- Add optional occurrence count
- Populate Error Log.xlsx, one sheet per validation rule

Public functions:
- error_log
- run_error_logs_from_config
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Mapping, Sequence

import pandas as pd
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill
from openpyxl.utils import get_column_letter

logger = logging.getLogger(__name__)

DEFAULT_ERROR_LOG_FILE = "Error Log.xlsx"
MISSING_VALUES = {"", "nan", "none", "nat", "<na>", "missing value", "na", "n/a", "null"}


def _log_step(step: str, level: int = logging.INFO, **details: Any) -> None:
    """Light logging only when enabled."""
    if not logger.isEnabledFor(level):
        return

    if details:
        detail_text = " | ".join(f"{key}={value}" for key, value in details.items())
        logger.log(level, "%s | %s", step, detail_text)
    else:
        logger.log(level, "%s", step)


def _normalise_columns(columns: Sequence[str] | str | None) -> list[str]:
    if columns is None:
        return []
    if isinstance(columns, str):
        return [columns]
    return [str(column) for column in columns]


def _normalise_sources(sources: Sequence[str] | str | None) -> list[str] | None:
    if sources is None:
        return None
    if isinstance(sources, str):
        return [sources]
    return [str(source) for source in sources]


def _is_missing(series: pd.Series) -> pd.Series:
    """Blank / NaN / missing-like check."""
    return series.isna() | series.astype("string").str.strip().str.lower().isin(MISSING_VALUES)


def _safe_sheet_name(value: Any) -> str:
    text = "Error" if value is None or str(value).strip() == "" else str(value).strip()

    for char in [":", "\\", "/", "?", "*", "[", "]"]:
        text = text.replace(char, "_")

    return text[:31] or "Error"


def _autosize_and_style(file_path: Path) -> None:
    wb = load_workbook(file_path)

    header_fill = PatternFill(fill_type="solid", start_color="4F81BD", end_color="4F81BD")
    header_font = Font(bold=True, color="FFFFFF")

    for ws in wb.worksheets:
        if ws.max_row == 0:
            continue

        for cell in ws[1]:
            cell.fill = header_fill
            cell.font = header_font

        ws.freeze_panes = "A2"
        ws.auto_filter.ref = ws.dimensions

        for column_cells in ws.columns:
            col_letter = get_column_letter(column_cells[0].column)
            max_len = 0

            for cell in column_cells[:500]:
                value = "" if cell.value is None else str(cell.value)
                max_len = max(max_len, len(value))

            ws.column_dimensions[col_letter].width = min(max(max_len + 2, 12), 60)

    wb.save(file_path)


def _build_error_df(
    df: pd.DataFrame,
    columns_to_keep: Sequence[str] | str | None,
    check_column: str,
    output_sheet_name: str,
    source_col: str = "Source",
    sources: Sequence[str] | str | None = None,
    add_occurrence_count: bool = True,
) -> pd.DataFrame:
    """Build unique error-log table for one validation rule."""
    if check_column not in df.columns:
        _log_step(
            "Error rule skipped",
            logging.WARNING,
            reason="check_column missing",
            check_column=check_column,
        )
        return pd.DataFrame()

    work = df
    source_values = _normalise_sources(sources)

    # Source-specific filtering
    if source_values is not None:
        if source_col not in df.columns:
            _log_step(
                "Source-specific error rule skipped",
                logging.WARNING,
                reason="source_col missing",
                source_col=source_col,
                check_column=check_column,
                sources=source_values,
            )
            return pd.DataFrame()

        source_lookup = {str(source).strip().lower() for source in source_values}
        work = df[
            df[source_col]
            .astype("string")
            .str.strip()
            .str.lower()
            .isin(source_lookup)
        ]

    if work.empty:
        return pd.DataFrame()

    # Filter rows where output/check column is blank
    mask = _is_missing(work[check_column])
    error_rows = work.loc[mask].copy()

    if error_rows.empty:
        return pd.DataFrame()

    keep_columns = _normalise_columns(columns_to_keep)

    # Keep only configured input columns that exist
    output_columns = [col for col in keep_columns if col in error_rows.columns]

    # Keep Source if available and not already present
    if source_col in error_rows.columns and source_col not in output_columns:
        output_columns.insert(0, source_col)
    elif "Source" in error_rows.columns and "Source" not in output_columns:
        output_columns.insert(0, "Source")

    # Include check column at end for visibility
    if check_column not in output_columns:
        output_columns.append(check_column)

    if not output_columns:
        output_columns = [check_column]

    error_df = error_rows.loc[:, output_columns].copy()

    # Normalize values before duplicate removal
    for col in error_df.columns:
        error_df[col] = error_df[col].astype("string").fillna("").str.strip()

    if add_occurrence_count:
        error_df = (
            error_df
            .groupby(output_columns, dropna=False)
            .size()
            .reset_index(name="Occurrence Count")
        )
    else:
        error_df = error_df.drop_duplicates().reset_index(drop=True)

    return error_df


def error_log(
    df: pd.DataFrame,
    folder_path,
    columns_to_keep: Sequence[str] | str | None,
    check_column: str,
    output_sheet_name: str = "Error",
    file_name: str = DEFAULT_ERROR_LOG_FILE,
    source_col: str = "Source",
    sources: Sequence[str] | str | None = None,
    add_occurrence_count: bool = True,
) -> Path | None:
    """Create/update one sheet in Error Log.xlsx.

    Main functionality:
    - If check_column is blank/NA
    - Keep input columns
    - Remove duplicates
    - Write to sheet
    """
    _log_step(
        "Error log started",
        rows=len(df),
        check_column=check_column,
        output_sheet_name=output_sheet_name,
        sources=sources or "All Sources",
    )

    if not isinstance(df, pd.DataFrame):
        raise TypeError("df must be a pandas DataFrame")

    folder_path = Path(folder_path)
    folder_path.mkdir(parents=True, exist_ok=True)

    file_path = folder_path / file_name
    sheet_name = _safe_sheet_name(output_sheet_name)

    error_df = _build_error_df(
        df=df,
        columns_to_keep=columns_to_keep,
        check_column=check_column,
        output_sheet_name=output_sheet_name,
        source_col=source_col,
        sources=sources,
        add_occurrence_count=add_occurrence_count,
    )

    if error_df.empty:
        _log_step(
            "Error log completed",
            reason="No error rows found",
            output_sheet_name=sheet_name,
        )
        return None

    # Load existing workbook or create new
    if file_path.exists():
        workbook = load_workbook(file_path)
    else:
        workbook = Workbook()
        if workbook.active.title == "Sheet":
            workbook.remove(workbook.active)

    # Replace sheet if exists
    if sheet_name in workbook.sheetnames:
        worksheet = workbook[sheet_name]
        workbook.remove(worksheet)

    ws = workbook.create_sheet(sheet_name)

    # Write header
    ws.append(error_df.columns.tolist())

    # Write rows
    for row in error_df.itertuples(index=False, name=None):
        ws.append(row)

    workbook.save(file_path)
    _autosize_and_style(file_path)

    _log_step(
        "Error log completed",
        output_path=file_path,
        sheet_name=sheet_name,
        unique_error_rows=len(error_df),
    )

    return file_path


def run_error_logs_from_config(
    df: pd.DataFrame,
    error_config: Mapping[str, Mapping[str, Any]],
    folder_path,
    file_name: str = DEFAULT_ERROR_LOG_FILE,
    source_col: str = "Source",
    add_occurrence_count: bool = True,
) -> Path | None:
    """Run all ERROR_CONFIG checks and write Error Log.xlsx once.

    Better than calling error_log in a loop because this keeps the logic centralized.
    """
    _log_step("Batch error log started", rows=len(df), checks=len(error_config))

    if not isinstance(df, pd.DataFrame):
        raise TypeError("df must be a pandas DataFrame")

    folder_path = Path(folder_path)
    folder_path.mkdir(parents=True, exist_ok=True)

    file_path = folder_path / file_name

    workbook = Workbook()
    if workbook.active.title == "Sheet":
        workbook.remove(workbook.active)

    created_sheets = 0
    skipped = {}

    for config_key, config in error_config.items():
        input_columns = config.get("input_columns", [])
        output_column = config.get("output_column")
        sources = config.get("sources", config.get("source"))
        sheet_name = _safe_sheet_name(config.get("sheet_name", config_key))

        if not output_column:
            skipped[config_key] = "output_column missing"
            continue

        error_df = _build_error_df(
            df=df,
            columns_to_keep=input_columns,
            check_column=output_column,
            output_sheet_name=config_key,
            source_col=source_col,
            sources=sources,
            add_occurrence_count=add_occurrence_count,
        )

        if error_df.empty:
            skipped[config_key] = "no error rows"
            continue

        ws = workbook.create_sheet(sheet_name)
        ws.append(error_df.columns.tolist())

        for row in error_df.itertuples(index=False, name=None):
            ws.append(row)

        created_sheets += 1

        _log_step(
            "Error log sheet created",
            sheet_name=sheet_name,
            rows=len(error_df),
            sources=sources or "All Sources",
        )

    if created_sheets == 0:
        _log_step("Batch error log completed", reason="No error sheets created", skipped=skipped)
        return None

    workbook.save(file_path)
    _autosize_and_style(file_path)

    _log_step(
        "Batch error log completed",
        output_path=file_path,
        sheet_count=created_sheets,
        skipped=skipped,
    )

    return file_path
