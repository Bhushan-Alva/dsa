from pathlib import Path
from typing import Any, Dict, List, Union
import os
import shutil
import tempfile
import numpy as np
import pandas as pd

PathLike = Union[str, Path]
VALUE_COLUMNS = ["Usage Input", "Cost in EUR", "Emissions Generated"]
BASE_KEYS = [
    "Employee Project Code", "Project GBL", "Project Details",
    "Project Unit Info", "Market Unit", "Text 7",
]
SHEET_KEYS = {
    "Project Code Comparison": BASE_KEYS,
    "Project Code + Source": BASE_KEYS + ["Source"],
    "Project Code + Source + ID": BASE_KEYS + ["Source", "Expense ID"],
}
TOOL_NAMES = {
    "Usage Input": "Tool_Total_Usage",
    "Cost in EUR": "Tool_Total_Cost",
    "Emissions Generated": "Tool_Total_Emissions",
}
PROCESSED_NAMES = {
    "Usage Input": "Processed_Total_Usage",
    "Cost in EUR": "Processed_Total_Cost",
    "Emissions Generated": "Processed_Total_Emissions",
}


def _excel_column_letter(index: int) -> str:
    index += 1
    result = ""
    while index:
        index, remainder = divmod(index - 1, 26)
        result = chr(65 + remainder) + result
    return result


def generate_excel(
    data: Any,
    output_path: PathLike,
    output_file: str,
    sheet_name: str = "Data",
    header_freeze: bool = True,
    header_bold: bool = True,
    border: bool = True,
    header_bg_colour: str = "0000FF",
    header_color: str = "FFFFFF",
    column_autofit: bool = True,
    max_column_width: int = 50,
    add_filter: bool = True,
):
    """Write all DataFrames correctly, then move the closed file to output."""
    output_path = Path(output_path)
    output_path.mkdir(parents=True, exist_ok=True)
    final_file = output_path / output_file
    sheets = data if isinstance(data, dict) else {sheet_name: data}

    fd, temp_name = tempfile.mkstemp(prefix="project_comparison_", suffix=".xlsx")
    os.close(fd)
    temp_file = Path(temp_name)
    temp_file.unlink(missing_ok=True)

    try:
        # Do not enable constant_memory. Pandas writes DataFrames column-wise,
        # while XlsxWriter constant_memory requires strict row-wise writes.
        with pd.ExcelWriter(
            temp_file,
            engine="xlsxwriter",
            engine_kwargs={"options": {
                "strings_to_urls": False,
                "nan_inf_to_errors": True,
            }},
        ) as writer:
            workbook = writer.book
            workbook.use_zip64()
            header_format = workbook.add_format({
                "bold": header_bold,
                "font_color": f"#{header_color}",
                "bg_color": f"#{header_bg_colour}",
                "align": "center",
                "valign": "vcenter",
                "border": 1 if border else 0,
            })
            number_format = workbook.add_format({
                "num_format": "#,##0.000000;[Red](#,##0.000000);-"
            })
            decrease_format = workbook.add_format({
                "bg_color": "#FFC7CE", "font_color": "#9C0006"
            })
            missing_format = workbook.add_format({
                "bg_color": "#F4CCCC", "font_color": "#9C0006"
            })
            numeric_columns = {
                "Tool_Total_Usage", "Tool_Total_Cost", "Tool_Total_Emissions",
                "Processed_Total_Usage", "Processed_Total_Cost",
                "Processed_Total_Emissions", "Usage_Difference",
                "Cost_Difference", "Emissions_Difference",
            }
            fixed_widths = {
                "Employee Project Code": 24, "Project GBL": 28,
                "Project Details": 45, "Project Unit Info": 45,
                "Market Unit": 35, "Text 7": 30, "Source": 20,
                "Expense ID": 18, "_merge": 18, "compare_df_Status": 24,
            }

            for name, frame in sheets.items():
                frame = frame if isinstance(frame, pd.DataFrame) else pd.DataFrame(frame)
                safe_name = str(name)[:31]

                # Let pandas write both headers and all values in one operation.
                frame.to_excel(writer, sheet_name=safe_name, index=False)
                worksheet = writer.sheets[safe_name]
                row_count, column_count = frame.shape

                # Rewrite only the header cells to apply header formatting.
                for column_index, column_name in enumerate(frame.columns):
                    worksheet.write(0, column_index, column_name, header_format)
                    width = None
                    if column_autofit:
                        width = fixed_widths.get(
                            column_name,
                            min(max(len(str(column_name)) + 2, 14), max_column_width),
                        )
                    worksheet.set_column(
                        column_index,
                        column_index,
                        width,
                        number_format if column_name in numeric_columns else None,
                    )

                if header_freeze:
                    worksheet.freeze_panes(1, 0)
                if add_filter and column_count:
                    worksheet.autofilter(0, 0, row_count, column_count - 1)
                worksheet.hide_gridlines(2)

                if row_count and "compare_df_Status" in frame.columns:
                    status_letter = _excel_column_letter(
                        frame.columns.get_loc("compare_df_Status")
                    )
                    target_range = (1, 0, row_count, column_count - 1)
                    worksheet.conditional_format(*target_range, {
                        "type": "formula",
                        "criteria": f'=${status_letter}2="DECREASE"',
                        "format": decrease_format,
                    })
                    worksheet.conditional_format(*target_range, {
                        "type": "formula",
                        "criteria": f'=${status_letter}2="MISSING_IN_PROCESSED"',
                        "format": missing_format,
                    })

        if final_file.exists():
            try:
                final_file.unlink()
            except PermissionError as exc:
                raise PermissionError(
                    f"Close the existing workbook in Excel and retry: {final_file}"
                ) from exc
        shutil.move(str(temp_file), str(final_file))
        return final_file
    except Exception:
        temp_file.unlink(missing_ok=True)
        raise


def _validate_columns(frame: pd.DataFrame, columns: List[str], name: str) -> None:
    missing = [column for column in columns if column not in frame.columns]
    if missing:
        raise KeyError(f"Missing columns in {name}: {missing}")


def _select_filtered_columns(
    frame: pd.DataFrame,
    data_source: str,
    candidate_columns: List[str],
    required_columns: List[str],
) -> pd.DataFrame:
    filter_column = next((c for c in candidate_columns if c in frame.columns), None)
    if filter_column is None:
        return frame.loc[:, required_columns].copy()
    wanted = str(data_source).strip().casefold()
    source = frame[filter_column]
    mask = source.notna() & source.astype("string").str.strip().str.casefold().eq(wanted)
    return frame.loc[mask, required_columns].copy()


def _prepare(frame: pd.DataFrame, keys: List[str]) -> pd.DataFrame:
    for column in keys:
        frame[column] = frame[column].astype("string").fillna("").str.strip()
    for column in VALUE_COLUMNS:
        frame[column] = pd.to_numeric(frame[column], errors="coerce").fillna(0)
    return frame.loc[frame["Employee Project Code"].ne("")]


def _aggregate(frame: pd.DataFrame, keys: List[str], names: Dict[str, str]) -> pd.DataFrame:
    return (
        frame.groupby(
            keys, dropna=False, as_index=False, sort=False, observed=True
        )[VALUE_COLUMNS]
        .sum()
        .rename(columns=names)
    )


def _build_comparison(
    tool: pd.DataFrame,
    processed: pd.DataFrame,
    keys: List[str],
    tolerance: float,
) -> pd.DataFrame:
    tool_summary = _aggregate(tool, keys, TOOL_NAMES)
    processed_summary = _aggregate(processed, keys, PROCESSED_NAMES)

    comparison = tool_summary.merge(
        processed_summary,
        on=keys,
        how="outer",
        indicator=True,
        sort=False,
        copy=False,
    )

    totals = list(TOOL_NAMES.values()) + list(PROCESSED_NAMES.values())

    # Explicitly convert total columns to regular float64.
    # This avoids pandas nullable dtypes being passed into np.select.
    comparison[totals] = (
        comparison[totals]
        .apply(pd.to_numeric, errors="coerce")
        .fillna(0.0)
        .astype("float64")
    )

    comparison["Usage_Difference"] = (
        comparison["Processed_Total_Usage"]
        - comparison["Tool_Total_Usage"]
    )

    comparison["Cost_Difference"] = (
        comparison["Processed_Total_Cost"]
        - comparison["Tool_Total_Cost"]
    )

    comparison["Emissions_Difference"] = (
        comparison["Processed_Total_Emissions"]
        - comparison["Tool_Total_Emissions"]
    )

    # Convert values to standard NumPy arrays.
    merge_status = comparison["_merge"].astype("string")

    cost = comparison["Cost_Difference"].to_numpy(
        dtype="float64",
        na_value=0.0,
    )

    conditions = [
        merge_status.eq("left_only").to_numpy(
            dtype=bool,
            na_value=False,
        ),
        merge_status.eq("right_only").to_numpy(
            dtype=bool,
            na_value=False,
        ),
        cost < -tolerance,
        np.abs(cost) <= tolerance,
        cost > tolerance,
    ]

    choices = [
        "MISSING_IN_PROCESSED",
        "NEW_IN_PROCESSED",
        "DECREASE",
        "MATCH",
        "INCREASE",
    ]

    # Status remains based only on cost.
    comparison["compare_df_Status"] = np.select(
        conditions,
        choices,
        default="CHECK",
    )

    output_columns = keys + totals + [
        "_merge",
        "Usage_Difference",
        "Cost_Difference",
        "Emissions_Difference",
        "compare_df_Status",
    ]

    return comparison.loc[:, output_columns].reset_index(drop=True)


def project_comparison(
    tool_extract: pd.DataFrame,
    data: pd.DataFrame,
    data_source: str,
    output_path: PathLike,
    tolerance: float = 1e-6,
) -> Dict[str, pd.DataFrame]:
    """Return three comparisons and generate the corrected Excel workbook."""
    required = BASE_KEYS + ["Source", "Expense ID"] + VALUE_COLUMNS
    _validate_columns(tool_extract, required + ["Team"], "tool_extract")
    _validate_columns(data, required, "data")

    tool = _select_filtered_columns(
        tool_extract, data_source, ["Team", "Data Source"], required
    )
    processed = _select_filtered_columns(
        data, data_source, ["Team", "Data Source"], required
    )
    if tool.empty:
        raise ValueError(f"No tool rows found for data_source={data_source!r}")
    if processed.empty:
        raise ValueError(f"No processed rows found for data_source={data_source!r}")

    all_keys = BASE_KEYS + ["Source", "Expense ID"]
    tool = _prepare(tool, all_keys)
    processed = _prepare(processed, all_keys)
    results = {
        sheet_name: _build_comparison(tool, processed, keys, tolerance)
        for sheet_name, keys in SHEET_KEYS.items()
    }

    file_path = generate_excel(
        data=results,
        output_path=output_path,
        output_file=f"{data_source}_Project_Comparison.xlsx",
        header_freeze=True,
        header_bold=True,
        border=False,
        header_bg_colour="1F4E78",
        header_color="FFFFFF",
        column_autofit=True,
        max_column_width=50,
        add_filter=True,
    )
    print(f"Project comparison generated: {file_path}")
    return results
