"""Duplicate-check validation utility with light logging.

Public function:
- duplicate_check_export

Purpose:
Export selected columns to a duplicate-check workbook, remove duplicate rows,
and highlight duplicate values in the first duplicate/check column.

Notes:
- This preserves the original behavior more closely than the heavy updated version.
- It does not use pd.read_excel() to load an existing workbook, so it avoids
  BadZipFile errors caused by corrupted/invalid existing .xlsx files.
- If the existing workbook is invalid, it recreates it safely.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Sequence
from zipfile import BadZipFile

import pandas as pd
from openpyxl import Workbook, load_workbook
from openpyxl.formatting.rule import Rule
from openpyxl.styles import Font, PatternFill
from openpyxl.styles.differential import DifferentialStyle
from openpyxl.utils import get_column_letter

logger = logging.getLogger(__name__)

DEFAULT_DUPLICATE_FILE = "Duplicate_Check.xlsx"
DEFAULT_SHEET_NAME = "Duplicate Records"


def _log_step(step: str, level: int = logging.INFO, **details: Any) -> None:
    """Light structured logging only when enabled."""
    if not logger.isEnabledFor(level):
        return

    if details:
        detail_text = " | ".join(f"{key}={value}" for key, value in details.items())
        logger.log(level, "%s | %s", step, detail_text)
    else:
        logger.log(level, "%s", step)


def _normalise_columns(columns: Sequence[str] | str | None) -> list[str]:
    if columns is None:
        return []
    if isinstance(columns, str):
        return [columns]
    return [str(column) for column in columns]


def _safe_sheet_name(value: Any) -> str:
    sheet_name = "Data" if value is None or str(value).strip() == "" else str(value).strip()

    for char in [":", "\\", "/", "?", "*", "[", "]"]:
        sheet_name = sheet_name.replace(char, "_")

    return sheet_name[:31] or "Data"


def _load_or_create_workbook(file_path: Path) -> Workbook:
    """Load workbook if valid; create a new workbook if missing or invalid."""
    if not file_path.exists():
        wb = Workbook()
        if wb.active.title == "Sheet":
            wb.remove(wb.active)
        return wb

    try:
        return load_workbook(file_path)
    except (BadZipFile, KeyError, OSError, ValueError) as exc:
        _log_step(
            "Existing duplicate workbook invalid; recreating workbook",
            logging.WARNING,
            file_path=file_path,
            error_type=type(exc).__name__,
            error_message=str(exc),
        )
        wb = Workbook()
        if wb.active.title == "Sheet":
            wb.remove(wb.active)
        return wb


def _autosize_and_style(
    file_path: Path,
    sheet_name: str,
    highlight_column_name: str | None = None,
    highlight_color: str = "FFF3CD",
    max_col_width: int = 40,
) -> None:
    """Apply header style, freeze row, duplicate highlight, and auto-width."""
    wb = load_workbook(file_path)
    ws = wb[sheet_name]

    header_fill = PatternFill(fill_type="solid", start_color="4F81BD", end_color="4F81BD")
    header_font = Font(bold=True, color="FFFFFF")

    if ws.max_row >= 1:
        for cell in ws[1]:
            cell.fill = header_fill
            cell.font = header_font

    ws.freeze_panes = "A2"

    # Highlight duplicate values in the selected/highlight column.
    if highlight_column_name and ws.max_row > 1:
        header_map = {cell.value: idx for idx, cell in enumerate(ws[1], start=1)}

        if highlight_column_name in header_map:
            col_idx = header_map[highlight_column_name]
            col_letter = get_column_letter(col_idx)

            fill = PatternFill(
                start_color=highlight_color,
                end_color=highlight_color,
                fill_type="solid",
            )
            dxf = DifferentialStyle(fill=fill)
            rule = Rule(type="duplicateValues", dxf=dxf)

            ws.conditional_formatting.add(
                f"{col_letter}2:{col_letter}{ws.max_row}",
                rule,
            )

    # Auto-size columns.
    for column_cells in ws.columns:
        col_letter = get_column_letter(column_cells[0].column)
        max_length = 0

        for cell in column_cells:
            value = "" if cell.value is None else str(cell.value)
            max_length = max(max_length, len(value))

        ws.column_dimensions[col_letter].width = min(max(max_length + 2, 12), max_col_width)

    wb.save(file_path)


def duplicate_check_export(
    df: pd.DataFrame,
    folder_path,
    duplicate_columns: Sequence[str] | str,
    columns_to_keep: Sequence[str] | str | None = None,
    output_file_name: str = DEFAULT_DUPLICATE_FILE,
    output_sheet_name: str = DEFAULT_SHEET_NAME,
    keep: bool | str = False,
    append: bool = False,
    highlight_color: str = "FFF3CD",
    max_col_width: int = 40,
) -> Path | None:
    """Export duplicate-check data to Excel.

    Main behavior, aligned to your original function:
    1. Keep selected columns.
    2. Drop duplicate rows from selected columns.
    3. Export to Excel.
    4. Highlight duplicate values in the first duplicate/check column.
    5. Replace the target sheet if it already exists, unless append=True.

    Parameters
    ----------
    df : pandas.DataFrame
        Source dataframe.
    folder_path : str or Path
        Folder where the workbook should be saved.
    duplicate_columns : sequence[str] or str
        Columns used as duplicate keys. The first column is used for highlighting.
    columns_to_keep : sequence[str], str, or None
        Columns to include in output. If None, duplicate_columns are used.
    output_file_name : str
        Workbook filename.
    output_sheet_name : str
        Sheet name.
    keep : bool or {'first', 'last', False}
        Kept for backward compatibility. Not used in this original-style export.
    append : bool
        If True, appends rows to an existing sheet. If False, replaces the sheet.
    highlight_color : str
        Hex fill color for duplicate values.
    max_col_width : int
        Maximum Excel column width.

    Returns
    -------
    pathlib.Path | None
        Path to the workbook.
    """
    _log_step(
        "Duplicate check started",
        rows=len(df),
        columns=len(df.columns),
        output_sheet_name=output_sheet_name,
        append=append,
    )

    if not isinstance(df, pd.DataFrame):
        raise TypeError("df must be a pandas DataFrame")

    duplicate_columns = _normalise_columns(duplicate_columns)
    if not duplicate_columns:
        raise ValueError("duplicate_columns cannot be empty")

    missing_duplicate_columns = [column for column in duplicate_columns if column not in df.columns]
    if missing_duplicate_columns:
        raise KeyError(f"Missing duplicate/check column(s): {missing_duplicate_columns}")

    output_columns = _normalise_columns(columns_to_keep) or duplicate_columns.copy()

    missing_output_columns = [column for column in output_columns if column not in df.columns]
    if missing_output_columns:
        _log_step("Duplicate check output columns missing", logging.WARNING, missing_columns=missing_output_columns)

    output_columns = [column for column in output_columns if column in df.columns]
    if not output_columns:
        raise KeyError("None of the requested output columns exist in the DataFrame")

    highlight_column = duplicate_columns[0]
    if highlight_column not in output_columns:
        output_columns.insert(0, highlight_column)

    # Original-style output: selected columns + drop duplicate rows.
    df_out = df.loc[:, output_columns].drop_duplicates().copy()

    duplicate_found = df_out[highlight_column].duplicated(keep=False).any()
    duplicate_value_count = int(df_out[highlight_column].duplicated(keep=False).sum())

    folder = Path(folder_path)
    folder.mkdir(parents=True, exist_ok=True)

    file_path = folder / output_file_name
    sheet_name = _safe_sheet_name(output_sheet_name)

    workbook = _load_or_create_workbook(file_path)

    # Replace target sheet unless append=True.
    if sheet_name in workbook.sheetnames and not append:
        workbook.remove(workbook[sheet_name])

    if sheet_name in workbook.sheetnames and append:
        ws = workbook[sheet_name]
        # If appending to an empty sheet, add header.
        if ws.max_row == 1 and all(cell.value is None for cell in ws[1]):
            ws.append(df_out.columns.tolist())
    else:
        ws = workbook.create_sheet(sheet_name)
        ws.append(df_out.columns.tolist())

    for row in df_out.itertuples(index=False, name=None):
        ws.append(row)

    workbook.save(file_path)

    _autosize_and_style(
        file_path=file_path,
        sheet_name=sheet_name,
        highlight_column_name=highlight_column,
        highlight_color=highlight_color,
        max_col_width=max_col_width,
    )

    _log_step(
        "Duplicate check completed",
        output_path=file_path,
        sheet_name=sheet_name,
        output_rows=len(df_out),
        highlight_column=highlight_column,
        duplicate_found=bool(duplicate_found),
        duplicate_value_count=duplicate_value_count,
    )

    if duplicate_found:
        print(f"Saved: {file_path}")
        print("Duplicate records found")
    else:
        print(f"Saved: {file_path}")
        print("No Duplicate records found")

    return file_path
