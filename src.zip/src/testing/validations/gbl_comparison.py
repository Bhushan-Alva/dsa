import calendar
import re
from pathlib import Path
from typing import Any, Dict, Union

import pandas as pd
from openpyxl import Workbook, load_workbook
from openpyxl.formatting.rule import CellIsRule
from openpyxl.styles import Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

PathLike = Union[str, Path]

MONTH_ORDER = list(calendar.month_name)[1:]
METRICS = ["Usage Input", "Cost in EUR", "Emissions Generated"]
REQUIRED_COLUMNS = METRICS + ["Emp GBL", "Month", "Source"]


def generate_excel(
    data: Any,
    output_path: PathLike,
    output_file: str,
    sheet_name: str = "Data",
    header_freeze: bool = True,
    header_bold: bool = True,
    border: bool = True,
    header_bg_colour: str = "0000FF",
    header_color: str = "FFFFFF",
    column_autofit: bool = True,
    max_column_width: int = 50,
    add_filter: bool = True,
):
    """Write or replace one formatted sheet without deleting other sheets."""
    output_path = Path(output_path)
    output_path.mkdir(parents=True, exist_ok=True)
    file_path = output_path / output_file

    if not isinstance(data, pd.DataFrame):
        data = pd.DataFrame(data)

    if file_path.exists():
        workbook = load_workbook(file_path)
    else:
        workbook = Workbook()
        workbook.remove(workbook.active)

    safe_sheet_name = _safe_sheet_name(sheet_name)
    if safe_sheet_name in workbook.sheetnames:
        del workbook[safe_sheet_name]

    worksheet = workbook.create_sheet(safe_sheet_name)

    for column_number, column_name in enumerate(data.columns, start=1):
        cell = worksheet.cell(row=1, column=column_number, value=str(column_name))
        cell.font = Font(bold=header_bold, color=header_color)
        cell.fill = PatternFill("solid", fgColor=header_bg_colour)

    for row_number, row in enumerate(data.itertuples(index=False, name=None), start=2):
        for column_number, value in enumerate(row, start=1):
            worksheet.cell(
                row=row_number,
                column=column_number,
                value=None if pd.isna(value) else value,
            )

    if header_freeze:
        worksheet.freeze_panes = "A2"

    if add_filter and worksheet.max_column > 0:
        worksheet.auto_filter.ref = worksheet.dimensions

    if border:
        thin_gray = Side(style="thin", color="D9E1F2")
        cell_border = Border(
            left=thin_gray,
            right=thin_gray,
            top=thin_gray,
            bottom=thin_gray,
        )
        for row in worksheet.iter_rows(
            min_row=1,
            max_row=worksheet.max_row,
            min_col=1,
            max_col=worksheet.max_column,
        ):
            for cell in row:
                cell.border = cell_border

    for row in worksheet.iter_rows(
        min_row=2,
        max_row=worksheet.max_row,
        min_col=3,
        max_col=worksheet.max_column,
    ):
        for cell in row:
            if isinstance(cell.value, (int, float)):
                cell.number_format = '#,##0.00;[Red](#,##0.00);-'

    if column_autofit:
        for column_number in range(1, worksheet.max_column + 1):
            column_letter = get_column_letter(column_number)
            maximum_length = max(
                (
                    len(str(worksheet.cell(row=row_number, column=column_number).value))
                    if worksheet.cell(row=row_number, column=column_number).value is not None
                    else 0
                )
                for row_number in range(1, worksheet.max_row + 1)
            )
            worksheet.column_dimensions[column_letter].width = min(
                maximum_length + 2,
                max_column_width,
            )

    worksheet.sheet_view.showGridLines = False
    workbook.save(file_path)
    return file_path


def _safe_sheet_name(sheet_name: str) -> str:
    """Return a valid Excel sheet name of at most 31 characters."""
    cleaned = re.sub(r'[\\/*?:\[\]]', "_", str(sheet_name)).strip()
    return (cleaned or "Sheet")[:31]


def _standardize_month(month_series: pd.Series) -> pd.Series:
    """Convert month numbers or month text to full English month names."""
    text = month_series.astype("string").str.strip()
    numeric = pd.to_numeric(text, errors="coerce")
    from_number = numeric.map(dict(enumerate(MONTH_ORDER, start=1)))

    normalized_text = text.str[:3].str.title()
    abbreviation_map = {month[:3]: month for month in MONTH_ORDER}
    from_text = normalized_text.map(abbreviation_map)

    return from_number.fillna(from_text)


def _clean_input(frame: pd.DataFrame) -> pd.DataFrame:
    """Standardize dimensions and make comparison metrics numeric."""
    frame = frame.copy()
    frame["Month"] = _standardize_month(frame["Month"])
    frame["Emp GBL"] = frame["Emp GBL"].astype("string").fillna("").str.strip()
    frame["Source"] = frame["Source"].astype("string").fillna("").str.strip()

    for metric in METRICS:
        frame[metric] = pd.to_numeric(frame[metric], errors="coerce").fillna(0)

    return frame.loc[
        frame["Emp GBL"].ne("")
        & frame["Source"].ne("")
        & frame["Month"].isin(MONTH_ORDER)
    ].copy()


def _make_pivot(summary: pd.DataFrame) -> pd.DataFrame:
    """Create Emp GBL and Metric rows with month columns."""
    if summary.empty:
        return pd.DataFrame(columns=["Emp GBL", "Metric"] + MONTH_ORDER)

    long_data = summary.melt(
        id_vars=["Emp GBL", "Month"],
        value_vars=METRICS,
        var_name="Metric",
        value_name="Value",
    )

    pivot = long_data.pivot_table(
        index=["Emp GBL", "Metric"],
        columns="Month",
        values="Value",
        aggfunc="sum",
        fill_value=0,
    ).reindex(columns=MONTH_ORDER, fill_value=0)

    pivot = pivot.reset_index()
    pivot["Metric"] = pd.Categorical(
        pivot["Metric"],
        categories=METRICS,
        ordered=True,
    )
    pivot = pivot.sort_values(["Emp GBL", "Metric"]).reset_index(drop=True)
    pivot["Metric"] = pivot["Metric"].astype("string")
    return pivot


def _align_pivots(
    tool_pivot: pd.DataFrame,
    data_pivot: pd.DataFrame,
):
    """Align Tool and Data to the union of Emp GBL and Metric combinations."""
    tool_indexed = tool_pivot.set_index(["Emp GBL", "Metric"])
    data_indexed = data_pivot.set_index(["Emp GBL", "Metric"])
    combined_index = tool_indexed.index.union(data_indexed.index)

    tool_aligned = tool_indexed.reindex(
        index=combined_index,
        columns=MONTH_ORDER,
        fill_value=0,
    ).fillna(0)

    data_aligned = data_indexed.reindex(
        index=combined_index,
        columns=MONTH_ORDER,
        fill_value=0,
    ).fillna(0)

    difference = tool_aligned - data_aligned

    active_months = [
        month
        for month in MONTH_ORDER
        if (
            tool_aligned[month].ne(0).any()
            or data_aligned[month].ne(0).any()
            or difference[month].ne(0).any()
        )
    ]

    return (
        tool_aligned[active_months].reset_index(),
        data_aligned[active_months].reset_index(),
        difference[active_months].reset_index(),
    )


def _format_difference_sheet(file_path: PathLike, sheet_name: str) -> None:
    """Highlight non-zero differences on an existing difference sheet."""
    workbook = load_workbook(file_path)
    if sheet_name not in workbook.sheetnames:
        return

    worksheet = workbook[sheet_name]
    if worksheet.max_row < 2 or worksheet.max_column < 3:
        workbook.save(file_path)
        return

    numeric_range = (
        f"C2:{get_column_letter(worksheet.max_column)}{worksheet.max_row}"
    )

    worksheet.conditional_formatting.add(
        numeric_range,
        CellIsRule(
            operator="notEqual",
            formula=["0"],
            fill=PatternFill("solid", fgColor="FFC7CE"),
            font=Font(color="9C0006"),
        ),
    )
    workbook.save(file_path)


def gbl_comparison(
    tool_extract: pd.DataFrame,
    data: pd.DataFrame,
    data_source: str,
    output_path: PathLike,
) -> Dict[str, Dict[str, pd.DataFrame]]:
    """
    Create one workbook for a data source with Tool, Data and Difference
    sheets for every Source. Difference equals Tool Extract minus Data.

    data_source is applied only to tool_extract["Team"].
    No data_source filter is applied to processed data.
    """
    missing_tool = [
        column
        for column in REQUIRED_COLUMNS + ["Team"]
        if column not in tool_extract.columns
    ]
    missing_data = [
        column for column in REQUIRED_COLUMNS if column not in data.columns
    ]

    if missing_tool:
        raise KeyError(f"Missing columns in tool_extract: {missing_tool}")
    if missing_data:
        raise KeyError(f"Missing columns in data: {missing_data}")

    source_key = str(data_source).strip().casefold()

    tool_mask = (
        tool_extract["Team"]
        .astype("string")
        .fillna("")
        .str.strip()
        .str.casefold()
        .eq(source_key)
    )
    tool = tool_extract.loc[tool_mask, REQUIRED_COLUMNS].copy()

    # Do not apply the data_source filter to processed data.
    processed = data.loc[:, REQUIRED_COLUMNS].copy()

    tool = _clean_input(tool)
    processed = _clean_input(processed)

    group_columns = ["Source", "Emp GBL", "Month"]
    tool_summary = tool.groupby(group_columns, as_index=False)[METRICS].sum()
    data_summary = processed.groupby(group_columns, as_index=False)[METRICS].sum()

    all_sources = sorted(
        set(tool_summary["Source"]) | set(data_summary["Source"])
    )
    if not all_sources:
        raise ValueError(
            f"No comparison data found for data source: {data_source}"
        )

    output_path = Path(output_path)
    output_path.mkdir(parents=True, exist_ok=True)
    output_file = f"GBL_Comparison_{data_source}.xlsx"
    file_path = output_path / output_file

    if file_path.exists():
        file_path.unlink()

    results: Dict[str, Dict[str, pd.DataFrame]] = {}
    difference_sheet_names = []

    for source in all_sources:
        source_tool = tool_summary.loc[
            tool_summary["Source"].eq(source)
        ].drop(columns="Source")
        source_data = data_summary.loc[
            data_summary["Source"].eq(source)
        ].drop(columns="Source")

        tool_output, data_output, difference_output = _align_pivots(
            _make_pivot(source_tool),
            _make_pivot(source_data),
        )

        prefix = _safe_sheet_name(source)[:25]
        tool_sheet = _safe_sheet_name(f"{prefix}_Tool")
        data_sheet = _safe_sheet_name(f"{prefix}_Data")
        difference_sheet = _safe_sheet_name(f"{prefix}_Diff")

        generate_excel(
            tool_output,
            output_path,
            output_file,
            tool_sheet,
            header_bg_colour="4472C4",
        )
        generate_excel(
            data_output,
            output_path,
            output_file,
            data_sheet,
            header_bg_colour="548235",
        )
        generate_excel(
            difference_output,
            output_path,
            output_file,
            difference_sheet,
            header_bg_colour="C65911",
        )

        difference_sheet_names.append(difference_sheet)
        results[source] = {
            "Tool Extract": tool_output,
            "Data": data_output,
            "Difference": difference_output,
        }

    for sheet_name in difference_sheet_names:
        _format_difference_sheet(file_path, sheet_name)

    print(f"GBL comparison generated: {file_path}")
    return results
