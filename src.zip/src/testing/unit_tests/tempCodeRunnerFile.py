from processing.calculate_usage import hotel_usage

# hotel_usage("Hotel tax", 100)