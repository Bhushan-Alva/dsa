import pandas as pd
import numpy as np
from pathlib import Path
import sys
import pytest

project_root = Path.cwd()
sys.path.append(str(project_root / "src"))

# Now absolute import works:
from processing.calculate_usage import company_car_usage



@pytest.mark.parametrize(
    "business_distance, expected",
    [
        (np.nan, np.nan),     # tax → returns 0
        (0, 0),     # tax → returns 0
        (18, 18),  # not tax positive cost → returns 1
        (-333, -333) # not tax negative cost → returns -1
    ]
)

def test_company_car_usage(business_distance, expected):

    result = company_car_usage(business_distance)

    # Special case for np.nan
    if isinstance(expected, float) and np.isnan(expected):
        assert np.isnan(result)
    else:
        assert result == expected


