import pandas as pd
from pathlib import Path
import sys
import pytest

project_root = Path.cwd()
sys.path.append(str(project_root / "src"))

# Now absolute import works:
from processing.calculate_usage import hotel_usage



@pytest.mark.parametrize(
    "expense_type, cost, expected",
    [
        ("Hotel tax", 100, 0),     # tax → returns 0
        ("Hotel-taxable", 100, 0),     # tax → returns 0
        ("Hotel", 100, 1),  # not tax positive cost → returns 1
        ("Hotel", -100, -1) # not tax negative cost → returns -1
    ]
)
def test_hotel_usage(expense_type, cost, expected):
    assert hotel_usage(expense_type, cost) == expected

