"""Data loading utilities for Centralized Processing V2 with step-level logging.

Public functions preserved:
- load_myexpense_zips
- load_clean_raw_excels
- normalize_columns
- convert_numeric
- convert_string
- apply_type_mapping
- load_lookup_mapping
- load_all_lookups

Recommended notebook/main setup:
    import logging
    from pathlib import Path

    log_folder = Path("logs")
    log_folder.mkdir(exist_ok=True)

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
        handlers=[
            logging.FileHandler(log_folder / "processing_run.log", mode="w", encoding="utf-8"),
            logging.StreamHandler(),
        ],
        force=True,
    )
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Iterable, Mapping, Sequence
from zipfile import BadZipFile, ZipFile

import pandas as pd

logger = logging.getLogger(__name__)

EXCEL_SUFFIXES = (".xlsx", ".xlsb")
DEFAULT_RAW_REQUIRED_COLUMNS = ("Reimbursement Currency", "Employee Country")


def _log_step(step: str, level: int = logging.INFO, **details) -> None:
    """Write one structured log event for each loader step."""
    if details:
        detail_text = " | ".join(f"{key}={value}" for key, value in details.items())
        logger.log(level, "%s | %s", step, detail_text)
    else:
        logger.log(level, "%s", step)


def _to_path(path: str | Path, name: str) -> Path:
    if path is None or str(path).strip() == "":
        _log_step("Path validation failed", logging.ERROR, parameter=name, value=path)
        raise ValueError(f"{name} cannot be empty")

    resolved = Path(path)
    _log_step("Path resolved", parameter=name, path=resolved)
    return resolved


def _normalise_str_list(value: None | str | Iterable[str]) -> list[str] | None:
    if value is None:
        return None
    if isinstance(value, str):
        value = [value]
    result = [str(item).strip().lower() for item in value if str(item).strip()]
    _log_step("String list normalised", value_count=len(result), values=result)
    return result


def _require_columns(df: pd.DataFrame, required_columns: Sequence[str], context: str) -> None:
    _log_step("Required-column validation started", context=context, required_columns=list(required_columns))
    missing = [col for col in required_columns if col not in df.columns]
    if missing:
        _log_step("Required-column validation failed", logging.ERROR, context=context, missing_columns=missing)
        raise KeyError(f"Missing required column(s) in {context}: {missing}")
    _log_step("Required-column validation completed", context=context)


def _read_excel_by_suffix(file: Path, sheet_name: str) -> pd.DataFrame:
    _log_step("Excel read started", file=file.name, sheet_name=sheet_name, suffix=file.suffix.lower())
    if file.suffix.lower() == ".xlsb":
        df = pd.read_excel(file, sheet_name=sheet_name, engine="pyxlsb")
    else:
        df = pd.read_excel(file, sheet_name=sheet_name)
    _log_step("Excel read completed", file=file.name, rows=len(df), columns=len(df.columns))
    return df


def load_myexpense_zips(
    data_folder,
    zip_file="All",
    inner_csv="Project Expenses.csv",
    skiprows=13,
    required_columns: Sequence[str] = DEFAULT_RAW_REQUIRED_COLUMNS,
    exclude_employee_countries: Sequence[str] = ("DE",),
    encoding: str | None = None,
):
    """Load and consolidate expense data from one or more MyExpense ZIP files."""
    _log_step(
        "ZIP load started",
        data_folder=data_folder,
        zip_file=zip_file,
        inner_csv=inner_csv,
        skiprows=skiprows,
    )

    data_folder = _to_path(data_folder, "data_folder")
    if not data_folder.exists():
        _log_step("ZIP load failed", logging.ERROR, reason="Data folder not found", data_folder=data_folder)
        raise FileNotFoundError(f"Data folder not found: {data_folder}")
    if not data_folder.is_dir():
        _log_step("ZIP load failed", logging.ERROR, reason="data_folder is not a directory", data_folder=data_folder)
        raise NotADirectoryError(f"data_folder is not a directory: {data_folder}")

    if zip_file == "All":
        zip_paths = sorted(data_folder.glob("*.zip"))
    elif isinstance(zip_file, (list, tuple, set)):
        zip_paths = [data_folder / str(name) for name in zip_file]
    else:
        zip_paths = [data_folder / str(zip_file)]

    _log_step("ZIP files discovered", zip_count=len(zip_paths), zip_files=[p.name for p in zip_paths])
    if not zip_paths:
        _log_step("ZIP load failed", logging.ERROR, reason="No ZIP files found", data_folder=data_folder)
        raise ValueError(f"No ZIP files found in: {data_folder}")

    data_list: list[pd.DataFrame] = []
    exclude_countries = set(_normalise_str_list(exclude_employee_countries) or [])

    for zip_path in zip_paths:
        _log_step("ZIP file processing started", file=zip_path.name)

        if not zip_path.exists():
            _log_step("ZIP file processing failed", logging.ERROR, file=zip_path.name, reason="ZIP file not found")
            raise FileNotFoundError(f"ZIP file not found: {zip_path}")
        if zip_path.suffix.lower() != ".zip":
            _log_step("ZIP file processing failed", logging.ERROR, file=zip_path.name, reason="Not a ZIP file")
            raise ValueError(f"Expected a .zip file, received: {zip_path.name}")

        try:
            with ZipFile(zip_path) as zf:
                names = zf.namelist()
                _log_step("ZIP contents inspected", file=zip_path.name, inner_file_count=len(names))
                if inner_csv not in names:
                    _log_step("ZIP file processing failed", logging.ERROR, file=zip_path.name, reason="Inner CSV not found", inner_csv=inner_csv)
                    raise FileNotFoundError(f"{inner_csv} not found in {zip_path.name}")

                with zf.open(inner_csv) as file_obj:
                    read_kwargs = {"skiprows": skiprows}
                    if encoding:
                        read_kwargs["encoding"] = encoding
                    df = pd.read_csv(file_obj, **read_kwargs)
        except BadZipFile as exc:
            _log_step("ZIP file processing failed", logging.ERROR, file=zip_path.name, reason="Invalid or corrupt ZIP")
            raise ValueError(f"Invalid or corrupt ZIP file: {zip_path}") from exc

        _log_step("CSV read completed", file=zip_path.name, rows=len(df), columns=len(df.columns))
        _require_columns(df, required_columns, zip_path.name)

        before_rows = len(df)
        df = df[df["Reimbursement Currency"].notna()].copy()
        after_currency_notna = len(df)
        df = df[df["Reimbursement Currency"].astype(str).ne("Reimbursement Currency")].copy()
        after_header_filter = len(df)

        if exclude_countries:
            employee_country = df["Employee Country"].astype(str).str.strip().str.lower()
            df = df[~employee_country.isin(exclude_countries)].copy()
        after_country_filter = len(df)

        _log_step(
            "ZIP cleaning completed",
            file=zip_path.name,
            original_rows=before_rows,
            after_currency_notna=after_currency_notna,
            after_header_filter=after_header_filter,
            after_country_filter=after_country_filter,
            rows_removed=before_rows - after_country_filter,
        )

        df["Source File"] = zip_path.name
        data_list.append(df)
        _log_step("ZIP file processing completed", file=zip_path.name, final_rows=len(df))

    if not data_list:
        _log_step("ZIP load failed", logging.ERROR, reason="No data loaded from ZIP files")
        raise ValueError("No data loaded from ZIP files")

    result = pd.concat(data_list, ignore_index=True)
    _log_step("ZIP load completed", total_rows=len(result), total_columns=len(result.columns), files_loaded=len(data_list))
    return result


def load_clean_raw_excels(
    data_folder,
    sheet_name="Clean Raw",
    source_filter=None,
    exclude_source_when_no_filter: str | None = "Air",
    return_empty: bool = False,
):
    """Load clean raw Excel files from a folder with source filtering and step-level logging."""
    _log_step(
        "Clean raw Excel load started",
        data_folder=data_folder,
        sheet_name=sheet_name,
        source_filter=source_filter,
        exclude_source_when_no_filter=exclude_source_when_no_filter,
    )

    data_folder = _to_path(data_folder, "data_folder")
    if not data_folder.exists():
        _log_step("Clean raw Excel load failed", logging.ERROR, reason="Data folder not found", data_folder=data_folder)
        raise FileNotFoundError(f"Data folder not found: {data_folder}")
    if not data_folder.is_dir():
        _log_step("Clean raw Excel load failed", logging.ERROR, reason="data_folder is not a directory", data_folder=data_folder)
        raise NotADirectoryError(f"data_folder is not a directory: {data_folder}")

    excel_files = sorted(
        file for file in data_folder.iterdir()
        if file.is_file() and file.suffix.lower() in EXCEL_SUFFIXES and not file.name.startswith("~$")
    )
    _log_step("Excel files discovered", file_count=len(excel_files), files=[file.name for file in excel_files])

    if not excel_files:
        _log_step("Clean raw Excel load completed", logging.WARNING, reason="No Excel files found", rows=0)
        return pd.DataFrame() if return_empty else None

    source_filter_normalised = _normalise_str_list(source_filter)
    exclude_source = None if exclude_source_when_no_filter is None else str(exclude_source_when_no_filter).strip().lower()

    data_list: list[pd.DataFrame] = []
    skipped_files: dict[str, str] = {}

    for file in excel_files:
        _log_step("Excel file processing started", file=file.name)
        try:
            df = _read_excel_by_suffix(file, sheet_name=sheet_name)
        except ValueError:
            skipped_files[file.name] = f"Sheet '{sheet_name}' not found"
            _log_step("Excel file skipped", logging.WARNING, file=file.name, reason=skipped_files[file.name])
            continue
        except Exception as exc:
            skipped_files[file.name] = str(exc)
            _log_step("Excel file skipped", logging.WARNING, file=file.name, reason=str(exc), error_type=type(exc).__name__)
            continue

        before_filter_rows = len(df)
        if "Source" in df.columns:
            source_lower = df["Source"].astype("string").str.strip().str.lower()
            if source_filter_normalised is None:
                if exclude_source:
                    df = df[~source_lower.eq(exclude_source)].copy()
                    _log_step("Source exclusion applied", file=file.name, excluded_source=exclude_source, before_rows=before_filter_rows, after_rows=len(df))
            else:
                df = df[source_lower.isin(source_filter_normalised)].copy()
                _log_step("Source filter applied", file=file.name, source_filter=source_filter_normalised, before_rows=before_filter_rows, after_rows=len(df))
        else:
            _log_step("Source filter skipped", logging.WARNING, file=file.name, reason="Source column not found")

        if df.empty:
            skipped_files[file.name] = "No rows after source filtering"
            _log_step("Excel file skipped", logging.WARNING, file=file.name, reason=skipped_files[file.name])
            continue

        df["Source File"] = file.name
        data_list.append(df)
        _log_step("Excel file processing completed", file=file.name, final_rows=len(df), final_columns=len(df.columns))

    if skipped_files:
        _log_step("Excel skipped-file summary", logging.WARNING, skipped_files=skipped_files)

    if not data_list:
        _log_step("Clean raw Excel load completed", logging.WARNING, reason="No usable data found", rows=0)
        return pd.DataFrame() if return_empty else None

    result = pd.concat(data_list, ignore_index=True)
    _log_step("Clean raw Excel load completed", total_rows=len(result), total_columns=len(result.columns), files_loaded=len(data_list))
    return result


def normalize_columns(df, column_mapping):
    """Rename columns using a configured mapping."""
    _log_step("Column normalisation started", input_columns=len(df.columns), mapping_count=0 if column_mapping is None else len(column_mapping))
    if column_mapping is None:
        _log_step("Column normalisation skipped", reason="column_mapping is None")
        return df.copy()

    rename_dict = {col: column_mapping[col] for col in df.columns if col in column_mapping}
    result = df.rename(columns=rename_dict)
    _log_step("Column normalisation completed", renamed_columns=len(rename_dict), output_columns=len(result.columns))
    return result


def convert_numeric(series):
    """Convert comma-formatted numeric text to numeric values using NA-safe coercion."""
    result = (
        series.astype("string")
        .str.strip()
        .str.replace(",", "", regex=False)
        .replace({"": pd.NA, "nan": pd.NA, "None": pd.NA})
        .pipe(pd.to_numeric, errors="coerce")
    )
    _log_step("Numeric conversion completed", rows=len(series), null_results=int(result.isna().sum()))
    return result


def convert_string(series):
    """Convert a Series to stripped pandas string dtype with blanks instead of NA-like text."""
    result = (
        series.astype("string")
        .fillna("")
        .str.strip()
        .replace({"nan": "", "None": "", "<NA>": ""})
    )
    _log_step("String conversion completed", rows=len(series), blank_results=int(result.eq("").sum()))
    return result


def apply_type_mapping(df, dtype_mapping, strict: bool = True):
    """Apply configured datatypes to DataFrame columns with step-level logs."""
    _log_step("Type mapping started", rows=len(df), columns=len(df.columns), strict=strict, mapping_count=0 if dtype_mapping is None else len(dtype_mapping))
    if dtype_mapping is None:
        _log_step("Type mapping skipped", reason="dtype_mapping is None")
        return df

    for col, dtype in dtype_mapping.items():
        if col not in df.columns:
            if strict:
                _log_step("Type mapping failed", logging.ERROR, column=col, dtype=dtype, reason="Missing required column")
                raise KeyError(f"Missing required column: {col}")
            _log_step("Type mapping skipped for column", logging.WARNING, column=col, dtype=dtype, reason="Missing column")
            continue

        dtype_normalised = str(dtype).lower().strip()
        _log_step("Column type conversion started", column=col, dtype=dtype_normalised)

        try:
            if dtype_normalised.startswith("datetime") or dtype_normalised in {"date", "timestamp"}:
                df[col] = pd.to_datetime(df[col], errors="coerce")
            elif dtype_normalised in {"float", "float64", "number", "numeric"}:
                df[col] = convert_numeric(df[col])
            elif dtype_normalised in {"int", "int64", "integer"}:
                df[col] = convert_numeric(df[col]).round().astype("Int64")
            elif dtype_normalised in {"str", "string", "object"}:
                df[col] = convert_string(df[col]).astype("string")
            elif dtype_normalised in {"bool", "boolean"}:
                df[col] = df[col].astype("boolean")
            else:
                df[col] = df[col].astype(dtype)
        except Exception as exc:
            _log_step("Column type conversion failed", logging.ERROR, column=col, dtype=dtype, error_type=type(exc).__name__, error_message=str(exc))
            raise

        _log_step("Column type conversion completed", column=col, dtype=str(df[col].dtype), null_count=int(df[col].isna().sum()))

    _log_step("Type mapping completed", rows=len(df), columns=len(df.columns))
    return df


def load_lookup_mapping(
    lookup_path: str,
    sheet_name: str,
    key_col: int = 0,
    value_col: int = 1,
    lowercase_keys: bool = True,
    duplicate_policy: str = "last",
    drop_blank_values: bool = False,
) -> dict:
    """Load a two-column lookup mapping from an Excel sheet with detailed logs."""
    _log_step(
        "Lookup load started",
        lookup_path=lookup_path,
        sheet_name=sheet_name,
        key_col=key_col,
        value_col=value_col,
        lowercase_keys=lowercase_keys,
        duplicate_policy=duplicate_policy,
    )

    lookup_path = _to_path(lookup_path, "lookup_path")
    if not lookup_path.exists():
        _log_step("Lookup load failed", logging.ERROR, reason="Excel file not found", lookup_path=lookup_path)
        raise FileNotFoundError(f"Excel file not found: {lookup_path}")
    if key_col < 0 or value_col < 0:
        _log_step("Lookup load failed", logging.ERROR, reason="Negative column index", key_col=key_col, value_col=value_col)
        raise ValueError("key_col and value_col must be zero-based non-negative integers")

    try:
        df = pd.read_excel(lookup_path, sheet_name=sheet_name)
    except ValueError as exc:
        _log_step("Lookup load failed", logging.ERROR, reason="Sheet not found", sheet_name=sheet_name)
        raise ValueError(f"Sheet '{sheet_name}' not found in Excel file: {lookup_path}") from exc
    except Exception as exc:
        _log_step("Lookup load failed", logging.ERROR, reason="Unexpected Excel read error", error_type=type(exc).__name__, error_message=str(exc))
        raise RuntimeError(f"Unexpected error while reading Excel file: {lookup_path}") from exc

    _log_step("Lookup sheet read completed", sheet_name=sheet_name, rows=len(df), columns=len(df.columns))

    max_index = max(key_col, value_col)
    if df.shape[1] <= max_index:
        _log_step("Lookup load failed", logging.ERROR, reason="Requested column index outside range", available_columns=df.shape[1], key_col=key_col, value_col=value_col)
        raise IndexError(
            f"Sheet '{sheet_name}' has only {df.shape[1]} columns, "
            f"but key_col={key_col}, value_col={value_col} were requested"
        )

    keys = df.iloc[:, key_col].astype("string").str.strip()
    values = df.iloc[:, value_col]

    valid_mask = keys.notna() & keys.ne("")
    if drop_blank_values:
        valid_mask &= values.notna()

    before_valid = len(keys)
    keys = keys[valid_mask]
    values = values[valid_mask]
    _log_step("Lookup blank-key filtering completed", sheet_name=sheet_name, before_rows=before_valid, after_rows=len(keys), removed_rows=before_valid - len(keys))

    if lowercase_keys:
        keys = keys.str.lower()
        _log_step("Lookup keys lowercased", sheet_name=sheet_name)

    if keys.empty:
        _log_step("Lookup load failed", logging.ERROR, sheet_name=sheet_name, reason="No valid lookup keys")
        raise ValueError(f"No valid lookup keys found in sheet '{sheet_name}'")
    if values.isna().all():
        _log_step("Lookup load failed", logging.ERROR, sheet_name=sheet_name, reason="Value column contains only NaN")
        raise ValueError(f"Value column contains only NaN values in sheet '{sheet_name}'")

    duplicate_policy = duplicate_policy.lower().strip()
    if duplicate_policy not in {"last", "first", "raise"}:
        _log_step("Lookup load failed", logging.ERROR, reason="Invalid duplicate_policy", duplicate_policy=duplicate_policy)
        raise ValueError("duplicate_policy must be one of: 'last', 'first', 'raise'")

    duplicate_count = int(keys.duplicated().sum())
    if duplicate_count:
        dup_keys = keys[keys.duplicated()].dropna().unique().tolist()
        _log_step("Lookup duplicate keys found", logging.WARNING, sheet_name=sheet_name, duplicate_count=duplicate_count, duplicate_keys=dup_keys)
        if duplicate_policy == "raise":
            _log_step("Lookup load failed", logging.ERROR, sheet_name=sheet_name, reason="Duplicate keys", duplicate_keys=dup_keys)
            raise ValueError(f"Duplicate keys found in mapping '{sheet_name}': {dup_keys}")

        keep = "first" if duplicate_policy == "first" else "last"
        deduped = pd.DataFrame({"key": keys, "value": values}).drop_duplicates("key", keep=keep)
        keys = deduped["key"]
        values = deduped["value"]
        _log_step("Lookup duplicate policy applied", sheet_name=sheet_name, duplicate_policy=duplicate_policy, final_rows=len(keys))

    mapping = dict(zip(keys.tolist(), values.tolist()))
    _log_step("Lookup load completed", sheet_name=sheet_name, mapping_size=len(mapping))
    return mapping


def load_all_lookups(lookup_path: str, lookup_config: Mapping[str, Mapping]) -> dict:
    """Load all lookup mappings defined in lookup_config with consolidated error logging."""
    _log_step("All lookups load started", lookup_path=lookup_path, lookup_count=0 if not lookup_config else len(lookup_config))
    if not lookup_config:
        _log_step("All lookups load failed", logging.ERROR, reason="lookup_config cannot be empty")
        raise ValueError("lookup_config cannot be empty")

    lookups = {}
    errors = {}

    for name, cfg in lookup_config.items():
        _log_step("Single lookup processing started", lookup_name=name, config=cfg)
        try:
            lookups[name] = load_lookup_mapping(
                lookup_path=lookup_path,
                sheet_name=cfg["sheet"],
                key_col=cfg.get("key_col", 0),
                value_col=cfg.get("value_col", 1),
                lowercase_keys=cfg.get("lowercase_keys", True),
                duplicate_policy=cfg.get("duplicate_policy", "last"),
                drop_blank_values=cfg.get("drop_blank_values", False),
            )
            _log_step("Single lookup processing completed", lookup_name=name, mapping_size=len(lookups[name]))
        except Exception as exc:
            errors[name] = str(exc)
            _log_step("Single lookup processing failed", logging.ERROR, lookup_name=name, error_type=type(exc).__name__, error_message=str(exc))

    if errors:
        _log_step("All lookups load failed", logging.ERROR, failed_lookup_count=len(errors), errors=errors)
        raise RuntimeError(
            "Failed to load one or more lookup tables:\n"
            + "\n".join(f"{name}: {message}" for name, message in errors.items())
        )

    _log_step("All lookups load completed", loaded_lookup_count=len(lookups), lookup_names=list(lookups.keys()))
    return lookups


import re
from pathlib import Path

import numpy as np
import pandas as pd


def load_tool_extract(folder_path):
    """
    Read and combine all Excel files from a folder, then transform
    the consolidated Tool Extract data.

    Parameters
    ----------
    folder_path : str or pathlib.Path
        Folder containing .xlsx and .xls files.

    Returns
    -------
    pd.DataFrame
        Combined and transformed Tool Extract dataframe.
    """

    folder = Path(folder_path)

    if not folder.exists():
        raise FileNotFoundError(f"Folder does not exist: {folder}")

    if not folder.is_dir():
        raise NotADirectoryError(f"Path is not a folder: {folder}")

    # Read Excel files only and exclude temporary Excel lock files.
    excel_files = sorted(
        file
        for file in folder.iterdir()
        if file.is_file()
        and file.suffix.lower() in {".xlsx", ".xls"}
        and not file.name.startswith("~$")
    )

    if not excel_files:
        raise FileNotFoundError(f"No Excel files found in folder: {folder}")

    dfs = []

    for file in excel_files:
        try:
            engine = "openpyxl" if file.suffix.lower() == ".xlsx" else "xlrd"
            df = pd.read_excel(file, engine=engine)

            # Retain original filename for audit trail.
            df["Source File"] = file.name

            dfs.append(df)
            print(f"Read: {file.name} ({len(df):,} rows)")

        except Exception as error:
            print(f"Error reading {file.name}: {error}")

    if not dfs:
        raise ValueError(
            "Excel files were found, but none could be read successfully."
        )

    tool_extract = pd.concat(dfs, ignore_index=True, sort=False)
    print(f"\nTotal rows: {len(tool_extract):,}")

    empty_date = pd.Series(pd.NaT, index=tool_extract.index)
    empty_text = pd.Series(pd.NA, index=tool_extract.index, dtype="object")

    # Create Month from Departure Date; otherwise use Check-In Date.
    departure_date = tool_extract.get("Departure Date", empty_date)
    check_in_date = tool_extract.get("Check-In Date", empty_date)

    tool_extract["Month"] = pd.to_datetime(
        departure_date.fillna(check_in_date),
        errors="coerce"
    ).dt.month_name()

    # Keep Source Name; when blank or null, use Source Name Input.
    source_name = tool_extract.get("Source Name", empty_text).replace(
        r"^\s*$", pd.NA, regex=True
    )
    source_name_input = tool_extract.get(
        "Source Name Input", empty_text
    ).replace(r"^\s*$", pd.NA, regex=True)

    tool_extract["Source Name"] = source_name.fillna(source_name_input)

    # Derive Team and Source from File Name.
    file_name = tool_extract.get(
        "File Name",
        pd.Series("", index=tool_extract.index, dtype="object")
    ).fillna("").astype(str)

    is_consolidated = file_name.str.contains(
        r"\bConsolidated\b", case=False, regex=True, na=False
    )
    is_myexpense = file_name.str.contains(
        r"\bMyExpense\b", case=False, regex=True, na=False
    )
    is_sap = file_name.str.contains(
        r"\bSAP\b", case=False, regex=True, na=False
    )

    # Only consolidated files receive a Team value.
    tool_extract["Team"] = np.select(
        [
            is_consolidated & is_myexpense,
            is_consolidated & is_sap
        ],
        [
            "MyExpense",
            "SAP"
        ],
        default=""
    )

    source_values = [
        "Company Car",
        "Private Car",
        "Hotel",
        "LPT",
        "Rail",
        "Taxi",
        "Rental Car"
    ]

    # Standardize CompanyCar before extracting the Source value.
    normalized_file_name = file_name.str.replace(
        r"\bCompanyCar\b",
        "Company Car",
        case=False,
        regex=True
    )

    # Match longer source names first to avoid partial matches.
    source_pattern = "|".join(
        sorted(map(re.escape, source_values), key=len, reverse=True)
    )
    source_mapping = {value.lower(): value for value in source_values}

    tool_extract["Source"] = (
        normalized_file_name
        .str.extract(
            rf"({source_pattern})",
            flags=re.IGNORECASE,
            expand=False
        )
        .str.lower()
        .map(source_mapping)
        .fillna("")
    )

    # Drop columns that have been consolidated into Month and Source Name.
    tool_extract.drop(
        columns=[
            "Departure Date",
            "Check-In Date",
            "Source Name Input"
        ],
        inplace=True,
        errors="ignore"
    )

    return tool_extract
