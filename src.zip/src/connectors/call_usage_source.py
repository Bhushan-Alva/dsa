"""Dispatcher utilities for MyExpense usage and source-name calculations with step-level logging.

Public functions preserved:
- calculate_usage
- calculate_source_name
- add_rental_report_flags

Logging behavior:
- Logs function start/end.
- Logs input row/column counts.
- Logs source being processed.
- Logs missing columns/lookups before raising errors.
- Logs Rental Car flag creation.
- Logs output non-null counts.

Recommended notebook setup:
    import logging
    from pathlib import Path

    log_folder = Path("logs")
    log_folder.mkdir(exist_ok=True)

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
        handlers=[
            logging.FileHandler(
                log_folder / "processing_run.log",
                mode="w",
                encoding="utf-8",
            ),
            logging.StreamHandler(),
        ],
        force=True,
    )
"""

from __future__ import annotations

import logging
from collections.abc import Callable, Mapping, Sequence
from typing import Any

import pandas as pd

logger = logging.getLogger(__name__)

try:
    from src.processing.calculate_usage import USAGE_FUNCTIONS
    from src.processing.calculate_source import SOURCE_FUNCTIONS
except ModuleNotFoundError:
    from processing.calculate_usage import USAGE_FUNCTIONS
    from processing.calculate_source import SOURCE_FUNCTIONS


USAGE_VALUE_COLUMNS: dict[str, list[str]] = {
    "Company Car": ["Business Distance"],
    "Private Car": ["Business Distance"],
    "Rental Car": [
        "Expense Type",
        "Employee Country",
        "Country Of Transaction",
        "Approved Amount",
        "_all_car_rental",
        "_all_fuel",
    ],
    "LPT": ["Employee Country", "Country Of Transaction", "Approved Amount"],
    "Taxi": ["Country Of Transaction", "City Of Transaction", "Approved Amount"],
    "Rail": [
        "City Pair",
        "Approved Amount",
        "Complementary Detail (Route / Taxi / Meal / Parking / Car)",
        "Country Of Transaction",
    ],
    "Hotel": ["Expense Type", "Approved Amount"],
}

USAGE_LOOKUP_KEYS: dict[str, dict[str, str]] = {
    "LPT": {
        "lpt_country_mapping": "lpt_country_mapping",
        "emp_country_bus_rate": "lpt_cc_bus_rates_mapping",
        "emp_country_rail_rate": "lpt_cc_rail_rates_mapping",
        "transaction_country_bus_rate": "lpt_bus_rates_mapping",
        "transaction_country_rail_rate": "lpt_rail_rates_mapping",
    },
    "Rental Car": {
        "rental_fuel_price_mapping": "rental_fuel_price_mapping",
        "rental_country_split_mapping": "rental_split_mapping",
    },
    "Taxi": {
        "taxi_city_start_rate_mapping": "taxi_city_start_rate_mapping",
        "taxi_city_1km_rate_mapping": "taxi_city_1km_rate_mapping",
        "taxi_country_start_rate_mapping": "taxi_country_start_rate_mapping",
        "taxi_country_1km_rate_mapping": "taxi_country_1km_rate_mapping",
        "taxi_city_normalized_mapping": "taxi_city_normalized_mapping",
    },
    "Rail": {
        "rail_city_distance_mapping": "rail_city_distance_mapping",
        "rail_country_rates_mapping": "rail_country_rates_mapping",
        "rail_region_rates_mapping": "rail_region_rates_mapping",
        "rail_clean_country_mapping": "rail_clean_country_mapping",
        "rail_clean_region_mapping": "rail_clean_region_mapping",
        "comp_details_distance_mapping": "comp_details_distance_mapping",
    },
}

SOURCE_VALUE_COLUMNS: dict[str, list[str]] = {
    "Company Car": ["Employee Country", "Expense Type", "Criteria Name"],
    "Private Car": ["Expense Type", "Criteria Name"],
    "Rental Car": [
        "Expense Type",
        "Employee Country",
        "Country Of Transaction",
        "_all_car_rental",
        "_all_fuel",
    ],
    "LPT": ["Employee Country"],
    "Taxi": [],
    "Rail": [
        "Complementary Detail (Route / Taxi / Meal / Parking / Car)",
        "Origin City",
        "Destination City",
        "Vendor Name",
        "Legal Entity",
        "Country Of Transaction",
        "City Pair"
    ],
    "Hotel": ["Travel Category"],
}

SOURCE_LOOKUP_KEYS: dict[str, dict[str, str]] = {
    "Company Car": {"mapping_lookup": "company_car_source"},
    "Private Car": {"mapping_lookup": "private_car_source"},
    "Rental Car": {
        "rental_source_mapping": "rental_source_mapping",
        "rental_source_fuel_mapping": "rental_source_fuel_mapping",
    },
    "Rail": {
        "comp_details_from_mapping": "comp_details_from_mapping",
        "comp_details_to_mapping": "comp_details_to_mapping",
        "rail_normalized_city_country_mapping": "rail_normalized_city_country_mapping",
        "country_mapping": "country_mapping",
        "vendor_name_mapping": "vendor_name_mapping",
        "eurostar_mapping": "eurostar_mapping",
        "legal_entity_country": "legal_entity_country",
    },
}

DEFAULT_SOURCE_COLUMN = "Source"
DEFAULT_USAGE_COLUMN = "Usage"
DEFAULT_SOURCE_NAME_COLUMN = "Source Name"
DEFAULT_EXPENSE_REPORT_KEY_COLUMN = "Expense Report Key"


def _log_step(step: str, level: int = logging.INFO, **details: Any) -> None:
    """Write one structured log event for each processing step."""
    if details:
        detail_text = " | ".join(
            f"{key}={value}" for key, value in details.items()
        )
        logger.log(level, "%s | %s", step, detail_text)
    else:
        logger.log(level, "%s", step)


def _normalise_source(source: str) -> str:
    if source is None or str(source).strip() == "":
        _log_step("Source validation failed", logging.ERROR, source=source)
        raise ValueError("source cannot be empty")

    source_text = str(source).strip()
    lookup = {
        key.lower(): key
        for key in set(USAGE_VALUE_COLUMNS) | set(SOURCE_VALUE_COLUMNS)
    }
    normalised = lookup.get(source_text.lower(), source_text)

    if normalised != source_text:
        _log_step(
            "Source normalised",
            original=source_text,
            normalised=normalised,
        )

    return normalised


def _ensure_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    if not isinstance(df, pd.DataFrame):
        _log_step(
            "Input validation failed",
            logging.ERROR,
            received_type=type(df).__name__,
        )
        raise TypeError("df must be a pandas DataFrame")

    return df


def _missing_columns(
    df: pd.DataFrame,
    columns: Sequence[str],
) -> list[str]:
    return [column for column in columns if column not in df.columns]


def _validate_columns(
    df: pd.DataFrame,
    columns: Sequence[str],
    source: str,
    calculation_type: str,
) -> None:
    _log_step(
        "Column validation started",
        calculation_type=calculation_type,
        source=source,
        required_columns=len(columns),
    )

    missing = _missing_columns(df, columns)

    if missing:
        _log_step(
            "Column validation failed",
            logging.ERROR,
            calculation_type=calculation_type,
            source=source,
            missing_columns=missing,
        )
        raise KeyError(
            f"Missing required column(s) for {calculation_type} calculation "
            f"for source '{source}': {missing}"
        )

    _log_step(
        "Column validation completed",
        calculation_type=calculation_type,
        source=source,
    )


def resolve_lookup_dicts(
    source: str,
    lookup_keys: Mapping[str, Mapping[str, str]],
    lookup_dicts: Mapping[str, Any] | None,
    calculation_type: str = "lookup",
) -> dict[str, Any]:
    source = _normalise_source(source)
    required = dict(lookup_keys.get(source, {}))

    _log_step(
        "Lookup resolution started",
        calculation_type=calculation_type,
        source=source,
        required_lookups=list(required.values()),
    )

    if not required:
        _log_step(
            "Lookup resolution skipped",
            calculation_type=calculation_type,
            source=source,
            reason="No lookup required",
        )
        return {}

    if lookup_dicts is None:
        _log_step(
            "Lookup resolution failed",
            logging.ERROR,
            calculation_type=calculation_type,
            source=source,
            reason="lookup_dicts is None",
            required=list(required.values()),
        )
        raise KeyError(
            f"Lookup dictionaries are required for {calculation_type} "
            f"calculation for source '{source}', but lookup_dicts is None. "
            f"Required: {list(required.values())}"
        )

    missing = [
        lookup_name
        for lookup_name in required.values()
        if lookup_name not in lookup_dicts
    ]

    if missing:
        _log_step(
            "Lookup resolution failed",
            logging.ERROR,
            calculation_type=calculation_type,
            source=source,
            missing_lookups=missing,
        )
        raise KeyError(
            f"Missing lookup dictionary/dictionaries for {calculation_type} "
            f"calculation for source '{source}': {missing}"
        )

    resolved = {
        argument_name: lookup_dicts[lookup_name]
        for argument_name, lookup_name in required.items()
    }

    _log_step(
        "Lookup resolution completed",
        calculation_type=calculation_type,
        source=source,
        resolved_arguments=list(resolved.keys()),
    )

    return resolved


def _call_function_safely(
    function: Callable,
    row_values: list[Any],
    lookup_kwargs: Mapping[str, Any],
) -> Any:
    return function(*row_values, **lookup_kwargs)


def _calculate_generic(
    df: pd.DataFrame,
    source: str,
    functions: Mapping[str, Callable],
    value_columns_map: Mapping[str, list[str]],
    lookup_keys_map: Mapping[str, Mapping[str, str]],
    lookup_dicts: Mapping[str, Any] | None = None,
    calculation_type: str = "calculation",
) -> pd.Series:
    df = _ensure_dataframe(df)
    source = _normalise_source(source)

    _log_step(
        "Calculation started",
        calculation_type=calculation_type,
        source=source,
        rows=len(df),
        columns=len(df.columns),
    )

    if source not in functions:
        available = sorted(functions.keys())
        _log_step(
            "Calculation failed",
            logging.ERROR,
            calculation_type=calculation_type,
            source=source,
            reason="No function configured",
            available_sources=available,
        )
        raise KeyError(
            f"No {calculation_type} function configured for source "
            f"'{source}'. Available: {available}"
        )

    value_columns = list(value_columns_map.get(source, []))
    _validate_columns(df, value_columns, source, calculation_type)

    lookup_kwargs = resolve_lookup_dicts(
        source,
        lookup_keys_map,
        lookup_dicts,
        calculation_type,
    )
    function = functions[source]

    if df.empty:
        _log_step(
            "Calculation completed",
            calculation_type=calculation_type,
            source=source,
            rows=0,
            non_null_results=0,
        )
        return pd.Series(index=df.index, dtype="object")

    try:
        if not value_columns:
            result = df.apply(
                lambda _: function(**lookup_kwargs),
                axis=1,
            )
        else:
            result = df[value_columns].apply(
                lambda row: _call_function_safely(
                    function,
                    row.tolist(),
                    lookup_kwargs,
                ),
                axis=1,
            )
    except Exception as exc:
        _log_step(
            "Calculation failed",
            logging.ERROR,
            calculation_type=calculation_type,
            source=source,
            error_type=type(exc).__name__,
            error_message=str(exc),
        )
        raise

    _log_step(
        "Calculation completed",
        calculation_type=calculation_type,
        source=source,
        rows=len(result),
        non_null_results=int(result.notna().sum()),
        null_results=int(result.isna().sum()),
    )

    return result


def add_rental_report_flags(
    df: pd.DataFrame,
    source_col: str = DEFAULT_SOURCE_COLUMN,
    expense_type_col: str = "Expense Type",
    report_key_col: str = "Expense Report Key",
    car_flag_col: str = "_all_car_rental",
    fuel_flag_col: str = "_all_fuel",
) -> pd.DataFrame:
    """
    Add Rental Car report-level flags.

    Logic:
    - Only rows where Source == "Rental Car" participate in the check.
    - Hotel, Taxi, Rail, and other source rows in the same expense report
      are ignored.
    - _all_car_rental is True when all Rental Car source rows in the
      Expense Report Key have Expense Type exactly equal to "Car Rental".
    - _all_fuel is True when all Rental Car source rows in the
      Expense Report Key contain "fuel" in Expense Type.
    - Flags remain False for non-Rental Car source rows.
    """

    df = _ensure_dataframe(df).copy()

    _log_step(
        "Rental flag step started",
        rows=len(df),
        columns=len(df.columns),
    )

    # Always reset flags to avoid retaining values from an earlier run
    df[car_flag_col] = False
    df[fuel_flag_col] = False

    required_columns = [
        source_col,
        expense_type_col,
        report_key_col,
    ]

    missing = _missing_columns(df, required_columns)

    if missing:
        _log_step(
            "Rental flag step skipped",
            logging.WARNING,
            missing_columns=missing,
        )
        return df

    # Identify only Source = Rental Car rows
    source_normalized = (
        df[source_col]
        .astype("string")
        .str.strip()
        .str.casefold()
    )

    rental_mask = source_normalized.eq("rental car")

    rental_rows = int(rental_mask.sum())

    _log_step(
        "Rental rows identified",
        rental_rows=rental_rows,
    )

    if rental_rows == 0:
        _log_step(
            "Rental flag step completed",
            reason="No Rental Car source rows",
            all_car_rental_true=0,
            all_fuel_true=0,
        )
        return df

    # Work only with Rental Car source rows
    rental_df = df.loc[
        rental_mask,
        [report_key_col, expense_type_col],
    ].copy()

    rental_df["_expense_type_normalized"] = (
        rental_df[expense_type_col]
        .astype("string")
        .str.strip()
        .str.casefold()
    )

    # Preserve original matching rules
    rental_df["_car_rental_row"] = (
        rental_df["_expense_type_normalized"]
        .eq("car rental")
        .fillna(False)
    )

    rental_df["_fuel_row"] = (
        rental_df["_expense_type_normalized"]
        .str.contains(
            "fuel",
            na=False,
            regex=False,
        )
    )

    # Check whether all Rental Car source rows within each report
    # satisfy the respective condition
    grouped_flags = (
        rental_df
        .groupby(
            report_key_col,
            dropna=False,
        )
        .agg(
            _all_car_rental=("_car_rental_row", "all"),
            _all_fuel=("_fuel_row", "all"),
        )
    )

    # Map report-level flags back only to Source = Rental Car rows
    rental_report_keys = df.loc[rental_mask, report_key_col]

    df.loc[rental_mask, car_flag_col] = (
        rental_report_keys
        .map(grouped_flags["_all_car_rental"])
        .fillna(False)
        .astype(bool)
        .to_numpy()
    )

    df.loc[rental_mask, fuel_flag_col] = (
        rental_report_keys
        .map(grouped_flags["_all_fuel"])
        .fillna(False)
        .astype(bool)
        .to_numpy()
    )

    _log_step(
        "Rental flag step completed",
        rental_rows=rental_rows,
        rental_reports=int(
            rental_df[report_key_col].nunique(dropna=False)
        ),
        all_car_rental_true=int(
            df.loc[rental_mask, car_flag_col].sum()
        ),
        all_fuel_true=int(
            df.loc[rental_mask, fuel_flag_col].sum()
        ),
    )

    return df


def calculate_usage(
    df: pd.DataFrame,
    source: str | None = None,
    lookup_dicts: Mapping[str, Any] | None = None,
    source_col: str = DEFAULT_SOURCE_COLUMN,
    output_col: str = DEFAULT_USAGE_COLUMN,
) -> pd.DataFrame:
    df = _ensure_dataframe(df).copy()

    _log_step(
        "Usage wrapper started",
        rows=len(df),
        source=source or "Source column",
        output_col=output_col,
    )

    df = add_rental_report_flags(df, source_col=source_col)

    if source is not None:
        source = _normalise_source(source)
        df[output_col] = _calculate_generic(
            df,
            source,
            USAGE_FUNCTIONS,
            USAGE_VALUE_COLUMNS,
            USAGE_LOOKUP_KEYS,
            lookup_dicts,
            "usage",
        )
        _log_step(
            "Usage wrapper completed",
            source=source,
            rows=len(df),
            non_null_usage=int(df[output_col].notna().sum()),
        )
        return df

    if source_col not in df.columns:
        _log_step(
            "Usage wrapper failed",
            logging.ERROR,
            reason="Source column missing",
            source_col=source_col,
        )
        raise KeyError(
            f"source_col '{source_col}' not found. "
            "Pass source='...' or include a Source column."
        )

    df[output_col] = pd.NA
    source_counts = df[source_col].value_counts(dropna=False).to_dict()

    _log_step(
        "Usage source grouping completed",
        source_counts=source_counts,
    )

    for source_name, index in df.groupby(
        source_col,
        dropna=False,
    ).groups.items():
        if pd.isna(source_name) or str(source_name).strip() == "":
            _log_step(
                "Usage source skipped",
                logging.WARNING,
                source=source_name,
                reason="Blank source",
            )
            continue

        normalised_source = _normalise_source(str(source_name))

        _log_step(
            "Usage source processing started",
            source=normalised_source,
            rows=len(index),
        )

        source_df = df.loc[index]
        df.loc[index, output_col] = _calculate_generic(
            source_df,
            normalised_source,
            USAGE_FUNCTIONS,
            USAGE_VALUE_COLUMNS,
            USAGE_LOOKUP_KEYS,
            lookup_dicts,
            "usage",
        ).values

        _log_step(
            "Usage source processing completed",
            source=normalised_source,
            rows=len(index),
        )

    _log_step(
        "Usage wrapper completed",
        rows=len(df),
        non_null_usage=int(df[output_col].notna().sum()),
        null_usage=int(df[output_col].isna().sum()),
    )

    return df


def calculate_source_name(
    df: pd.DataFrame,
    source: str | None = None,
    lookup_dicts: Mapping[str, Any] | None = None,
    source_col: str = DEFAULT_SOURCE_COLUMN,
    output_col: str = DEFAULT_SOURCE_NAME_COLUMN,
) -> pd.DataFrame:
    df = _ensure_dataframe(df).copy()

    _log_step(
        "Source-name wrapper started",
        rows=len(df),
        source=source or "Source column",
        output_col=output_col,
    )

    df = add_rental_report_flags(df, source_col=source_col)

    if source is not None:
        source = _normalise_source(source)
        df[output_col] = _calculate_generic(
            df,
            source,
            SOURCE_FUNCTIONS,
            SOURCE_VALUE_COLUMNS,
            SOURCE_LOOKUP_KEYS,
            lookup_dicts,
            "source name",
        )
        _log_step(
            "Source-name wrapper completed",
            source=source,
            rows=len(df),
            non_null_source_name=int(df[output_col].notna().sum()),
        )
        return df

    if source_col not in df.columns:
        _log_step(
            "Source-name wrapper failed",
            logging.ERROR,
            reason="Source column missing",
            source_col=source_col,
        )
        raise KeyError(
            f"source_col '{source_col}' not found. "
            "Pass source='...' or include a Source column."
        )

    df[output_col] = pd.NA
    source_counts = df[source_col].value_counts(dropna=False).to_dict()

    _log_step(
        "Source-name source grouping completed",
        source_counts=source_counts,
    )

    for source_name, index in df.groupby(
        source_col,
        dropna=False,
    ).groups.items():
        if pd.isna(source_name) or str(source_name).strip() == "":
            _log_step(
                "Source-name source skipped",
                logging.WARNING,
                source=source_name,
                reason="Blank source",
            )
            continue

        normalised_source = _normalise_source(str(source_name))

        _log_step(
            "Source-name processing started",
            source=normalised_source,
            rows=len(index),
        )

        source_df = df.loc[index]
        df.loc[index, output_col] = _calculate_generic(
            source_df,
            normalised_source,
            SOURCE_FUNCTIONS,
            SOURCE_VALUE_COLUMNS,
            SOURCE_LOOKUP_KEYS,
            lookup_dicts,
            "source name",
        ).values

        _log_step(
            "Source-name processing completed",
            source=normalised_source,
            rows=len(index),
        )

    _log_step(
        "Source-name wrapper completed",
        rows=len(df),
        non_null_source_name=int(df[output_col].notna().sum()),
        null_source_name=int(df[output_col].isna().sum()),
    )

    return df
