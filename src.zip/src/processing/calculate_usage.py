"""Fast usage calculation functions with minimal logging.

Public functions preserved:
- company_car_usage
- rental_car_usage
- private_car_usage
- safe_lower
- safe_float
- taxi_usage
- safe_rate
- is_blank
- lpt_usage
- rail_usage
- hotel_usage
- USAGE_FUNCTIONS

Design:
- These functions are called row-by-row by call_usage_source.py.
- No row-level logging is performed here for speed.
- High-level start/end logging should remain in call_usage_source.py.
"""

from __future__ import annotations

import logging
from typing import Any, Mapping

import numpy as np
import pandas as pd
import re

logger = logging.getLogger(__name__)

MISSING_TEXT_VALUES = {"", "nan", "none", "nat", "<na>", "missing value", "na", "n/a", "null"}


def _log_step(step: str, level: int = logging.DEBUG, **details: Any) -> None:
    """Fast log helper. Keeps compatibility but avoids string work when disabled."""
    if not logger.isEnabledFor(level):
        return
    if details:
        detail_text = " | ".join(f"{key}={value}" for key, value in details.items())
        logger.log(level, "%s | %s", step, detail_text)
    else:
        logger.log(level, "%s", step)


def is_blank(value: Any) -> bool:
    """Return True when a value is null, NA-like, or blank after stripping."""
    if value is None:
        return True
    try:
        if pd.isna(value):
            return True
    except Exception:
        pass
    return str(value).strip().lower() in MISSING_TEXT_VALUES


def safe_lower(value: Any) -> str:
    """Safely convert a scalar value to stripped lowercase text."""
    if is_blank(value):
        return ""
    return str(value).strip().lower()


def safe_float(value: Any, default: float = np.nan, context: str | None = None) -> float:
    """Fast scalar-to-float conversion. No row-level logging."""
    if is_blank(value):
        return default
    try:
        return float(str(value).replace(",", "").strip())
    except Exception:
        return default


def safe_rate(mapping: Mapping | None, key: Any, default: float = np.nan, context: str | None = None) -> float:
    """Fast lookup-rate retrieval. No row-level logging."""
    if mapping is None:
        return default

    key_text = safe_lower(key)
    if not key_text:
        return default

    value = mapping.get(key_text)
    if value is None:
        # Fallback for dictionaries that were not lowercased.
        try:
            value = mapping.get(key)
        except TypeError:
            value = None

    if value is None:
        return default

    return safe_float(value, default=default, context=context)


def _lookup_value(mapping: Mapping | None, key: Any, default: Any = np.nan, context: str | None = None) -> Any:
    """Fast raw lookup using lowercase and original-key fallback."""
    if mapping is None:
        return default

    key_text = safe_lower(key)
    if not key_text:
        return default

    if key_text in mapping:
        return mapping[key_text]

    try:
        if key in mapping:
            return mapping[key]
    except TypeError:
        pass

    return default


def company_car_usage(business_distance: Any) -> float:
    """Usage for Company Car: business distance."""
    return safe_float(business_distance)


def private_car_usage(business_distance: Any) -> float:
    """Usage for Private Car: business distance."""
    return safe_float(business_distance)


import re
from typing import Any, Mapping

import pandas as pd


def rail_usage(
    city_pair: Any,
    approved_amount: Any,
    complementary_detail: Any,
    country_of_transaction: Any,
    rail_city_distance_mapping: Mapping | None = None,
    rail_country_rates_mapping: Mapping | None = None,
    rail_region_rates_mapping: Mapping | None = None,
    rail_clean_country_mapping: Mapping | None = None,
    rail_clean_region_mapping: Mapping | None = None,
    comp_details_distance_mapping: Mapping | None = None,
) -> float | None:

    def clean(value: Any) -> str:
        return "" if pd.isna(value) else str(value).strip().lower()

    def lookup(mapping: Mapping | None, key: Any) -> Any:
        # Mapping keys are already lowercase.
        # Only the incoming lookup key is cleaned and lowercased.
        return (mapping or {}).get(clean(key), "")

    # Convert approved amount to numeric.
    try:
        approved_amount = float(approved_amount)
    except (TypeError, ValueError):
        return None

    city_pair = clean(city_pair)
    complementary_detail = clean(complementary_detail)
    country_input = clean(country_of_transaction)

    # complementary_detail is intentionally retained as an input
    # but is not used in the calculation.

    # Priority 1: City-pair distance.
    # Do not perform a blank-key lookup when city_pair is missing.
    if city_pair:
        usage = lookup(
            rail_city_distance_mapping,
            city_pair,
        )
    else:
        usage = None

    # Clean country lookup.
    country = lookup(
        rail_clean_country_mapping,
        country_input,
    )
    country = clean(country)

    # Clean region lookup.
    region = lookup(
        rail_clean_region_mapping,
        country_input,
    )
    region = clean(region)

    # Country rate first.
    lookup_cost_per_unit = lookup(
        rail_country_rates_mapping,
        country,
    )

    # Region rate fallback.
    if (
        lookup_cost_per_unit == ""
        or pd.isna(lookup_cost_per_unit)
    ):
        lookup_cost_per_unit = lookup(
            rail_region_rates_mapping,
            region,
        )

    # No valid country or region rate.
    if (
        lookup_cost_per_unit == ""
        or pd.isna(lookup_cost_per_unit)
    ):
        return None

    try:
        lookup_cost_per_unit = float(lookup_cost_per_unit)
    except (TypeError, ValueError):
        return None

    if lookup_cost_per_unit == 0:
        return None

    # If city pair is blank, missing, nonnumeric, or mapped to zero,
    # calculate usage from approved amount and lookup rate.
    try:
        usage = float(usage)
    except (TypeError, ValueError):
        return approved_amount / lookup_cost_per_unit

    if pd.isna(usage) or usage == 0:
        return approved_amount / lookup_cost_per_unit
    
    if complementary_detail and city_pair:
        if approved_amount < 0:
            usage *= -1
        if "rtn" in str(complementary_detail).strip().lower():
            usage *= 2
        return usage

    # Calculate actual cost per unit using the city-pair distance.
    cost_per_unit = abs(approved_amount) / abs(usage)

    minimum_rate = lookup_cost_per_unit / 3
    maximum_rate = lookup_cost_per_unit * 3

    # Use city-pair distance if calculated rate is within the valid range.
    if minimum_rate <= cost_per_unit <= maximum_rate:
        return (
            -abs(usage)
            if approved_amount < 0
            else abs(usage)
        )

    # Otherwise, calculate usage using approved amount and lookup rate.
    return approved_amount / lookup_cost_per_unit



def hotel_usage(expense_type: Any, cost: Any) -> float:
    """Usage for Hotel: approved amount/spend-based usage."""
    if expense_type.lower() in ["hotel tax", "hotel-taxable"]:
        return 0
    else:
        if cost > 0:
            return 1
        elif cost < 0:
            return -1
        else:
            return 0


def rental_car_usage(
    expense_type: Any,
    employee_country: Any,
    country_of_transaction: Any,
    approved_amount: Any,
    _all_car_rental: Any,
    _all_fuel: Any,
    rental_fuel_price_mapping: Mapping | None = None,
    rental_country_split_mapping: Mapping | None = None,
) -> float:
    """
    Calculate Rental Car usage.

    Preserved logic:
    - GB employee country returns 0.
    - All car rental rows: approved amount * country split / fuel price.
    - All fuel rows: approved amount / fuel price.
    - Expense types containing 'fuel': approved amount / fuel price.
    - Expense types containing 'rental' but not fuel: 0.
    - Otherwise: NaN.
    - Missing country mappings fall back to the 'oc' split value.
    """

    # Preserve original GB exception
    if safe_lower(employee_country) == "gb":
        return 0.0

    amount = safe_float(approved_amount)

    if pd.isna(amount):
        return np.nan

    expense = safe_lower(expense_type)
    emp_country_key = safe_lower(employee_country)
    transaction_country_key = safe_lower(country_of_transaction)

    rental_fuel_price_mapping = rental_fuel_price_mapping or {}
    rental_country_split_mapping = rental_country_split_mapping or {}

    # Original fallback value
    oc_mapping = safe_rate(
        rental_country_split_mapping,
        "oc",
    )

    # Fuel price falls back to OC mapping
    fuel_price = safe_rate(
        rental_fuel_price_mapping,
        transaction_country_key,
    )

    if pd.isna(fuel_price):
        fuel_price = oc_mapping

    # Employee-country split falls back to OC mapping
    split_value = safe_rate(
        rental_country_split_mapping,
        emp_country_key,
    )

    if pd.isna(split_value):
        split_value = oc_mapping

    # Safely normalize boolean flags
    all_car_rental = (
        str(_all_car_rental).strip().casefold() in {"true", "1", "yes"}
        if isinstance(_all_car_rental, str)
        else bool(_all_car_rental)
        if not is_blank(_all_car_rental)
        else False
    )

    all_fuel = (
        str(_all_fuel).strip().casefold() in {"true", "1", "yes"}
        if isinstance(_all_fuel, str)
        else bool(_all_fuel)
        if not is_blank(_all_fuel)
        else False
    )

    # Prevent invalid division
    valid_fuel_price = pd.notna(fuel_price) and fuel_price != 0

    # CONDITION 1 — all rows car rental
    if all_car_rental:
        if not valid_fuel_price or pd.isna(split_value):
            return np.nan

        return (amount * split_value) / fuel_price

    # CONDITION 2 — all rows fuel
    if all_fuel:
        if not valid_fuel_price:
            return np.nan

        return amount / fuel_price

    # CONDITION 3 — fuel expense
    if "fuel" in expense:
        if not valid_fuel_price:
            return np.nan

        return amount / fuel_price

    # CONDITION 4 — rental but not fuel
    if "rental" in expense:
        return 0.0

    return np.nan


def taxi_usage(
    country_of_transaction: Any,
    city_of_transaction: Any,
    approved_amount: Any,
    taxi_city_start_rate_mapping: Mapping | None = None,
    taxi_city_1km_rate_mapping: Mapping | None = None,
    taxi_country_start_rate_mapping: Mapping | None = None,
    taxi_country_1km_rate_mapping: Mapping | None = None,
    taxi_city_normalized_mapping: Mapping | None = None,
) -> float:
    """
    Calculate taxi usage in kilometres from the approved amount.

    Lookup fallback:
        normalized city -> raw city -> country

    Calculation:
        first 2 km = start rate
        additional km = (amount - start rate) / per-km rate

    Negative approved amounts return negative taxi usage.
    """

    amount = safe_float(approved_amount)
    if amount == 0:
        return 0

    if pd.isna(amount):
        return np.nan

    raw_city = safe_lower(city_of_transaction)
    country = safe_lower(country_of_transaction)

    country_city_key = country + raw_city

    normalized_city = _lookup_value(
        taxi_city_normalized_mapping,
        country_city_key,
        default=raw_city,
    )

    normalized_city = safe_lower(normalized_city) or raw_city
    normalized_city_key = country + normalized_city
    
    city_key_exists = (
    taxi_city_1km_rate_mapping is not None
    and normalized_city_key in taxi_city_1km_rate_mapping
)

    # If normalized city not found, check raw city
    if not city_key_exists and normalized_city_key != country_city_key:
        city_key_exists = (
            taxi_city_1km_rate_mapping is not None
            and country_city_key in taxi_city_1km_rate_mapping
        )

    # City not found anywhere in city lookup
    if not city_key_exists:
        return np.nan

    # First try the normalized city.
    start_rate = safe_rate(
        taxi_city_start_rate_mapping,
        normalized_city_key,
    )

    per_km_rate = safe_rate(
        taxi_city_1km_rate_mapping,
        normalized_city_key,
    )

    # If normalized and raw city keys differ, fall back to raw city.
    if normalized_city_key != country_city_key:
        if pd.isna(start_rate):
            start_rate = safe_rate(
                taxi_city_start_rate_mapping,
                country_city_key,
            )

        if pd.isna(per_km_rate):
            per_km_rate = safe_rate(
                taxi_city_1km_rate_mapping,
                country_city_key,
            )

    # Fall back independently to country rates.
    if pd.isna(start_rate):
        start_rate = safe_rate(
            taxi_country_start_rate_mapping,
            country,
        )

    if pd.isna(per_km_rate):
        per_km_rate = safe_rate(
            taxi_country_1km_rate_mapping,
            country,
        )

    # Distance cannot be calculated without a valid per-km rate.
    if pd.isna(per_km_rate) or per_km_rate == 0:
        return 0.0

    # Treat a missing start rate as zero.
    if pd.isna(start_rate):
        start_rate = 0.0

    absolute_amount = abs(amount)

    # Start rate covers the first 2 km.
    if absolute_amount <= start_rate:
        usage = 2.0
    else:
        usage = ((absolute_amount - start_rate) / per_km_rate) + 2.0

    return -usage if amount < 0 else usage




def lpt_usage(emp_country, country_of_transaction, cost, **lookups):

    if not cost:
        return 0.0

    # ===== Excel: IF(BK2="") =====
    if is_blank(country_of_transaction):

        # Excel: IF(P2="FR")
        if emp_country == "FR":
            rate = safe_rate(
                lookups["emp_country_rail_rate"],
                emp_country.lower()
            )
        else:
            rate = safe_rate(
                lookups["emp_country_bus_rate"],
                emp_country.lower()
            )

    else:
        mapped_country = lookups["lpt_country_mapping"].get(
            safe_lower(country_of_transaction),
            ""
        )

        if emp_country == "FR":
            rate = safe_rate(
                lookups["transaction_country_rail_rate"],
                mapped_country.lower()
            )
        else:
            rate = safe_rate(
                lookups["transaction_country_bus_rate"],
                mapped_country.lower()
            )

    return cost / rate if rate else 0.0


USAGE_FUNCTIONS = {
    "Company Car": company_car_usage,
    "Private Car": private_car_usage,
    "Rental Car": rental_car_usage,
    "LPT": lpt_usage,
    "Taxi": taxi_usage,
    "Rail": rail_usage,
    "Hotel": hotel_usage,
}
