from pathlib import Path
import sys
import numpy as np
import pandas as pd

project_root = Path.cwd().parents[1]
sys.path.append(str(project_root / "src"))

from processing.myexpense_general import create_scalar_concat_string


def company_car_source(country: str, expense_type: str, criteria_name: str, **lookups: dict):
    key = create_scalar_concat_string(country, expense_type, criteria_name)
    return lookups['mapping_lookup'].get(key.lower(), "")
    

def rental_car_source(
    expense_type: str,
    emp_country: str,
    cot: str,
    all_car_rental: bool,
    all_fuel: bool,
    **lookups,
) -> float:
    
    emp_country = emp_country.lower()
    expense_type = expense_type.lower()
    cot = cot.lower()

    if emp_country == "gb":
        # return f"{emp_country}{expense_type}"
        return lookups["rental_source_fuel_mapping"].get(f"{emp_country}{expense_type}", np.nan)
        

    expense_type_norm = expense_type.strip().casefold()

    # CONDITION 1 — all rows car rental
    if all_car_rental:
        return lookups["rental_source_mapping"].get(cot, np.nan)

    # CONDITION 2 — all rows fuel
    if all_fuel:
        return lookups["rental_source_mapping"].get(cot, np.nan)

    # CONDITION 3 — rental but not fuel
    if "fuel" in expense_type_norm:
        return lookups["rental_source_mapping"].get(cot, np.nan)

    # CONDITION 4 — not fuel
    if "rental" in expense_type_norm:
        return "Car Rental Cost"

    return np.nan

def private_car_source(expense_type, criteria_name, **lookups):
    key = create_scalar_concat_string(expense_type, criteria_name)
    return lookups['mapping_lookup'].get(key.lower(), "")

def taxi_source():
    return "Taxi"

def lpt_source(country):
    if country == "FR":
        return "Domestic Rail"
    else:
        return "Bus"
    
    

def safe_text(value) -> str:
    if pd.isna(value):
        return ""
    return str(value).strip().lower()


def rail_source(
    Comp_Details,
    port_of_departure,
    port_of_arrival,
    Vendor_name,
    legal_entity,
    country_of_transaction,
    city_pair,
    **lookups
):
    city_pair_lookup = lookups["rail_normalized_city_country_mapping"]
    vendor_name_lookup = lookups["vendor_name_mapping"]
    eurostar_lookup = lookups["eurostar_mapping"]
    legal_entity_country_lookup = lookups["legal_entity_country"]

    # Normalize input values
    Comp_Details = safe_text(Comp_Details)
    port_of_departure = safe_text(port_of_departure)
    port_of_arrival = safe_text(port_of_arrival)
    Vendor_name = safe_text(Vendor_name)
    legal_entity = safe_text(legal_entity)
    country_of_transaction = safe_text(country_of_transaction)
    city_pair = safe_text(city_pair)

    def is_missing(value):
        """
        Returns True for blank, None, NaN, pandas NA,
        NaT, N/A, or other common missing-value strings.
        """
        return safe_text(value) in {
            "",
            "nan",
            "none",
            "<na>",
            "nat",
            "n/a",
            "na",
            "null"
        }

    def is_eurostar(value):
        """Checks whether the mapped source is Euro Star."""
        return safe_text(value) == "euro star"

    def entity_transaction_source():
        """
        Compares legal entity country with transaction country.

        Same valid country -> Domestic Rail
        Missing or different country -> International Rail
        """
        entity_country = safe_text(
            legal_entity_country_lookup.get(legal_entity, "")
        )

        if (
            not is_missing(entity_country)
            and not is_missing(country_of_transaction)
            and entity_country == country_of_transaction
        ):
            return "Domestic Rail"

        return "International Rail"

    # ===============================================================
    # Branch 1: City pair is blank or missing
    # ===============================================================
    if is_missing(city_pair):
        vendor_source = vendor_name_lookup.get(Vendor_name, "")

        if is_eurostar(vendor_source):
            return "Euro Star"

        return entity_transaction_source()

    # ===============================================================
    # Branch 2: City pair is available
    # ===============================================================

    # First check city-pair Eurostar mapping
    source_name = eurostar_lookup.get(city_pair, "")

    # If city-pair mapping is missing or NaN, use vendor mapping
    if is_missing(source_name):
        source_name = vendor_name_lookup.get(Vendor_name, "")

    # Eurostar takes priority
    if is_eurostar(source_name):
        return "Euro Star"

    # Get mapped departure and arrival countries.
    # The default is blank because the station value itself is not a country.
    origin_country = safe_text(
        city_pair_lookup.get(port_of_departure, "")
    )

    destination_country = safe_text(
        city_pair_lookup.get(port_of_arrival, "")
    )

    # Both valid countries are the same
    if (
        not is_missing(origin_country)
        and not is_missing(destination_country)
        and origin_country == destination_country
    ):
        return "Domestic Rail"

    # Origin/destination country is missing, N/A, NaN, or different.
    # Fall back to legal entity country vs transaction country.
    return entity_transaction_source()


def hotel_source(travel_category):
    if travel_category.lower() == "local":
        return "Hotel - Domestic"
    else:
        return "Hotel - Abroad"



SOURCE_FUNCTIONS = {
    "Company Car": company_car_source,
    "Private Car": private_car_source,
    "Rental Car": rental_car_source,
    "LPT": lpt_source,
    "Taxi": taxi_source,
    "Rail": rail_source,
    "Hotel": hotel_source,
}
