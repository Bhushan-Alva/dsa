"""Fast general MyExpense transformation utilities with light step-level logging.

Public functions preserved:
- calculate_departure_date
- create_concat_string
- create_scalar_concat_string
- get_travel_category
- build_console_key
- calculate_cost_in_local

Added for speed:
- get_travel_category_vectorized

Design:
- Logs only start/end or validation failures.
- No row-level logging.
- _log_step exits immediately if the logger level will not emit the message.
- Vectorized travel category function should be used in the notebook instead of df.apply.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Mapping, Sequence

import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)

try:
    from src.testing.validations.error_log import error_log
except ModuleNotFoundError:
    try:
        from testing.validations.error_log import error_log
    except Exception:
        error_log = None


MISSING_VALUES = {"", "missing value", "na", "n/a", "null", "none", "nan", "<na>"}


def _log_step(step: str, level: int = logging.INFO, **details: Any) -> None:
    """Fast structured log entry. Avoids string building when level disabled."""
    if not logger.isEnabledFor(level):
        return
    if details:
        detail_text = " | ".join(f"{key}={value}" for key, value in details.items())
        logger.log(level, "%s | %s", step, detail_text)
    else:
        logger.log(level, "%s", step)


def _series_name(series_or_value: Any, fallback: str) -> str:
    return getattr(series_or_value, "name", None) or fallback


def _as_series(value: Any, index: pd.Index, name: str) -> pd.Series:
    if isinstance(value, pd.Series):
        return value.reindex(index)
    return pd.Series(value, index=index, name=name)


def _require_columns(df: pd.DataFrame, columns: Sequence[str], context: str) -> None:
    missing = [column for column in columns if column not in df.columns]
    if missing:
        _log_step("Required-column validation failed", logging.ERROR, context=context, missing_columns=missing)
        raise KeyError(f"Missing required column(s) in {context}: {missing}")


def calculate_departure_date(
    df: pd.DataFrame,
    output_col: str = "Departure Date",
    inplace: bool = False,
) -> pd.DataFrame:
    """
    Calculate Departure Date using Transaction Date and Report Extract Date.

    Rules:
    - If Transaction Date is more than 2 calendar months older than
      Report Extract Date, return the first day of the month that is
      2 months before Report Extract Date.
    - Otherwise, return Transaction Date.
    - Do not fill a missing Transaction Date with Report Extract Date.
    - If Transaction Date is missing or invalid, Departure Date remains NaT.
    """

    _log_step(
        "Departure date calculation started",
        rows=len(df),
        output_col=output_col,
    )

    result = df if inplace else df.copy()

    required_cols = ["Transaction Date", "Report Extract Date"]
    missing_cols = [
        col for col in required_cols
        if col not in result.columns
    ]

    if missing_cols:
        raise ValueError(
            "Required column(s) missing for departure date calculation: "
            f"{missing_cols}"
        )

    transaction_date = pd.to_datetime(
        result["Transaction Date"],
        errors="coerce",
    )

    report_extract_date = pd.to_datetime(
        result["Report Extract Date"],
        errors="coerce",
    )

    # Calculate the difference in calendar months
    month_diff = (
        (report_extract_date.dt.year - transaction_date.dt.year) * 12
        + (
            report_extract_date.dt.month
            - transaction_date.dt.month
        )
    )

    # Default Departure Date is Transaction Date.
    # Missing Transaction Date remains NaT.
    departure_date = transaction_date.copy()

    # Apply capping only when both dates are valid and the difference
    # is more than two calendar months.
    mask = (
        transaction_date.notna()
        & report_extract_date.notna()
        & month_diff.gt(2)
    )

    # First day of the month, two months before Report Extract Date
    capped_date = (
        report_extract_date.loc[mask]
        .dt.to_period("M")
        .sub(2)
        .dt.to_timestamp()
    )

    departure_date.loc[mask] = capped_date

    result[output_col] = departure_date

    _log_step(
        "Departure date calculation completed",
        rows=len(result),
        capped_dates=int(mask.sum()),
        non_null_dates=int(result[output_col].notna().sum()),
        null_dates=int(result[output_col].isna().sum()),
    )

    return result



def create_concat_string(df: pd.DataFrame, cols: Sequence[str], sep: str = "") -> pd.Series:
    """Create a row-wise concatenated key from multiple DataFrame columns.

    Optimized path for common cases avoids DataFrame.apply(axis=1).
    """
    _log_step("Concat string creation started", rows=len(df), column_count=len(cols), separator=sep)
    _require_columns(df, cols, "create_concat_string")

    cols = list(cols)
    if not cols:
        return pd.Series("", index=df.index, dtype="string")

    result = df[cols[0]].fillna("").astype(str).str.strip()
    for col in cols[1:]:
        result = result + sep + df[col].fillna("").astype(str).str.strip()

    _log_step("Concat string creation completed", rows=len(result), blank_results=int(result.eq("").sum()))
    return result


def create_scalar_concat_string(*values: Any, sep: str = "") -> str:
    """Create a concatenated key from scalar values. No logging to avoid row-level overhead."""
    return sep.join("" if pd.isna(value) else str(value).strip() for value in values)


def get_travel_category_vectorized(
    df,
    entity_country_lookup,
    country_mapping_lookup,
    country_col="Country Of Transaction",
    legal_entity_col="Legal Entity",
):
    # Legal Entity -> Country lookup
    entity_lookup = {
        str(key).strip().lower(): str(value).strip().lower()
        for key, value in entity_country_lookup.items()
    }

    # Country normalization lookup
    country_lookup = {
        str(key).strip().lower(): str(value).strip().lower()
        for key, value in country_mapping_lookup.items()
    }

    country = (
        df[country_col]
        .astype("string")
        .str.strip()
        .str.lower()
        .map(lambda x: country_lookup.get(x, x))
    )

    legal_entity = (
        df[legal_entity_col]
        .astype("string")
        .str.strip()
        .str.lower()
    )

    entity_country = (
        legal_entity
        .map(entity_lookup)
        .astype("string")
        .str.strip()
        .str.lower()
    )

    country_missing = (
        country.isna()
        | country.isin(MISSING_VALUES)
    )

    entity_country_missing = (
        entity_country.isna()
        | entity_country.isin(MISSING_VALUES)
    )

    result = pd.Series("Abroad", index=df.index, dtype="string")

    result.loc[country_missing] = "Unknown"

    result.loc[
        ~country_missing
        & ~entity_country_missing
        & country.eq(entity_country)
    ] = "Local"

    return result


def build_console_key(
    df: pd.DataFrame,
    key_map: Mapping[str, Sequence[str]],
    source_col: str = "Source",
    output_col: str = "Console Key",
    sep: str = "",
    inplace: bool = False,
) -> pd.DataFrame:
    """Build source-specific console keys based on mapping of source to columns."""
    _log_step("Console key build started", rows=len(df), source_count=len(key_map), output_col=output_col)
    result = df if inplace else df.copy()
    _require_columns(result, [source_col], "build_console_key")

    if output_col not in result.columns:
        result[output_col] = ""

    all_cols = sorted({column for cols in key_map.values() for column in cols})
    missing = [column for column in all_cols if column not in result.columns]
    if missing:
        _log_step("Console key source columns missing", logging.WARNING, missing_columns=missing)
        for column in missing:
            result[column] = ""

    if all_cols:
        cleaned = result[all_cols].fillna("").astype(str)
        for column in all_cols:
            cleaned[column] = cleaned[column].str.strip()
    else:
        cleaned = pd.DataFrame(index=result.index)

    processed_rows = 0
    source_series = result[source_col].astype("string").str.strip()
    for source, cols in key_map.items():
        if not cols:
            continue
        mask = source_series.eq(str(source).strip())
        row_count = int(mask.sum())
        if row_count == 0:
            continue
        result.loc[mask, output_col] = cleaned.loc[mask, list(cols)].agg(sep.join, axis=1)
        processed_rows += row_count

    _log_step("Console key build completed", rows=len(result), processed_rows=processed_rows)
    return result


def calculate_cost_in_local(
    cost_in_euro,
    country,
    year,
    lookup: Mapping[str, Mapping],
    df: pd.DataFrame | None = None,
    logs: str | Path | None = None,
) -> pd.DataFrame:
    """Calculate local-currency cost using country and currency-conversion lookups."""
    _log_step("Local currency cost calculation started")

    if lookup is None:
        raise ValueError("lookup cannot be None")
    missing_sections = [key for key in ["currency", "currency_conversion"] if key not in lookup]
    if missing_sections:
        _log_step("Local currency cost calculation failed", logging.ERROR, missing_lookup_sections=missing_sections)
        raise KeyError(f"Missing required lookup section(s): {missing_sections}")

    if df is None:
        index = country.index if isinstance(country, pd.Series) else None
        if index is None and isinstance(year, pd.Series):
            index = year.index
        if index is None and isinstance(cost_in_euro, pd.Series):
            index = cost_in_euro.index
        if index is None:
            index = pd.RangeIndex(1)
        result = pd.DataFrame(index=index)
    else:
        result = df.copy()

    country_col = _series_name(country, "Employee Country")
    year_col = _series_name(year, "Departure Date")
    cost_col = _series_name(cost_in_euro, "Approved Amount")

    result[country_col] = _as_series(country, result.index, country_col)
    result[year_col] = _as_series(year, result.index, year_col)
    result[cost_col] = _as_series(cost_in_euro, result.index, cost_col)

    country_lower = result[country_col].astype("string").str.strip().str.lower()
    currency_lookup = {str(key).strip().lower(): value for key, value in lookup["currency"].items()}
    result["Local_Currency"] = country_lower.map(currency_lookup)
    result["Missing_Currency_Flag"] = result["Local_Currency"].isna()

    year_values = pd.to_datetime(result[year_col], errors="coerce").dt.year.astype("Int64").astype("string")
    result["Conv_Key"] = result["Local_Currency"].astype("string") + year_values

    conversion_lookup = {str(key).strip().lower(): value for key, value in lookup["currency_conversion"].items()}
    result["Conv_Key_Lower"] = result["Conv_Key"].astype("string").str.lower()
    result["Rate"] = result["Conv_Key_Lower"].map(conversion_lookup)
    result["Missing_Rate_Flag"] = result["Rate"].isna() & result["Local_Currency"].notna()

    result[cost_col] = pd.to_numeric(result[cost_col], errors="coerce")
    result["Rate"] = pd.to_numeric(result["Rate"], errors="coerce")
    result["Cost in local currency"] = result[cost_col] / result["Rate"]

    missing_currency_count = int(result["Missing_Currency_Flag"].sum())
    missing_rate_count = int(result["Missing_Rate_Flag"].sum())

    if missing_currency_count and error_log is not None and logs is not None:
        try:
            error_log(
                df=result,
                folder_path=logs,
                columns_to_keep=[country_col],
                check_column="Local_Currency",
                output_sheet_name="Missing Currency",
            )
        except Exception as exc:
            _log_step("Missing currency error log failed", logging.WARNING, error_type=type(exc).__name__, error_message=str(exc))

    if missing_rate_count and error_log is not None and logs is not None:
        try:
            error_log(
                df=result,
                folder_path=logs,
                columns_to_keep=["Conv_Key"],
                check_column="Rate",
                output_sheet_name="Missing Currency Conversion Rate",
            )
        except Exception as exc:
            _log_step("Missing currency conversion rate error log failed", logging.WARNING, error_type=type(exc).__name__, error_message=str(exc))

    _log_step(
        "Local currency cost calculation completed",
        rows=len(result),
        missing_currency_count=missing_currency_count,
        missing_rate_count=missing_rate_count,
        non_null_cost_local=int(result["Cost in local currency"].notna().sum()),
    )
    return result
