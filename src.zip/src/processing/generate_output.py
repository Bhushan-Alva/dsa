"""Generate source-wise consolidated Excel outputs."""

import logging
import re
from pathlib import Path

import pandas as pd

logger = logging.getLogger(__name__)

SUM_COLUMNS = ["Usage Input", "Cost", "Emissions"]
ALIASES = {
    "Country of Transaction": "Country Of Transaction",
    "Country Of transaction": "Country Of Transaction",
    "City Name": "City Of Transaction",
    "Text3": "Text 3",
    "Text3 ": "Text 3",
    "Text5": "Text 5",
    "Number2": "Number 2",
    "Number3": "Number 3",
}


def get_sources(df, source_col="Source"):
    return df[source_col].dropna().astype(str).str.strip().loc[lambda x: x.ne("")].unique()


def _first_nonblank(values):
    values = values.dropna()
    if values.dtype == "object":
        values = values[values.astype(str).str.strip().ne("")]
    return values.iloc[0] if not values.empty else pd.NA


def _apply_aliases(df):
    for target, source in ALIASES.items():
        if target not in df and source in df:
            df[target] = df[source]
    return df


def _source_date(df, source, date_col=None):
    columns = ([date_col] if date_col else []) + (
        ["Check-In Date", "Departure Date"]
        if str(source).strip().lower() == "hotel"
        else ["Departure Date", "Check-In Date"]
    )
    for column in columns:
        if column and column in df:
            dates = pd.to_datetime(df[column], errors="coerce")
            if dates.notna().any():
                return dates.max()
    return pd.NaT


def _filename(source, max_date, data_source_name):
    clean = lambda x: re.sub(r'[<>:"/\\|?*]', "_", str(x).strip()).rstrip(". ")
    year, month = (max_date.year, f"{max_date.month:02d}") if pd.notna(max_date) else ("UNKNOWN", "00")
    return f"{year} 01-{month} Consolidated CG {clean(source)} {clean(data_source_name)}.xlsx"


def group_source(df, source, keys, sum_columns=None):
    keys = list(dict.fromkeys(keys))
    missing = [col for col in keys if col not in df.columns]

    if missing:
        raise KeyError(
            f"Missing grouping columns for '{source}': {missing}"
        )

    df = df.copy()
    sum_columns = set(sum_columns or SUM_COLUMNS)

    text_columns = df.select_dtypes(
        include=["object", "string"]
    ).columns

    # Normalize whitespace and blank values once
    df[text_columns] = (
        df[text_columns]
        .astype("string")
        .apply(lambda col: col.str.strip())
        .replace("", pd.NA)
    )

    numeric_columns = [
        col for col in sum_columns
        if col in df.columns and col not in keys
    ]

    if numeric_columns:
        df[numeric_columns] = df[numeric_columns].apply(
            pd.to_numeric,
            errors="coerce",
        )

    if "Check-Out Date" in df.columns:
        df["Check-Out Date"] = pd.to_datetime(
            df["Check-Out Date"],
            errors="coerce",
        )

    rules = {
        col: (
            "sum"
            if col in numeric_columns
            else "min"
            if col in {"Departure Date", "Arrival Date", "Check-In Date"}
            else "first"
        )
        for col in df.columns
        if col not in keys
    }

    grouped = (
        df.groupby(
            keys,
            as_index=False,
            sort=False,
            dropna=False,
            observed=True,
        )
        .agg(rules)
    )
    
    # Calculate Check-Out Date from grouped Check-In Date and Usage Input
    if (
        "Check-Out Date" in grouped.columns
        and "Check-In Date" in grouped.columns
        and "Usage Input" in grouped.columns
    ):
        grouped["Check-Out Date"] = (
            grouped["Check-In Date"]
            + pd.to_timedelta(
                grouped["Usage Input"].abs(),
                unit="D",
            )
        )
    
    # Norway Company Car exception
    if (
        source == "Company Car"
        and "Legal Entity" in grouped.columns
        and "Usage Input" in grouped.columns
    ):
        grouped.loc[
            grouped["Legal Entity"].eq("Norway Capgemini"),
            "Usage Input",
        ] = pd.NA

    logger.info(
        "Grouped source=%s | input_rows=%s | "
        "output_rows=%s | keys=%s",
        source,
        len(df),
        len(grouped),
        keys,
    )

    return grouped


def get_output_dataframes(df, output_map, keys_map=None, sum_columns=None, source_col="Source"):
    result = {}
    source_values = df[source_col].fillna("").astype(str).str.strip()

    for source in get_sources(df, source_col):
        out = _apply_aliases(df.loc[source_values.eq(source)].copy())
        keys = (keys_map or {}).get(source, [])
        if keys:
            out = group_source(out, source, keys, sum_columns)

        columns = list(dict.fromkeys(output_map.get("Common Columns", []) + output_map.get(source, [])))
        for column in columns:
            if column not in out:
                out[column] = pd.NA
        result[source] = out[columns]

    return result


def _write_excel(df, path, sheet_name="Sheet1", col_width=30):
    with pd.ExcelWriter(path, engine="xlsxwriter", datetime_format="mm-dd-yyyy", date_format="mm-dd-yyyy") as writer:
        df.to_excel(writer, index=False, sheet_name=sheet_name[:31])
        worksheet = writer.sheets[sheet_name[:31]]
        header = writer.book.add_format({
            "bold": True, "font_color": "white", "bg_color": "#4F81BD",
            "align": "center", "valign": "vcenter", "text_wrap": True, "border": 1,
        })
        for index, column in enumerate(df.columns):
            worksheet.write(0, index, column, header)
        worksheet.freeze_panes(1, 0)
        if len(df.columns):
            worksheet.autofilter(0, 0, max(len(df), 1), len(df.columns) - 1)
            worksheet.set_column(0, len(df.columns) - 1, col_width)


def generate_outputs(
    df,
    output_map,
    output_dir,
    keys_map=None,
    sum_columns=None,
    source_col="Source",
    date_col=None,
    sheet_name="Sheet1",
    col_width=30,
    data_source_name="MyExpense",
):
    """Return ({source: dataframe}, {source: exported path})."""
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    if keys_map is None:
        keys_map = {source: ["Console Key"] for source in get_sources(df, source_col)}

    dates = {
        source: _source_date(df.loc[df[source_col].fillna("").astype(str).str.strip().eq(source)], source, date_col)
        for source in get_sources(df, source_col)
    }
    outputs = get_output_dataframes(df, output_map, keys_map, sum_columns, source_col)
    exported = {}

    for source, out in outputs.items():
        path = output_dir / _filename(source, dates[source], data_source_name)
        _write_excel(out, path, sheet_name, col_width)
        exported[source] = str(path)
        logger.info("Saved source=%s | rows=%s | path=%s", source, len(out), path)

    return outputs, exported
